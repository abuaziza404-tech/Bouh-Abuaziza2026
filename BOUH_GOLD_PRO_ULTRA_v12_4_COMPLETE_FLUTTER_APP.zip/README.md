# BOUH GOLD PRO ULTRA V12.4 — بوح التضاريس

تطبيق Flutter ميداني عربي لإدارة الخرائط والتحليل المبدئي والنقاط والطبقات والملفات.

- كلمة المرور: `Abuaziza2000`
- التطبيق لا يحتوي أهداف ذهب جاهزة داخل الخريطة.
- التحليل يتم عند ضغط المستخدم على الخريطة أو عند استيراد ملفات KML/GeoJSON/CSV.
- النتائج ليست إثباتًا اقتصاديًا. يلزم تحقق ميداني + عينات + QA/QC.

## الملفات الأساسية
- `lib/main.dart`
- `pubspec.yaml`
- `.github/workflows/main.yml`
- `assets/branding/bouh_icon.png`
- `assets/branding/bouh_cover.png`

## البناء
GitHub Actions يبني APK قابل للتثبيت مباشرة.
