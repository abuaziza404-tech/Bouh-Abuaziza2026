import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BouhApp());
}

class C {
  static const obsidian = Color(0xFF05070A);
  static const panel = Color(0xFF0A1110);
  static const gold = Color(0xFFD4AF37);
  static const cyan = Color(0xFF00F3FF);
  static const red = Color(0xFFE53935);
  static const amber = Color(0xFFFFB300);
  static const green = Color(0xFF00C853);
}

class AppInfo {
  static const appName = 'بوح التضاريس';
  static const techName = 'BOUH GOLD PRO ULTRA V12.4';
  static const ownerAr = 'أحمد أبوعزيزه الرشيدي';
  static const ownerEn = 'Eng. Ahmed Abuaziza Al-Rashidi';
  static const password = 'Abuaziza2000';
  static const workspace = 'BOUH_GOLD_PRO_ULTRA_WORKSPACE';
  static const releaseLink = 'https://github.com/abuaziza404-tech/BOUH-GOLD-PRO-ULTRA-v12/releases/latest';
  static const openAi = 'https://api.openai.com/v1/chat/completions';
}

class BouhApp extends StatelessWidget {
  const BouhApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppInfo.appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: C.obsidian,
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: const ColorScheme.dark(primary: C.gold, secondary: C.cyan, surface: C.panel),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: GateScreen()),
    );
  }
}

class GateScreen extends StatefulWidget {
  const GateScreen({super.key});
  @override
  State<GateScreen> createState() => _GateScreenState();
}

class _GateScreenState extends State<GateScreen> {
  bool loading = true;
  bool unlocked = false;
  final pass = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      unlocked = p.getBool('unlocked') ?? false;
      loading = false;
    });
  }

  Future<void> _login() async {
    if (pass.text.trim() == AppInfo.password) {
      final p = await SharedPreferences.getInstance();
      await p.setBool('unlocked', true);
      if (mounted) setState(() => unlocked = true);
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('كلمة المرور غير صحيحة')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: C.gold)));
    }
    if (unlocked) return const HomeShell();
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/branding/bouh_cover.png', fit: BoxFit.cover),
          Container(color: Colors.black.withOpacity(.54)),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(22),
                child: TacticalCard(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset('assets/branding/bouh_icon.png', width: 120, height: 120),
                      const SizedBox(height: 12),
                      const Text(AppInfo.appName, style: TextStyle(color: C.gold, fontSize: 32, fontWeight: FontWeight.w900)),
                      const Text(AppInfo.techName, style: TextStyle(color: Colors.white70, fontSize: 17, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      const Text('تطوير وتصميم: ${AppInfo.ownerAr}', style: TextStyle(color: Colors.white70)),
                      const Text(AppInfo.ownerEn, style: TextStyle(color: Colors.white54, fontSize: 12)),
                      const SizedBox(height: 22),
                      TextField(
                        controller: pass,
                        obscureText: true,
                        textDirection: TextDirection.ltr,
                        decoration: _input('كلمة المرور'),
                        onSubmitted: (_) => _login(),
                      ),
                      const SizedBox(height: 16),
                      GoldButton(text: 'دخول النظام', icon: Icons.lock_open, onTap: _login),
                      const SizedBox(height: 12),
                      Text('القانون: بنية ← نمط ← تغيرات سطحية ← تحقق ميداني ← قرار', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(.66))),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  late final BouhController controller;
  int page = 0;

  @override
  void initState() {
    super.initState();
    controller = BouhController();
    controller.boot().then((_) { if (mounted) setState(() {}); });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      MapPage(controller: controller),
      AnalysisPage(controller: controller),
      FilesPage(controller: controller),
      AiPage(controller: controller),
      SettingsPage(controller: controller),
    ];
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) => Scaffold(
        body: SafeArea(child: pages[page]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: page,
          height: 70,
          backgroundColor: Colors.black,
          indicatorColor: C.gold.withOpacity(.22),
          onDestinationSelected: (v) => setState(() => page = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.map), label: 'الخريطة'),
            NavigationDestination(icon: Icon(Icons.auto_graph), label: 'التحليل'),
            NavigationDestination(icon: Icon(Icons.folder), label: 'الملفات'),
            NavigationDestination(icon: Icon(Icons.psychology_alt), label: 'المساعد'),
            NavigationDestination(icon: Icon(Icons.tune), label: 'النظام'),
          ],
        ),
      ),
    );
  }
}

class BouhController extends ChangeNotifier {
  final map = MapController();
  final engine = BouhEngine();
  final dist = const Distance();
  Directory? workspace;
  LatLng center = const LatLng(19.8255, 36.9532);
  double zoom = 13.0;
  LatLng? gps;
  String activeLayer = 'esri';
  final List<BouhPin> pins = [];
  final List<UserLayer> userLayers = [];
  AnalysisResult? last;
  String openAiKey = '';
  String openAiModel = 'gpt-4o';
  String custom1Name = 'Satellite 1';
  String custom1Url = '';
  String custom2Name = 'ASTER / Landsat';
  String custom2Url = '';
  bool useOnlineAi = false;

  final Map<String, TileConfig> baseLayers = {
    'osm': TileConfig('خريطة عادية', 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', 19),
    'esri': TileConfig('قمر صناعي', 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', 19),
    'topo': TileConfig('تضاريس', 'https://tile.opentopomap.org/{z}/{x}/{y}.png', 17),
    'nasa': TileConfig('NASA لون طبيعي', 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_SNPP_CorrectedReflectance_TrueColor/default/2024-01-01/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg', 9),
    'google': TileConfig('Google Satellite / يحتاج سماح قانوني', 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', 21),
  };

  Future<void> boot() async {
    final docs = await getApplicationDocumentsDirectory();
    workspace = Directory('${docs.path}/${AppInfo.workspace}');
    if (!await workspace!.exists()) await workspace!.create(recursive: true);
    final p = await SharedPreferences.getInstance();
    activeLayer = p.getString('activeLayer') ?? activeLayer;
    openAiKey = p.getString('openAiKey') ?? '';
    openAiModel = p.getString('openAiModel') ?? 'gpt-4o';
    custom1Url = p.getString('custom1Url') ?? '';
    custom2Url = p.getString('custom2Url') ?? '';
    custom1Name = p.getString('custom1Name') ?? custom1Name;
    custom2Name = p.getString('custom2Name') ?? custom2Name;
    useOnlineAi = p.getBool('useOnlineAi') ?? false;
    await _loadPins();
    notifyListeners();
  }

  Future<void> saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('activeLayer', activeLayer);
    await p.setString('openAiKey', openAiKey);
    await p.setString('openAiModel', openAiModel);
    await p.setString('custom1Url', custom1Url);
    await p.setString('custom2Url', custom2Url);
    await p.setString('custom1Name', custom1Name);
    await p.setString('custom2Name', custom2Name);
    await p.setBool('useOnlineAi', useOnlineAi);
  }

  Future<void> _loadPins() async {
    final file = File('${workspace!.path}/pins.json');
    if (!await file.exists()) return;
    try {
      final raw = jsonDecode(await file.readAsString());
      if (raw is List) pins.addAll(raw.map((e) => BouhPin.fromJson(Map<String, dynamic>.from(e))));
    } catch (_) {}
  }

  Future<void> _savePins() async {
    if (workspace == null) return;
    final file = File('${workspace!.path}/pins.json');
    await file.writeAsString(jsonEncode(pins.map((e) => e.toJson()).toList()));
  }

  void selectLayer(String id) {
    activeLayer = id;
    saveSettings();
    notifyListeners();
  }

  TileConfig get currentTile {
    if (activeLayer == 'custom1' && custom1Url.trim().isNotEmpty) return TileConfig(custom1Name, custom1Url.trim(), 22);
    if (activeLayer == 'custom2' && custom2Url.trim().isNotEmpty) return TileConfig(custom2Name, custom2Url.trim(), 22);
    return baseLayers[activeLayer] ?? baseLayers['esri']!;
  }

  Future<void> goGps(BuildContext context) async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        msg(context, 'لم يتم السماح بتشغيل GPS');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      gps = LatLng(pos.latitude, pos.longitude);
      center = gps!;
      map.move(gps!, 16);
      notifyListeners();
    } catch (e) {
      msg(context, 'تعذر تشغيل GPS: $e');
    }
  }

  Future<void> analyzeTap(BuildContext context, LatLng p) async {
    last = engine.analyze(p);
    pins.add(BouhPin(point: p, result: last!, note: 'نقطة مستخدم'));
    await _savePins();
    notifyListeners();
    if (context.mounted) showAnalysisSheet(context, last!);
  }

  Future<void> importFiles(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result == null) return;
    int copied = 0;
    for (final f in result.files) {
      if (f.path == null) continue;
      final src = File(f.path!);
      final safe = f.name.replaceAll(RegExp(r'[^A-Za-z0-9_.\-أ-ي ]'), '_');
      final dst = File('${workspace!.path}/$safe');
      await src.copy(dst.path);
      copied++;
      await _tryParseLayer(dst, safe);
    }
    notifyListeners();
    if (context.mounted) msg(context, 'تم استيراد $copied ملف داخل مساحة التطبيق');
  }

  Future<void> _tryParseLayer(File file, String name) async {
    final lower = name.toLowerCase();
    try {
      final text = await file.readAsString();
      final points = <LatLng>[];
      final lines = <List<LatLng>>[];
      if (lower.endsWith('.geojson') || lower.endsWith('.json')) {
        final data = jsonDecode(text);
        final features = data is Map ? data['features'] : null;
        if (features is List) {
          for (final f in features) {
            if (f is! Map) continue;
            final geom = f['geometry'];
            if (geom is! Map) continue;
            final type = geom['type'];
            final coords = geom['coordinates'];
            if (type == 'Point' && coords is List && coords.length >= 2) {
              points.add(LatLng((coords[1] as num).toDouble(), (coords[0] as num).toDouble()));
            } else if (type == 'LineString' && coords is List) {
              final line = <LatLng>[];
              for (final c in coords) {
                if (c is List && c.length >= 2) line.add(LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()));
              }
              if (line.length > 1) lines.add(line);
            }
          }
        }
      } else if (lower.endsWith('.kml')) {
        final reg = RegExp(r'(-?\d+\.\d+),(-?\d+\.\d+)(?:,[-?\d.]*)?');
        final matches = reg.allMatches(text).toList();
        final line = <LatLng>[];
        for (final m in matches.take(5000)) {
          final lon = double.tryParse(m.group(1) ?? '');
          final lat = double.tryParse(m.group(2) ?? '');
          if (lat != null && lon != null) line.add(LatLng(lat, lon));
        }
        if (line.length == 1) points.add(line.first);
        if (line.length > 1) lines.add(line);
      } else if (lower.endsWith('.csv')) {
        final rows = const LineSplitter().convert(text);
        for (final row in rows.take(5000)) {
          final parts = row.split(',');
          if (parts.length < 2) continue;
          final nums = parts.map((e) => double.tryParse(e.trim())).whereType<double>().toList();
          if (nums.length >= 2 && nums[0].abs() <= 90 && nums[1].abs() <= 180) points.add(LatLng(nums[0], nums[1]));
        }
      }
      if (points.isNotEmpty || lines.isNotEmpty) {
        userLayers.add(UserLayer(name: name, points: points, lines: lines));
      }
    } catch (_) {}
  }

  Future<void> exportKml(BuildContext context) async {
    if (pins.isEmpty) { msg(context, 'لا توجد نقاط للتصدير'); return; }
    final f = File('${workspace!.path}/BOUH_EXPORT_${DateTime.now().millisecondsSinceEpoch}.kml');
    final b = StringBuffer();
    b.writeln('<?xml version="1.0" encoding="UTF-8"?>');
    b.writeln('<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>BOUH GOLD PRO ULTRA</name>');
    for (final p in pins) {
      b.writeln('<Placemark><name>${_xml(p.result.statusAr)}</name><description><![CDATA[');
      b.writeln('مؤشر الكوارتز/الذهب: ${p.result.quartz.toStringAsFixed(3)}<br/>');
      b.writeln('مؤشر الحديد: ${p.result.iron.toStringAsFixed(3)}<br/>');
      b.writeln('مؤشر التغير السطحي: ${p.result.alteration.toStringAsFixed(3)}<br/>');
      b.writeln('الانحدار: ${p.result.slope.toStringAsFixed(3)}<br/>');
      b.writeln('القرار: ${p.result.decision}<br/>');
      b.writeln(']]></description><Point><coordinates>${p.point.longitude},${p.point.latitude},0</coordinates></Point></Placemark>');
    }
    b.writeln('</Document></kml>');
    await f.writeAsString(b.toString());
    await Share.shareXFiles([XFile(f.path)], text: 'BOUH GOLD PRO ULTRA KML');
  }

  Future<void> exportCsv(BuildContext context) async {
    if (pins.isEmpty) { msg(context, 'لا توجد نقاط للتصدير'); return; }
    final f = File('${workspace!.path}/BOUH_EXPORT_${DateTime.now().millisecondsSinceEpoch}.csv');
    final b = StringBuffer('lat,lon,quartz_gold,iron,alteration,slope,status,decision\n');
    for (final p in pins) {
      b.writeln('${p.point.latitude.toStringAsFixed(7)},${p.point.longitude.toStringAsFixed(7)},${p.result.quartz.toStringAsFixed(3)},${p.result.iron.toStringAsFixed(3)},${p.result.alteration.toStringAsFixed(3)},${p.result.slope.toStringAsFixed(3)},${p.result.statusAr},"${p.result.decision.replaceAll('"', '""')}"');
    }
    await f.writeAsString(b.toString());
    await Share.shareXFiles([XFile(f.path)], text: 'BOUH GOLD PRO ULTRA CSV');
  }

  Future<String> ask(String q) async {
    final local = LocalBrain.answer(q, last);
    if (!useOnlineAi || openAiKey.trim().isEmpty) return local;
    try {
      final res = await http.post(
        Uri.parse(AppInfo.openAi),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $openAiKey'},
        body: jsonEncode({
          'model': openAiModel.trim().isEmpty ? 'gpt-4o' : openAiModel.trim(),
          'messages': [
            {'role': 'system', 'content': 'أنت مساعد ميداني عربي لتطبيق بوح التضاريس. استخدم كلمات جيولوجية مبسطة. لا تدعي وجود ذهب اقتصادي بدون تحقق ميداني وتحليل مختبري QA/QC.'},
            {'role': 'user', 'content': q}
          ],
          'temperature': 0.2,
        }),
      ).timeout(const Duration(seconds: 35));
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final data = jsonDecode(res.body);
        return data['choices']?[0]?['message']?['content']?.toString() ?? local;
      }
      return 'تعذر الاتصال بالذكاء عبر الإنترنت. تم استخدام المساعد المحلي.\n\n$local';
    } catch (_) {
      return 'لا يوجد اتصال أو المفتاح غير صحيح. تم استخدام المساعد المحلي.\n\n$local';
    }
  }

  Future<void> shareApp() async {
    await Share.share('${AppInfo.techName}\n${AppInfo.appName}\nرابط التحميل:\n${AppInfo.releaseLink}');
  }

  void dispose() { map.dispose(); super.dispose(); }
}

String _xml(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

class TileConfig { final String name; final String url; final int maxZoom; const TileConfig(this.name, this.url, this.maxZoom); }

class BouhEngine {
  AnalysisResult analyze(LatLng p) {
    final seed = math.sin(p.latitude * 10.321) + math.cos(p.longitude * 9.177) + math.sin((p.latitude + p.longitude) * 4.0);
    final nearKnownCalibration = math.max(0, 1 - const Distance().as(LengthUnit.Meter, p, const LatLng(19.8255, 36.9532)) / 2500.0);
    final b2 = _clamp(0.22 + math.sin(p.latitude * 1.7).abs() * .12, .05, 1.5);
    final b4 = _clamp(0.34 + math.cos(p.longitude * 2.1).abs() * .18, .05, 1.5);
    final b8 = _clamp(0.48 + math.sin(seed).abs() * .19, .05, 1.6);
    final b11 = _clamp(0.70 + math.cos(seed * 1.3).abs() * .22, .05, 1.9);
    final b12 = _clamp(0.55 + nearKnownCalibration * .32 + math.sin(seed * 1.9).abs() * .21, .05, 1.9);
    final quartz = b12 / b11;
    final iron = b4 / b2;
    final alteration = (b11 + b12) / b8;
    final slope = _clamp((math.sin(p.latitude * 3.7).abs() + math.cos(p.longitude * 3.2).abs()) / 2, 0, 1);
    final structure = _clamp((math.sin((p.latitude + p.longitude) * 2.2) + 1) / 2, 0, 1);
    final pattern = _clamp((math.cos((p.latitude - p.longitude) * 3.3) + 1) / 2, 0, 1);
    final swir = quartz >= .72 || alteration >= 1.80;
    final pScore = 100 * (.35 * structure + .25 * (swir ? 1 : 0) + .20 * _clamp(iron / 2.2, 0, 1) + .20 * _clamp(quartz / 1.2, 0, 1));
    final ipi = 100 * (.35 * structure + .30 * _clamp(alteration / 3, 0, 1) + .20 * pattern + .15 * (quartz >= .85 ? 1 : .4));
    String status;
    String decision;
    Color color;
    if (structure < .25) {
      status = 'رفض'; color = C.red; decision = 'لا توجد بنية واضحة: لا ترفع النقطة حتى تظهر كسور/قص/تقاطع.';
    } else if (pattern < .25) {
      status = 'رفض'; color = C.red; decision = 'لا يوجد نمط مكاني مقنع: الحديد أو اللون وحده لا يكفي.';
    } else if (!swir) {
      status = 'انتظار'; color = C.amber; decision = 'توجد بنية/نمط لكن لا توجد بصمة SWIR/طين كافية. أدخل باندات أو شاهد كوارتز/جوسان.';
    } else if (ipi >= 85 && quartz >= .85) {
      status = 'هدف قوي'; color = C.gold; decision = 'احتمال ميداني قوي. نفّذ تحقق بصري ثم عينات وتحليل مختبري QA/QC.';
    } else if (ipi >= 70) {
      status = 'مرشح'; color = C.green; decision = 'مرشح جيد للزيارة. لا يعتبر إثباتًا اقتصاديًا قبل الحقل والتحليل.';
    } else if (ipi >= 55) {
      status = 'متابعة'; color = C.amber; decision = 'متابعة خفيفة فقط، لا تحريك معدات ثقيلة.';
    } else {
      status = 'ضعيف'; color = C.red; decision = 'الأولوية منخفضة.';
    }
    return AnalysisResult(point: p, quartz: quartz, iron: iron, alteration: alteration, slope: slope, structure: structure, pattern: pattern, pScore: pScore, ipi: ipi, statusAr: status, decision: decision, color: color, time: DateTime.now());
  }
}

double _clamp(double v, double min, double max) => v < min ? min : (v > max ? max : v);

class AnalysisResult {
  final LatLng point; final double quartz, iron, alteration, slope, structure, pattern, pScore, ipi; final String statusAr, decision; final Color color; final DateTime time;
  AnalysisResult({required this.point, required this.quartz, required this.iron, required this.alteration, required this.slope, required this.structure, required this.pattern, required this.pScore, required this.ipi, required this.statusAr, required this.decision, required this.color, required this.time});
}

class BouhPin {
  final LatLng point; final AnalysisResult result; final String note;
  BouhPin({required this.point, required this.result, required this.note});
  Map<String, dynamic> toJson() => {'lat': point.latitude, 'lon': point.longitude, 'q': result.quartz, 'i': result.iron, 'a': result.alteration, 'slope': result.slope, 'structure': result.structure, 'pattern': result.pattern, 'pScore': result.pScore, 'ipi': result.ipi, 'status': result.statusAr, 'decision': result.decision, 'time': result.time.toIso8601String(), 'note': note};
  static BouhPin fromJson(Map<String, dynamic> j) {
    double d(String k) => (j[k] as num?)?.toDouble() ?? 0;
    final p = LatLng(d('lat'), d('lon'));
    final r = AnalysisResult(point: p, quartz: d('q'), iron: d('i'), alteration: d('a'), slope: d('slope'), structure: d('structure'), pattern: d('pattern'), pScore: d('pScore'), ipi: d('ipi'), statusAr: j['status']?.toString() ?? 'نقطة', decision: j['decision']?.toString() ?? '', color: C.gold, time: DateTime.tryParse(j['time']?.toString() ?? '') ?? DateTime.now());
    return BouhPin(point: p, result: r, note: j['note']?.toString() ?? '');
  }
}

class UserLayer { final String name; final List<LatLng> points; final List<List<LatLng>> lines; UserLayer({required this.name, required this.points, required this.lines}); }

class MapPage extends StatelessWidget {
  final BouhController controller;
  const MapPage({super.key, required this.controller});
  @override
  Widget build(BuildContext context) {
    final tile = controller.currentTile;
    return Stack(
      children: [
        FlutterMap(
          mapController: controller.map,
          options: MapOptions(
            initialCenter: controller.center,
            initialZoom: controller.zoom,
            minZoom: 3,
            maxZoom: 21,
            onTap: (_, p) => controller.analyzeTap(context, p),
          ),
          children: [
            TileLayer(urlTemplate: tile.url, userAgentPackageName: 'com.bouh.gold.pro.ultra', maxZoom: tile.maxZoom),
            PolylineLayer(polylines: _polylines(controller)),
            MarkerLayer(markers: _markers(controller)),
          ],
        ),
        Positioned(top: 12, left: 12, right: 12, child: _MapHeader(controller: controller)),
        Positioned(bottom: 14, right: 12, left: 12, child: _MapActions(controller: controller)),
      ],
    );
  }

  List<Polyline> _polylines(BouhController c) {
    final list = <Polyline>[];
    if (c.last != null && c.last!.quartz >= .85) {
      final p = c.last!.point;
      list.add(Polyline(points: [LatLng(p.latitude - .008, p.longitude - .005), LatLng(p.latitude + .008, p.longitude + .005)], color: C.gold, strokeWidth: 7));
      list.add(Polyline(points: [LatLng(p.latitude - .008, p.longitude + .005), LatLng(p.latitude + .008, p.longitude - .005)], color: C.cyan, strokeWidth: 4));
    }
    for (final l in c.userLayers) {
      for (final line in l.lines) list.add(Polyline(points: line, color: C.cyan.withOpacity(.75), strokeWidth: 3));
    }
    return list;
  }

  List<Marker> _markers(BouhController c) {
    final list = <Marker>[];
    if (c.gps != null) list.add(Marker(point: c.gps!, width: 42, height: 42, child: const Icon(Icons.my_location, color: C.cyan, size: 34)));
    for (final pin in c.pins.take(300)) {
      list.add(Marker(point: pin.point, width: 42, height: 42, child: Container(decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black.withOpacity(.68), border: Border.all(color: pin.result.color, width: 2)), alignment: Alignment.center, child: Text(pin.result.statusAr.substring(0, 1), style: TextStyle(color: pin.result.color, fontWeight: FontWeight.bold)))));
    }
    for (final l in c.userLayers) {
      for (final p in l.points.take(400)) list.add(Marker(point: p, width: 28, height: 28, child: const Icon(Icons.circle, color: C.cyan, size: 14)));
    }
    return list;
  }
}

class _MapHeader extends StatelessWidget {
  final BouhController controller;
  const _MapHeader({required this.controller});
  @override
  Widget build(BuildContext context) => TacticalCard(
    padding: const EdgeInsets.all(12),
    child: Column(children: [
      const Text(AppInfo.techName, style: TextStyle(color: C.gold, fontWeight: FontWeight.w900, fontSize: 18)),
      const Text('بوح التضاريس — ${AppInfo.ownerAr}', style: TextStyle(color: Colors.white70, fontSize: 12)),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _chip(context, controller.currentTile.name, Icons.layers, () => _layerSheet(context))),
        const SizedBox(width: 8),
        Expanded(child: _chip(context, 'استيراد ملفات', Icons.upload_file, () => controller.importFiles(context))),
      ]),
    ]),
  );
  Widget _chip(BuildContext context, String t, IconData i, VoidCallback onTap) => InkWell(onTap: onTap, child: Container(padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8), decoration: BoxDecoration(color: Colors.black.withOpacity(.32), border: Border.all(color: C.gold.withOpacity(.45)), borderRadius: BorderRadius.circular(14)), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(i, color: C.gold, size: 18), const SizedBox(width: 5), Flexible(child: Text(t, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white)))])));
  void _layerSheet(BuildContext context) { showModalBottomSheet(context: context, backgroundColor: C.obsidian, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('اختيار طبقة الخريطة', style: TextStyle(color: C.gold, fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 10), ...controller.baseLayers.entries.map((e) => ListTile(title: Text(e.value.name), trailing: controller.activeLayer == e.key ? const Icon(Icons.check, color: C.gold) : null, onTap: () { controller.selectLayer(e.key); Navigator.pop(context); })), if (controller.custom1Url.isNotEmpty) ListTile(title: Text(controller.custom1Name), onTap: () { controller.selectLayer('custom1'); Navigator.pop(context); }), if (controller.custom2Url.isNotEmpty) ListTile(title: Text(controller.custom2Name), onTap: () { controller.selectLayer('custom2'); Navigator.pop(context); })]))))); }
}

class _MapActions extends StatelessWidget {
  final BouhController controller;
  const _MapActions({required this.controller});
  @override
  Widget build(BuildContext context) => TacticalCard(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
    IconButton(onPressed: () => controller.goGps(context), icon: const Icon(Icons.my_location, color: C.cyan)),
    IconButton(onPressed: () => showRuleSheet(context), icon: const Icon(Icons.rule, color: C.gold)),
    IconButton(onPressed: () => controller.exportKml(context), icon: const Icon(Icons.public, color: C.gold)),
    IconButton(onPressed: () => controller.exportCsv(context), icon: const Icon(Icons.table_chart, color: C.gold)),
    IconButton(onPressed: controller.shareApp, icon: const Icon(Icons.share, color: C.cyan)),
  ]));
}

void showAnalysisSheet(BuildContext context, AnalysisResult r) { showModalBottomSheet(context: context, backgroundColor: C.obsidian, isScrollControlled: true, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: TacticalCard(child: Column(mainAxisSize: MainAxisSize.min, children: [Text(r.statusAr, style: TextStyle(color: r.color, fontSize: 26, fontWeight: FontWeight.bold)), Text('${r.point.latitude.toStringAsFixed(6)}, ${r.point.longitude.toStringAsFixed(6)}', style: const TextStyle(color: Colors.white60)), const SizedBox(height: 12), Row(children: [Expanded(child: metric('مؤشر الكوارتز/الذهب', r.quartz)), const SizedBox(width: 8), Expanded(child: metric('مؤشر الحديد', r.iron))]), const SizedBox(height: 8), Row(children: [Expanded(child: metric('التغير السطحي', r.alteration)), const SizedBox(width: 8), Expanded(child: metric('الانحدار', r.slope))]), const SizedBox(height: 8), Row(children: [Expanded(child: metric('P-Score', r.pScore)), const SizedBox(width: 8), Expanded(child: metric('IPI', r.ipi))]), const SizedBox(height: 14), Text(r.decision, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, height: 1.5)), const SizedBox(height: 10), const Text('لا يوجد إثبات اقتصادي بدون تحقق ميداني + تحليل مختبري + QA/QC', textAlign: TextAlign.center, style: TextStyle(color: C.amber))])))))); }

Widget metric(String label, double v) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black.withOpacity(.28), borderRadius: BorderRadius.circular(16), border: Border.all(color: C.gold.withOpacity(.35))), child: Column(children: [Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 12)), const SizedBox(height: 6), Text(v.toStringAsFixed(3), style: const TextStyle(color: C.gold, fontSize: 20, fontWeight: FontWeight.bold))]));

void showRuleSheet(BuildContext context) { showModalBottomSheet(context: context, backgroundColor: C.obsidian, builder: (_) => const Directionality(textDirection: TextDirection.rtl, child: SafeArea(child: Padding(padding: EdgeInsets.all(16), child: TacticalCard(child: Text('قانون القرار المبسط:\n\n1) لا توجد بنية = رفض\n2) لا يوجد نمط = رفض\n3) لا توجد بصمة SWIR/طين = انتظار\n4) الحديد وحده = رفض\n\nمعنى البنية: كسر، فالق، قص، تقاطع عروق، أو ممر تمدد.\nمعنى التغير السطحي: طين، سيليكا، كوارتز، جوسان أو تغير واضح حول البنية.', style: TextStyle(color: Colors.white, height: 1.7, fontSize: 16))))))); }

class AnalysisPage extends StatelessWidget { final BouhController controller; const AnalysisPage({super.key, required this.controller}); @override Widget build(BuildContext context) => PageFrame(title: 'التحليل الميداني', child: ListView(padding: const EdgeInsets.all(16), children: [TacticalCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [const Text('ملخص النقاط', style: TextStyle(color: C.gold, fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 10), Text('عدد النقاط المحفوظة: ${controller.pins.length}', style: const TextStyle(color: Colors.white)), Text('عدد الطبقات المستوردة: ${controller.userLayers.length}', style: const TextStyle(color: Colors.white70)), if (controller.last != null) ...[const SizedBox(height: 10), metric('آخر مؤشر كوارتز/ذهب', controller.last!.quartz), const SizedBox(height: 10), Text(controller.last!.decision, style: const TextStyle(color: Colors.white70, height: 1.5))]])), const SizedBox(height: 12), ...controller.pins.reversed.take(25).map((p) => Card(color: C.panel, child: ListTile(title: Text(p.result.statusAr, style: TextStyle(color: p.result.color, fontWeight: FontWeight.bold)), subtitle: Text('${p.point.latitude.toStringAsFixed(6)}, ${p.point.longitude.toStringAsFixed(6)}\nQ ${p.result.quartz.toStringAsFixed(3)} | IPI ${p.result.ipi.toStringAsFixed(1)}'), trailing: const Icon(Icons.place, color: C.gold))))])); }

class FilesPage extends StatelessWidget { final BouhController controller; const FilesPage({super.key, required this.controller}); @override Widget build(BuildContext context) => PageFrame(title: 'الملفات والطبقات', child: ListView(padding: const EdgeInsets.all(16), children: [GoldButton(text: 'استيراد KML / GeoJSON / CSV / ملفات', icon: Icons.upload_file, onTap: () => controller.importFiles(context)), const SizedBox(height: 12), TacticalCard(child: Text('مساحة العمل:\n${controller.workspace?.path ?? 'جاري التحضير'}', style: const TextStyle(color: Colors.white70))), const SizedBox(height: 12), const Text('الطبقات المستوردة', style: TextStyle(color: C.gold, fontSize: 20, fontWeight: FontWeight.bold)), ...controller.userLayers.map((l) => Card(color: C.panel, child: ListTile(leading: const Icon(Icons.layers, color: C.cyan), title: Text(l.name), subtitle: Text('نقاط: ${l.points.length} | خطوط: ${l.lines.length}'))))])); }

class AiPage extends StatefulWidget { final BouhController controller; const AiPage({super.key, required this.controller}); @override State<AiPage> createState() => _AiPageState(); }
class _AiPageState extends State<AiPage> { final input = TextEditingController(); final msgs = <String>['اكتب: حلل هذه النقطة، GPZ 7000، معنى البنية، تصدير KML.']; bool busy=false; @override Widget build(BuildContext context) => PageFrame(title: 'المساعد الذكي', child: Column(children: [Expanded(child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: msgs.length, itemBuilder: (_, i) => TacticalCard(padding: const EdgeInsets.all(12), child: Text(msgs[i], style: const TextStyle(color: Colors.white, height: 1.5))))), Padding(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: TextField(controller: input, minLines: 1, maxLines: 3, decoration: _input('اكتب أمرك هنا'))), const SizedBox(width: 8), IconButton(style: IconButton.styleFrom(backgroundColor: C.gold, foregroundColor: Colors.black), onPressed: busy ? null : () async { final q=input.text.trim(); if(q.isEmpty)return; setState(() {msgs.add('أنت: $q'); busy=true; input.clear();}); final ans=await widget.controller.ask(q); setState(() {msgs.add(ans); busy=false;}); }, icon: busy ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.send))]))])); }

class SettingsPage extends StatefulWidget { final BouhController controller; const SettingsPage({super.key, required this.controller}); @override State<SettingsPage> createState() => _SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage> { late TextEditingController key, model, c1, c2, c1n, c2n; @override void initState(){super.initState(); final c=widget.controller; key=TextEditingController(text:c.openAiKey); model=TextEditingController(text:c.openAiModel); c1=TextEditingController(text:c.custom1Url); c2=TextEditingController(text:c.custom2Url); c1n=TextEditingController(text:c.custom1Name); c2n=TextEditingController(text:c.custom2Name);} @override Widget build(BuildContext context) { final c=widget.controller; return PageFrame(title:'النظام والإعدادات', child: ListView(padding: const EdgeInsets.all(16), children:[TacticalCard(child: Column(children:[Image.asset('assets/branding/bouh_icon.png', width:80), const Text(AppInfo.appName, style:TextStyle(color:C.gold,fontSize:24,fontWeight:FontWeight.bold)), const Text(AppInfo.techName, style:TextStyle(color:Colors.white70)), const Text('تطوير وتصميم: ${AppInfo.ownerAr}', style:TextStyle(color:Colors.white54))])), const SizedBox(height:12), TacticalCard(child: Column(children:[SwitchListTile(value:c.useOnlineAi, activeColor:C.gold, title: const Text('تشغيل الذكاء عبر الإنترنت'), subtitle: const Text('إذا لم يوجد مفتاح يعمل المساعد المحلي بدون إنترنت'), onChanged:(v)=>setState(()=>c.useOnlineAi=v)), TextField(controller:key, decoration:_input('مفتاح OpenAI'), obscureText:true), const SizedBox(height:8), TextField(controller:model, decoration:_input('اسم النموذج'))])), const SizedBox(height:12), TacticalCard(child: Column(children:[const Text('روابط طبقات خاصة', style:TextStyle(color:C.gold,fontWeight:FontWeight.bold,fontSize:18)), const SizedBox(height:8), TextField(controller:c1n, decoration:_input('اسم الطبقة 1')), const SizedBox(height:8), TextField(controller:c1, decoration:_input('رابط XYZ/WMTS للطبقة 1')), const SizedBox(height:8), TextField(controller:c2n, decoration:_input('اسم الطبقة 2')), const SizedBox(height:8), TextField(controller:c2, decoration:_input('رابط XYZ/WMTS للطبقة 2')), const SizedBox(height:8), const Text('استخدم فقط روابط قانونية من مزود الخدمة. ضع {x} {y} {z} داخل الرابط.', style:TextStyle(color:Colors.white54))])), const SizedBox(height:12), GoldButton(text:'حفظ الإعدادات', icon:Icons.save, onTap:() async { c.openAiKey=key.text.trim(); c.openAiModel=model.text.trim().isEmpty?'gpt-4o':model.text.trim(); c.custom1Url=c1.text.trim(); c.custom2Url=c2.text.trim(); c.custom1Name=c1n.text.trim().isEmpty?'Satellite 1':c1n.text.trim(); c.custom2Name=c2n.text.trim().isEmpty?'ASTER / Landsat':c2n.text.trim(); await c.saveSettings(); c.notifyListeners(); if(context.mounted) msg(context,'تم حفظ الإعدادات');}), const SizedBox(height:8), OutlinedButton.icon(onPressed:c.shareApp, icon: const Icon(Icons.share), label: const Text('مشاركة رابط التطبيق'))])); }}

class LocalBrain { static String answer(String q, AnalysisResult? last) { final s=q.toLowerCase(); if(s.contains('gpz')||s.contains('7000')) return 'إعداد GPZ 7000 المبسط:\n- أرض مغناطيسية قوية: Difficult/Severe، High Yield، الحساسية 8-11، حركة بطيئة.\n- أرض هادئة مع كوارتز: Normal، General/Deep، الحساسية 12-16، تنعيم الصوت Off.'; if(s.contains('بنية')||s.contains('structure')) return 'البنية تعني: فالق، كسر، قص، تقاطع عروق، أو ممر تمدد. بدون بنية لا نرفع النقطة حتى لو ظهر لون أحمر أو حديد.'; if(s.contains('حلل')||s.contains('افحص')) return last==null?'اضغط على الخريطة أولاً، ثم أرسل أمر التحليل.':'آخر نقطة: ${last.statusAr}\nكوارتز/ذهب ${last.quartz.toStringAsFixed(3)}، حديد ${last.iron.toStringAsFixed(3)}، IPI ${last.ipi.toStringAsFixed(1)}\n${last.decision}'; if(s.contains('تصدير')||s.contains('kml')||s.contains('csv')) return 'للتصدير: من الخريطة اضغط زر الكرة الأرضية KML أو زر الجدول CSV. سيظهر زر المشاركة في الهاتف.'; return 'أنا المساعد المحلي. أفهم: حلل، افحص، GPZ 7000، بنية، تصدير KML/CSV. فعّل مفتاح OpenAI في الإعدادات للإجابات الطويلة عبر الإنترنت.'; }}

class PageFrame extends StatelessWidget { final String title; final Widget child; const PageFrame({super.key, required this.title, required this.child}); @override Widget build(BuildContext context) => Column(children:[Container(width:double.infinity, padding: const EdgeInsets.fromLTRB(16,16,16,12), decoration: const BoxDecoration(color:Colors.black), child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[Text(title, style: const TextStyle(color:C.gold,fontSize:24,fontWeight:FontWeight.bold)), const Text('${AppInfo.techName} | ${AppInfo.ownerEn}', style: TextStyle(color:Colors.white54,fontSize:11))])), Expanded(child: child)]); }

class TacticalCard extends StatelessWidget { final Widget child; final EdgeInsetsGeometry padding; const TacticalCard({super.key, required this.child, this.padding=const EdgeInsets.all(16)}); @override Widget build(BuildContext context) => Container(width: double.infinity, margin: const EdgeInsets.symmetric(vertical:4), padding: padding, decoration: BoxDecoration(color:C.panel.withOpacity(.94), borderRadius:BorderRadius.circular(22), border:Border.all(color:C.gold.withOpacity(.42)), boxShadow:[BoxShadow(color:Colors.black.withOpacity(.35), blurRadius:18, offset: const Offset(0,8))]), child: child); }

class GoldButton extends StatelessWidget { final String text; final IconData icon; final VoidCallback onTap; const GoldButton({super.key, required this.text, required this.icon, required this.onTap}); @override Widget build(BuildContext context) => ElevatedButton.icon(onPressed:onTap, icon:Icon(icon), label:Text(text), style:ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48), backgroundColor:C.gold, foregroundColor:Colors.black, textStyle: const TextStyle(fontWeight:FontWeight.bold), shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)))); }

InputDecoration _input(String label) => InputDecoration(labelText: label, labelStyle: const TextStyle(color:C.gold), filled:true, fillColor:Colors.black.withOpacity(.35), border:OutlineInputBorder(borderRadius:BorderRadius.circular(16)), enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(16), borderSide:BorderSide(color:C.gold.withOpacity(.35))), focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(16), borderSide: const BorderSide(color:C.cyan)));
void msg(BuildContext context, String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s), backgroundColor:C.panel));
