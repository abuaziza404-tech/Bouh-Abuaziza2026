# BUILD_REPORT.md — v13.1 Professional Radar UX Patch

## ملخص الإصدار

- UX cleanup للصفحة الرئيسية والأقسام الميدانية.
- Radar follows map center افتراضيًا.
- radius selector واضح: 100m / 300m / 500m / 1000m.
- improved live score meter تحت الخريطة مباشرة.
- moved MBTiles/PMTiles to drawer مغلق افتراضيًا.
- preserved ground_cells = 4303.
- preserved truth_status = partial_raw_grid_landsat_dem_not_full_spectral.
- preserved live-score logic, weights, and field names.

## v13.2 Final Radar UX Android Ready corrections

- BUILD_REPORT يبدأ الآن بعنوان v13.1 Professional Radar UX Patch.
- crosshair ثابت ومسمى بوضوح عبر classes:
  - map-center-crosshair
  - radar-crosshair
- GitHub Actions workflow renamed to:
  - BOUH Android Build From ZIP
- workflow يحتوي على:
  - postcss
  - autoprefixer
  - node ./node_modules/vite/bin/vite.js build
  - node ./node_modules/@capacitor/cli/bin/capacitor sync android
- package.json build script أصبح:
  - vite build
- أضيف build:strict:
  - tsc && vite build
- Android icon and splash resources are present in mipmap-* and drawable* resources.
- لا توجد نصوص تثبيت تجريبية في الصفحة الرئيسية.

## الحدود العلمية

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
Field-check only
```


## سجل تقني مختصر

# GitHub Actions

The workflow `.github/workflows/android-build-from-zip.yml` was updated for v13.1 and includes dependency repair for Capacitor/Vitest before `npm run build`.

Expected GitHub Actions outputs after running on GitHub:

```text
APK Debug
AAB Release
CHECKSUMS_ANDROID.txt
BOUH_v13_1_INSTALLABLE_ANDROID_ARTIFACTS.zip
```

## v13.2 local verification and Android build status

### Local checks

```text
npm install = rc 0
npm install build dependencies = rc 0
npm run build = rc 0
npm run build:strict = rc 0
node ./node_modules/@capacitor/cli/bin/capacitor sync android = rc 0
validate_v12_5_analytical_pack = rc 0
test_live_score_repository = rc 0 / 3 passed
test_v12_6_ready_analyzed_grid = rc 0 / 1 passed
```

### APK/AAB local build attempt

```text
./gradlew assembleDebug = rc 1
./gradlew bundleRelease = rc 1
```

Local environment blocker:

```text
java.net.UnknownHostException: services.gradle.org
```

The GitHub Actions workflow is updated to build the APK/AAB on a connected runner and upload:

```text
APK Debug
AAB Release
CHECKSUMS_ANDROID.txt
BOUH_v13_2_INSTALLABLE_ANDROID_ARTIFACTS.zip
```

### v13.2 field UX confirmation checklist

```text
MBTiles/PMTiles drawer is closed by default.
Live Ground Score is placed directly under the map.
Map moveend updates coordinates when center-follow mode is enabled.
Radius selector is visible: 100m / 300m / 500m / 1000m.
Indicator details are collapsed by default.
Crosshair classes exist: map-center-crosshair and radar-crosshair.
Android icon resources exist in mipmap-* and drawable*.
```
