# DATA_IMPORT_GUIDE.md

## الملفات المدعومة

- GeoTIFF/TIFF/JP2: تحليل Raster/DEM/Bands.
- ZIP: أرشيف بيانات يفك بأمان.
- GeoJSON/JSON/CSV: بيانات منظمة.
- MBTiles/PMTiles: خرائط Offline.
- KML/KMZ/PNG/JPG: سياق بصري فقط.

## Workflow

Upload → Inspect → Classify → Validate → Store → Analyze → Report

## قيود

- KML/KMZ/PNG/JPG ليست دليلاً طيفيًا رقميًا.
- لا يتم تنفيذ أي ملف مرفوع.
- ZIP يحظر path traversal.
- أي رقم بلا مصدر موثق يتم منعه أو وسمه بعدم كفاية البيانات.
