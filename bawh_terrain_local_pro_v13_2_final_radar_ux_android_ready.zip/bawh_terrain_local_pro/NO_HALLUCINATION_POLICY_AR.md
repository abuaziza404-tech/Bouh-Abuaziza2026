# سياسة منع الهلوسة في بيانات بوح

## ممنوع
- إنتاج مؤشر طيفي من PNG/JPG/KMZ/KML.
- اعتبار Browser Images باندات.
- كتابة Gold proof.
- كتابة عمق أو نسبة ذهب.
- تحويل support score إلى حقيقة ميدانية.
- منح Class A بدون Structure + Alteration/Clay/Silica + Confirmation.

## مسموح
- عرض النقاط الرسمية كـ Field-check.
- عرض نقاط الدعم النسبي كـ Screening.
- حساب المؤشرات من GeoTIFF خام فقط.
- استخدام DEM للتضاريس.
- استخدام PNG/KMZ كسياق بصري فقط.

## صيغة كل نتيجة
كل نتيجة يجب أن تحمل:
- source
- evidence_class
- truth_status
- calculation_allowed
- limitation_ar


## v12.2

تمت إضافة Popup داخل MapLibre لكل نقطة خفيفة يوضح source وtruth_status وlimitation_ar وproof_status. لا تعرض الواجهة أي Gold Target.
