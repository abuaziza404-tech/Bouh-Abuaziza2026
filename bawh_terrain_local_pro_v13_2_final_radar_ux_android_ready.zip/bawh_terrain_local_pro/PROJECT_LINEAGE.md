# PROJECT_LINEAGE.md

## النسخة المعتمدة

- `bawh_terrain_local_pro_v11_maps_emergency.zip` هي النسخة المعتمدة كأساس الإنتاج الحالي.
- تم فتحها وتثبيتها كأساس v12.

## النسخة الاحتياطية

- `bawh_terrain_local_pro_v10_final_release.zip` نسخة احتياطية مرجعية فقط.
- تم استخدام مفاهيم release من v10 عند الحاجة: أدلة Android Release، scripts، checklist، release notes.

## النسخ التاريخية

v3/v5/v6/v7/v8/v9 مراحل تاريخية للتطوير ولا تُستخدم كأساس إنتاجي.

## ميزات v10 المدمجة في v12

- بنية Android Release scripts.
- Release signing templates.
- QA checklist.
- Release notes.
- Android build guidance.

## التزام الصدق العلمي

بوح التضاريس منصة تحليل تضاريس وطبقات سطحية وسلامة ميدانية. النتائج احتمالية وتحتاج تحقق ميداني. النظام لا يثبت وجود ذهب أو دفائن أو أهداف تحت الأرض.


## v12.1

تم دمج BOUH_RADAR_LIGHTWEIGHT_INTELLIGENCE_PACK_v12_1_FIXED.zip فوق v12 دون البدء من الصفر. الحزمة تضيف panel خفيف للرادار وواجهات `/bouh/*` وسياسة أدلة تمنع الهلوسة.
