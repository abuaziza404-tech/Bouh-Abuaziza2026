# Release Notes — بوح التضاريس v10 Final

المطور: أحمد أبوعزيزة الرشيدي

## Highlights

- منظومة Android Field كاملة.
- خرائط Esri Satellite مع Offline Cache.
- MBTiles وPMTiles.
- مدير تنزيل مناطق Offline.
- رادار MapLibre.
- Safety Intelligence.
- AI Queue.
- PIN/Biometrics.
- JWT/RBAC.
- Docker + CI + Release signing.

## Known build note

لم يتم تضمين مجلد `apps/web/android` الناتج من Capacitor لأنه يُنشأ بعد:

```bash
cd apps/web
npm install
npm run android:init
```

هذا يحافظ على حجم الحزمة ويضمن توليد مشروع Android بما يوافق إصدار Capacitor المحلي.
