# بوح التضاريس Capacitor release rules
-keep class com.getcapacitor.** { *; }
-keep class com.capacitorjs.** { *; }
-keep class org.apache.cordova.** { *; }
-keepattributes *Annotation*
-dontwarn com.getcapacitor.**
