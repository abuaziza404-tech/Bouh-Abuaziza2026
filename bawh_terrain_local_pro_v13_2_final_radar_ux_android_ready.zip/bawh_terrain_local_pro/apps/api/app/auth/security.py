from datetime import datetime, timedelta, timezone
import base64
import hashlib
import hmac
import json
import os
import secrets
from typing import Any


TOKEN_TTL_HOURS = 24


def get_secret_key() -> str:
    return os.getenv("APP_SECRET_KEY", "change-me-local-development-secret")


def hash_password(password: str, salt: str | None = None) -> str:
    if salt is None:
        salt = secrets.token_hex(16)

    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        120_000,
    ).hex()

    return f"pbkdf2_sha256${salt}${digest}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algorithm, salt, expected = stored.split("$", 2)
    except ValueError:
        return False

    if algorithm != "pbkdf2_sha256":
        return False

    calculated = hash_password(password, salt).split("$", 2)[2]
    return hmac.compare_digest(calculated, expected)


def create_token(payload: dict[str, Any], ttl_hours: int = TOKEN_TTL_HOURS) -> str:
    now = datetime.now(timezone.utc)
    body = {
        **payload,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(hours=ttl_hours)).timestamp()),
    }

    header = {"alg": "HS256", "typ": "JWT-Lite"}
    header_b64 = b64url_json(header)
    body_b64 = b64url_json(body)
    signature = sign(f"{header_b64}.{body_b64}")

    return f"{header_b64}.{body_b64}.{signature}"


def decode_token(token: str) -> dict[str, Any]:
    try:
        header_b64, body_b64, signature = token.split(".", 2)
    except ValueError as exc:
        raise ValueError("token_format") from exc

    expected = sign(f"{header_b64}.{body_b64}")

    if not hmac.compare_digest(signature, expected):
        raise ValueError("token_signature")

    payload = json.loads(b64url_decode(body_b64).decode("utf-8"))
    exp = int(payload.get("exp", 0))

    if exp < int(datetime.now(timezone.utc).timestamp()):
        raise ValueError("token_expired")

    return payload


def require_role(payload: dict[str, Any], allowed_roles: set[str]) -> None:
    role = str(payload.get("role") or "")

    if role not in allowed_roles:
        raise PermissionError("role_not_allowed")


def sign(value: str) -> str:
    digest = hmac.new(
        get_secret_key().encode("utf-8"),
        value.encode("utf-8"),
        hashlib.sha256,
    ).digest()

    return b64url_bytes(digest)


def b64url_json(value: dict[str, Any]) -> str:
    return b64url_bytes(json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))


def b64url_bytes(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)
