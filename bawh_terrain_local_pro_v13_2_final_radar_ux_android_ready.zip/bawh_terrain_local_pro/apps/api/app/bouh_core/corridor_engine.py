REGIONAL_ROLES = ["regional_south", "regional_center", "regional_north"]
ALL_ROLES = [
    "regional_south",
    "regional_center",
    "regional_north",
    "port_partial",
    "local_target_west",
    "local_target_east",
    "abuziza_local_app",
]

ROLE_LABELS_AR = {
    "regional_south": "النطاق الجنوبي",
    "regional_center": "نطاق الوسط",
    "regional_north": "النطاق الشمالي",
    "port_partial": "Port الجزئي",
    "local_target_west": "الهدف المحلي الغربي",
    "local_target_east": "الهدف المحلي الشرقي",
    "abuziza_local_app": "سجل أبو عزيزة المحلي",
}


def build_corridor_decision(items: list[dict]) -> dict:
    by_role = {item.get("role"): item for item in items if item.get("role")}
    missing = [role for role in REGIONAL_ROLES if role not in by_role]
    has_center = "regional_center" in by_role

    if not missing:
        status = "Regional Corridor"
        recommendation = "الممر الإقليمي مكتمل جنوب → وسط → شمال. استخدم نطاق الوسط كحلقة ربط أساسية وقارن المؤشرات السطحية."
        best = "regional_center"
    elif has_center:
        status = "Partial Corridor"
        recommendation = "نطاق الوسط موجود، لكن الممر يحتاج استكمال القطاعات المفقودة قبل أي قرار قوي."
        best = "regional_center"
    else:
        status = "Disconnected"
        recommendation = "لا توجد حلقة ربط مركزية كافية؛ استخدم البيانات كسياق محلي فقط."
        best = next((role for role in REGIONAL_ROLES if role in by_role), None)

    comparison = []
    for role in ALL_ROLES:
        item = by_role.get(role)
        if not item:
            comparison.append({"role": role, "label_ar": ROLE_LABELS_AR[role], "status": "missing"})
            continue
        comparison.append({
            "role": role,
            "label_ar": ROLE_LABELS_AR[role],
            "status": "present",
            "ndvi_mean": item.get("ndvi_mean"),
            "ndwi_mean": item.get("ndwi_mean"),
            "bsi_mean": item.get("bsi_mean"),
            "ndmi_mean": item.get("ndmi_mean"),
            "note_ar": role_note(role),
        })

    return {
        "corridor_status": status,
        "missing_segments": missing,
        "best_connected_segment": best,
        "regional_comparison": comparison,
        "recommendation_ar": recommendation,
    }


def role_note(role: str) -> str:
    if role == "port_partial":
        return "سياق جزئي فقط."
    if role in {"local_target_west", "local_target_east"}:
        return "سياق محلي يحتاج تحقق وربط بالممر."
    if role == "abuziza_local_app":
        return "Knowledge Register وليس إثباتًا علميًا وحده."
    if role == "regional_center":
        return "حلقة الربط الأساسية."
    return "قطاع إقليمي."
