from __future__ import annotations

from pathlib import Path
from typing import Any

VISUAL_EXTENSIONS = {".png", ".jpg", ".jpeg", ".kmz", ".kml"}
RASTER_EXTENSIONS = {".tif", ".tiff"}

def classify_file_name(file_name: str) -> dict[str, Any]:
    name = file_name.lower()
    suffix = Path(name).suffix

    if suffix in VISUAL_EXTENSIONS or "browser_images" in name:
        return {
            "evidence_class": "visual_context_only",
            "can_compute_indices": False,
            "can_generate_numeric_score": False,
            "message_ar": "هذا الملف سياق بصري فقط ولا يصلح لحساب مؤشرات طيفية."
        }

    if suffix in RASTER_EXTENSIONS and ("sentinel" in name or "_b02" in name or "_b03" in name or "_b04" in name or "_b08" in name or "_b11" in name or "_b12" in name or "_b8a" in name):
        return {
            "evidence_class": "calculation_grade_sentinel_raw",
            "can_compute_indices": True,
            "can_generate_numeric_score": True,
            "message_ar": "ملف Sentinel خام قابل للحساب إذا اكتملت الباندات والـ metadata."
        }

    if suffix in RASTER_EXTENSIONS and ("lc08" in name or "landsat" in name or "qa_pixel" in name or "qa_radsat" in name):
        return {
            "evidence_class": "calculation_grade_landsat",
            "can_compute_indices": True,
            "can_generate_numeric_score": True,
            "message_ar": "ملف Landsat قابل للحساب مع QA/MTL عند توفرها."
        }

    if suffix in RASTER_EXTENSIONS and ("dem" in name or "srtm" in name or "n19_e036" in name):
        return {
            "evidence_class": "terrain_grade_dem",
            "can_compute_indices": False,
            "can_generate_numeric_score": True,
            "message_ar": "ملف DEM يصلح للتضاريس مثل الميل والظل والتدفق التقريبي."
        }

    if suffix in {".csv", ".json", ".txt"}:
        return {
            "evidence_class": "calculation_grade_registry",
            "can_compute_indices": False,
            "can_generate_numeric_score": False,
            "message_ar": "ملف سجل/تعريف منظم. يستخدم كمرجع أو سجل أدلة حسب محتواه."
        }

    if suffix in {".md", ".docx", ".pdf"}:
        return {
            "evidence_class": "reference_only",
            "can_compute_indices": False,
            "can_generate_numeric_score": False,
            "message_ar": "ملف مرجعي لا يستخدم وحده لحساب مؤشرات رقمية."
        }

    return {
        "evidence_class": "unknown_requires_review",
        "can_compute_indices": False,
        "can_generate_numeric_score": False,
        "message_ar": "ملف غير مصنف ويحتاج مراجعة قبل استخدامه."
    }

def assert_not_visual_for_indices(file_name: str) -> None:
    info = classify_file_name(file_name)
    if info["evidence_class"] == "visual_context_only":
        raise ValueError("Visual context files cannot be used to compute spectral indices.")
