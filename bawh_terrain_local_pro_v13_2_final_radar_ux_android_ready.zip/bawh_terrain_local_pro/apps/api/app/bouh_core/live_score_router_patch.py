# Add these endpoints to apps/api/app/bouh_core/router.py

from app.bouh_core.live_score_repository import live_score, live_score_status

@router.get("/live-score")
def bouh_live_score(lat: float, lng: float, radius: float = 300):
    return live_score(lat, lng, radius)

@router.get("/live-score/status")
def bouh_live_score_status():
    return live_score_status()
