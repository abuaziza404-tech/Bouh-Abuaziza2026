from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

def _candidate_dirs() -> list[Path]:
    env_dir = os.getenv("BOUH_PRECOMPUTED_DIR")
    dirs: list[Path] = []
    if env_dir:
        dirs.append(Path(env_dir))
    # Running inside app container from project root
    dirs.extend([
        Path("/app/data/precomputed"),
        Path.cwd() / "data" / "precomputed",
        Path.cwd().parent / "data" / "precomputed",
        Path(__file__).resolve().parents[4] / "data" / "precomputed",
    ])
    # Deduplicate while preserving order
    seen: set[str] = set()
    out: list[Path] = []
    for d in dirs:
        key = str(d)
        if key not in seen:
            seen.add(key)
            out.append(d)
    return out

def precomputed_dir() -> Path:
    for d in _candidate_dirs():
        if d.exists():
            return d
    # Return the preferred Docker path for clear error messages.
    return Path(os.getenv("BOUH_PRECOMPUTED_DIR", "/app/data/precomputed"))

def read_json(name: str) -> dict[str, Any]:
    path = precomputed_dir() / name
    if not path.exists():
        return {
            "ok": False,
            "error": "missing_precomputed_file",
            "file": name,
            "expected_dir": str(precomputed_dir()),
        }
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return {
            "ok": False,
            "error": "invalid_json",
            "file": name,
            "message": str(exc),
        }

def get_truth_policy() -> dict[str, Any]:
    return read_json("truth_policy.json")

def get_evidence_registry() -> dict[str, Any]:
    return read_json("evidence_registry.json")

def get_regional_zones() -> dict[str, Any]:
    return read_json("regional_zones.json")

def get_official_targets() -> dict[str, Any]:
    return read_json("official_targets_and_screening_points.json")

def get_universal_summary() -> dict[str, Any]:
    return read_json("universal_summary_compact.json")

def get_drive_import_manifest() -> dict[str, Any]:
    return read_json("drive_import_manifest.json")

def get_data_definitions() -> dict[str, Any]:
    return read_json("data_definitions.json")

def get_radar_bootstrap_payload() -> dict[str, Any]:
    existing = read_json("radar_bootstrap.json")
    if existing.get("ok") is True:
        return existing

    evidence = get_evidence_registry()
    targets = get_official_targets()
    zones = get_regional_zones()
    return {
        "ok": True,
        "pack_name": "BOUH Radar Lightweight Intelligence Pack",
        "pack_version": "12.1-fixed",
        "truth_policy": evidence.get("scientific_policy", {}),
        "regional_zones": zones.get("zones", []),
        "official_targets": targets.get("targets", []),
        "screening_points": {
            "universal_top10": targets.get("universal_relative_support_top10", []),
            "sentinel2_top10": targets.get("sentinel2_relative_support_top10", []),
        },
        "universal_summary": get_universal_summary(),
        "data_definitions": get_data_definitions(),
        "heavy_data_policy": get_drive_import_manifest().get("heavy_data_policy"),
    }
