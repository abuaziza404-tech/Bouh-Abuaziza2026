from .decision_rules import decide_target_priority
from .evidence_guard import guard_numeric
from .gpz_strategy import recommend_gpz_strategy


def classify_target(evidence: dict) -> dict:
    guarded = [
        guard_numeric("ndvi", evidence.get("ndvi"), evidence.get("source")),
        guard_numeric("ndwi", evidence.get("ndwi"), evidence.get("source")),
        guard_numeric("bsi", evidence.get("bsi"), evidence.get("source")),
        guard_numeric("ndmi", evidence.get("ndmi"), evidence.get("source")),
    ]
    decision = decide_target_priority(evidence)
    gpz = recommend_gpz_strategy(evidence.get("magnetic_ground_risk"), evidence.get("quartz_qi"))
    return {"decision": decision, "guarded_values": guarded, "gpz_strategy": gpz}
