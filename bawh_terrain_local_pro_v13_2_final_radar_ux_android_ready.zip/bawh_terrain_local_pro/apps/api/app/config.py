from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "sqlite:////tmp/bawh_test.db"
    redis_url: str = "redis://redis:6379/0"
    minio_endpoint: str = "minio:9000"
    minio_public_endpoint: str = "localhost:9000"
    minio_access_key: str = "minioadmin"
    minio_secret_key: str = "minioadmin"
    minio_bucket: str = "bawh-terrain"
    app_secret_key: str = "change-me-local-development-secret"
    opentopography_api_key: str | None = None
    sentinel_hub_client_id: str | None = None
    sentinel_hub_client_secret: str | None = None
    sentinel_date_from: str = "2024-01-01"
    sentinel_date_to: str = "2026-12-31"
    sentinel_max_cloud_coverage: float = 30.0

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
