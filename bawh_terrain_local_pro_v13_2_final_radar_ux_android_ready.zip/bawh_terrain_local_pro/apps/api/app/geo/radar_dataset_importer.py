from pathlib import Path
import hashlib, mimetypes, zipfile
from PIL import Image, ExifTags

IMAGE_EXTENSIONS={".jpg",".jpeg",".png",".webp",".tif",".tiff",".jp2"}

def safe_extract_zip(zip_path, extract_dir):
    zip_path=Path(zip_path); extract_dir=Path(extract_dir); extract_dir.mkdir(parents=True, exist_ok=True)
    root=extract_dir.resolve(); out=[]
    with zipfile.ZipFile(zip_path) as archive:
        for member in archive.infolist():
            if member.is_dir(): continue
            target=(extract_dir/member.filename).resolve()
            if not str(target).startswith(str(root)): raise RuntimeError(f"Unsafe path: {member.filename}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as src, target.open("wb") as dst: dst.write(src.read())
            out.append(target)
    return out

def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""): h.update(chunk)
    return h.hexdigest()

def classify_asset(path):
    n=(path.name+" "+str(path.parent)).lower()
    if "الجنوبي" in n or "south" in n: return "regional_south"
    if "الوسط" in n or "center" in n or "middle" in n: return "regional_center"
    if "الشمال" in n or "north" in n: return "regional_north"
    if "port" in n: return "port_partial"
    if path.suffix.lower() in IMAGE_EXTENSIONS: return "radar_image"
    return "support_file"

def extract_image_metadata(path):
    meta={"width":None,"height":None,"gps_lat":None,"gps_lng":None,"exif":{}}
    if path.suffix.lower() not in IMAGE_EXTENSIONS: return meta
    try:
        with Image.open(path) as img:
            meta["width"]=img.width; meta["height"]=img.height
            exif=img.getexif()
            if exif:
                meta["exif"]={ExifTags.TAGS.get(k,str(k)):str(v) for k,v in exif.items()}
    except Exception as exc:
        meta["error"]=str(exc)
    return meta

def index_extracted_files(files, extract_dir):
    assets=[]
    for path in files:
        m=extract_image_metadata(path)
        assets.append({"file_name":path.name,"relative_path":str(path.relative_to(extract_dir)),"local_path":str(path),"content_type":mimetypes.guess_type(path.name)[0] or "application/octet-stream","sha256":sha256_file(path),"width":m.get("width"),"height":m.get("height"),"gps_lat":m.get("gps_lat"),"gps_lng":m.get("gps_lng"),"asset_role":classify_asset(path),"metadata_json":m})
    return assets
