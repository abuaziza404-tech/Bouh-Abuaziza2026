from pathlib import Path
import numpy as np
import rasterio
from rasterio.transform import from_bounds
from rasterio.crs import CRS
from app.geo.bbox import BBox
from app.geo.spectral_indices import SpectralIndexResult

RASTER_LAYER_NAMES = {"hillshade","slope","flow","ndvi","ndwi","bsi","ndmi"}

def calculate_hillshade(dem, azimuth=315.0, altitude=45.0):
    values = np.nan_to_num(dem.astype("float32"), nan=float(np.nanmean(dem)))
    gy,gx = np.gradient(values)
    slope = np.pi/2 - np.arctan(np.sqrt(gx*gx+gy*gy))
    aspect = np.arctan2(-gx, gy)
    return np.clip(np.sin(np.radians(altitude))*np.sin(slope)+np.cos(np.radians(altitude))*np.cos(slope)*np.cos(np.radians(azimuth)-aspect),0,1).astype("float32")

def calculate_slope_layer(dem):
    values = np.nan_to_num(dem.astype("float32"), nan=float(np.nanmean(dem)))
    gy,gx = np.gradient(values)
    return np.degrees(np.arctan(np.sqrt(gx*gx+gy*gy))).astype("float32")

def calculate_flow_proxy_layer(dem):
    values = np.nan_to_num(dem.astype("float32"), nan=float(np.nanmean(dem)))
    gy,gx = np.gradient(values)
    gradient = np.sqrt(gx*gx+gy*gy)
    return np.where(values < np.nanpercentile(values,40), gradient, 0).astype("float32")

def save_geotiff_layer(array, bbox: BBox, path):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    h,w = array.shape
    transform = from_bounds(bbox.west,bbox.south,bbox.east,bbox.north,w,h)
    clean = array.astype("float32"); clean[~np.isfinite(clean)] = -9999.0
    with rasterio.open(p, "w", driver="GTiff", height=h, width=w, count=1, dtype="float32", crs=CRS.from_epsg(4326), transform=transform, nodata=-9999.0, compress="deflate", tiled=True, blockxsize=256, blockysize=256) as ds:
        ds.write(clean, 1)
    return p

def stats(array):
    valid = np.isfinite(array)
    if not np.any(valid): return {"min":None,"max":None,"mean":None,"std":None}
    v = array[valid]
    return {"min":float(np.nanmin(v)),"max":float(np.nanmax(v)),"mean":float(np.nanmean(v)),"std":float(np.nanstd(v))}

def save_project_raster_layers(project_id: int, dem, bbox: BBox, spectral_result: SpectralIndexResult | None, output_root="/app/data/outputs/layers"):
    project_dir = Path(output_root)/f"project_{project_id}"
    layers = {"hillshade": calculate_hillshade(dem), "slope": calculate_slope_layer(dem), "flow": calculate_flow_proxy_layer(dem)}
    if spectral_result:
        if spectral_result.ndvi is not None: layers["ndvi"] = spectral_result.ndvi.astype("float32")
        if spectral_result.ndwi is not None: layers["ndwi"] = spectral_result.ndwi.astype("float32")
        if spectral_result.bsi is not None: layers["bsi"] = spectral_result.bsi.astype("float32")
        if getattr(spectral_result, "ndmi", None) is not None: layers["ndmi"] = spectral_result.ndmi.astype("float32")
    out = {}
    for name, arr in layers.items():
        tif = save_geotiff_layer(arr, bbox, project_dir/f"{name}.tif")
        s = stats(arr)
        out[name] = {"geotiff_path":str(tif),"available":True,"bounds":[bbox.west,bbox.south,bbox.east,bbox.north],"crs":"EPSG:4326", **s}
    return out
