from dataclasses import dataclass
import numpy as np

@dataclass
class TerrainResult:
    mean_elevation: float
    min_elevation: float
    max_elevation: float
    mean_slope: float
    max_slope: float
    roughness_score: float
    flow_score: float
    data_quality_score: float
    final_score: float
    report_ar: str

def normalize_score(value: float, minimum: float, maximum: float) -> float:
    if maximum <= minimum:
        return 0.0
    return float(max(0, min(100, ((value - minimum) / (maximum - minimum)) * 100)))

def calculate_slope_degrees(dem: np.ndarray, pixel_size_m: float) -> np.ndarray:
    clean = np.nan_to_num(dem.astype(float), nan=float(np.nanmean(dem)))
    gy, gx = np.gradient(clean, pixel_size_m, pixel_size_m)
    return np.degrees(np.arctan(np.sqrt(gx**2 + gy**2)))

def calculate_roughness_score(dem: np.ndarray) -> float:
    return normalize_score(float(np.nanstd(dem)), 0, 80)

def calculate_flow_proxy_score(dem: np.ndarray) -> float:
    clean = np.nan_to_num(dem.astype(float), nan=float(np.nanmean(dem)))
    gy, gx = np.gradient(clean)
    gradient = np.sqrt(gx**2 + gy**2)
    low = clean < np.nanpercentile(clean, 35)
    return normalize_score(float(np.nanmean(gradient[low])) if np.any(low) else 0, 0, 20)

def generate_synthetic_dem(size: int = 160) -> np.ndarray:
    y, x = np.mgrid[0:size, 0:size]
    return 620 + 55*np.sin(x/16) - 38*np.cos(y/18) + 120*np.exp(-(((x-76)**2+(y-54)**2)/1300)) + x*.8 + y*.35

def analyze_dem_array(dem: np.ndarray, pixel_size_m: float, soil_type: str, terrain_type: str, dem_source: str,
                      soil_summary=None, osm_summary=None, sentinel_summary=None, spectral_summary=None, spectral_bonus: float = 0.0) -> TerrainResult:
    slope = calculate_slope_degrees(dem, pixel_size_m)
    mean_elevation = float(np.nanmean(dem))
    min_elevation = float(np.nanmin(dem))
    max_elevation = float(np.nanmax(dem))
    mean_slope = float(np.nanmean(slope))
    max_slope = float(np.nanmax(slope))
    rough = calculate_roughness_score(dem)
    flow = calculate_flow_proxy_score(dem)
    quality = 88.0 if dem_source != "synthetic-fallback" else 62.0
    final = max(0.0, min(100.0, normalize_score(mean_slope,0,32)*.20 + rough*.18 + flow*.20 + quality*.26 + spectral_bonus))
    spectral_text = "لم تتوفر مؤشرات طيفية." if not spectral_summary else f"المؤشرات الطيفية: {', '.join(spectral_summary.keys())}."
    report = f"قراءة بوح التضاريس: مصدر الارتفاعات {dem_source}. متوسط الميل {mean_slope:.2f}°. جودة البيانات {quality:.0f}/100. {spectral_text} تحليل سطحي احتمالي وليس كشفًا لما تحت الأرض."
    return TerrainResult(mean_elevation, min_elevation, max_elevation, mean_slope, max_slope, rough, flow, quality, final, report)
