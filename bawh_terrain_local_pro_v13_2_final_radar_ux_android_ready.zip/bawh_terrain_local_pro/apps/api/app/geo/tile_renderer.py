from pathlib import Path
import numpy as np
from rio_tiler.io import Reader
from rio_tiler.models import ImageData
from rio_tiler.errors import TileOutsideBounds

def normalize_to_uint8(array, minimum=None, maximum=None):
    values = array.astype("float32"); values[~np.isfinite(values)] = np.nan
    if minimum is None: minimum = float(np.nanpercentile(values,2)) if np.isfinite(values).any() else 0.0
    if maximum is None: maximum = float(np.nanpercentile(values,98)) if np.isfinite(values).any() else 1.0
    if maximum <= minimum: maximum = minimum + 1.0
    return (np.nan_to_num(np.clip((values-minimum)/(maximum-minimum),0,1))*255).astype("uint8")

def rgba_for_layer(layer_name, values, minimum=None, maximum=None):
    scaled = normalize_to_uint8(values, -1, 1) if layer_name in {"ndvi","ndwi","bsi","ndmi"} else normalize_to_uint8(values, minimum, maximum)
    if layer_name == "ndmi":
        r,g,b = np.clip(80+scaled//5,0,255).astype("uint8"), np.clip(120+scaled//2,0,255).astype("uint8"), np.clip(70+scaled//4,0,255).astype("uint8")
    elif layer_name == "ndvi":
        r,g,b = np.clip(180-scaled,0,255).astype("uint8"), np.clip(scaled+35,0,255).astype("uint8"), np.clip(80-scaled//3,0,255).astype("uint8")
    elif layer_name == "ndwi":
        r,g,b = np.clip(35+scaled//5,0,255).astype("uint8"), np.clip(70+scaled//2,0,255).astype("uint8"), np.clip(120+scaled,0,255).astype("uint8")
    elif layer_name == "bsi":
        r,g,b = np.clip(100+scaled//2,0,255).astype("uint8"), np.clip(72+scaled//3,0,255).astype("uint8"), np.clip(38+scaled//6,0,255).astype("uint8")
    else:
        r=g=b=scaled
    a = np.where(np.isfinite(values),190,0).astype("uint8")
    return np.stack([r,g,b,a], axis=0)

def render_tile_png(geotiff_path, layer_name, z, x, y, minimum=None, maximum=None):
    path = Path(geotiff_path)
    if not path.exists(): raise FileNotFoundError(str(path))
    try:
        with Reader(str(path)) as cog:
            tile = cog.tile(x,y,z,tilesize=256)
    except TileOutsideBounds:
        return ImageData(np.zeros((4,256,256), dtype="uint8")).render(img_format="PNG")
    values = tile.data[0].astype("float32")
    if tile.mask is not None: values = np.where(tile.mask > 0, values, np.nan)
    values[values == -9999] = np.nan
    return ImageData(rgba_for_layer(layer_name, values, minimum, maximum)).render(img_format="PNG")
