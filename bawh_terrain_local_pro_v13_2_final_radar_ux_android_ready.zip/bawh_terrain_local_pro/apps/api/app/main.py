from pathlib import Path
from datetime import datetime, timezone
import csv
import os
from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from sqlalchemy.orm import Session
from app.app_identity import APP_IDENTITY
from app.database import Base, engine, get_db
from app.geo.radar_dataset_importer import safe_extract_zip, index_extracted_files
from app.geo.radar_library import build_radar_library, build_dataset_detail
from app.geo.raster_layers import RASTER_LAYER_NAMES
from app.geo.regional_corridor import build_corridor_segments, analyze_corridor_trend
from app.geo.tile_renderer import render_tile_png
from app.models import AIAnalysisJob, AppUser, EmergencyAlertEvent, OfflineMapDownloadJob, OfflineMapPack, ProjectUpload, RadarDataset, RadarDatasetAsset, ScanProject, TerrainMetrics
from app.safety.local_cache import SafetyLocalCache
from app.safety.open_meteo import OpenMeteoSafetyConnector
from app.safety.risk_engine import analyze_safety_forecast, offline_safety_response
from app.safety.safety_models import SafetyForecastRequest
from app.schemas import AuthTokenResponse, BootstrapAdminRequest, CreateAIAnalysisJobRequest, AIAnalysisJobResponse, CreateOfflineMapDownloadJobRequest, EmergencyForecastRequest, EmergencyAlertEventResponse, OfflineMapDownloadJobResponse, CreateScanProjectRequest, LoginRequest, RadarScanRequest, ScanProjectResponse, TerrainMetricsResponse, UserResponse
from app.storage import ensure_bucket, upload_bytes
from app.worker import run_terrain_analysis
from app.security.upload_validation import validate_upload, enrich_with_hash
from app.bouh_core.report_builder import build_project_report_json, build_project_report_html
from app.bouh_core.corridor_engine import build_corridor_decision
from app.bouh_core.decision_rules import decide_target_priority
from app.bouh_core.evidence_guard import guard_numeric
from app.bouh_core.gpz_strategy import recommend_gpz_strategy
from app.bouh_core.router import router as bouh_lightweight_router
from app.emergency.forecast import build_emergency_sources_status, forecast_emergency_risk
from app.auth.security import create_token, decode_token, hash_password, require_role, verify_password
from app.offline.map_packs import detect_pack_type, inspect_mbtiles, inspect_pmtiles, read_mbtiles_tile, safe_pack_name, validate_map_pack_extension
from app.offline.tile_planner import build_tile_plan, estimate_tile_count

app = FastAPI(title="بوح التضاريس API", version="2.0.0-local-pro")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(bouh_lightweight_router)

@app.middleware("http")
async def add_security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "geolocation=(self), camera=(), microphone=()"
    response.headers["X-Bawh-Developer"] = "Ahmed Abuaziza Al-Rashidi"
    return response


@app.on_event("startup")
def startup():
    if os.getenv("BOUH_SKIP_DB_STARTUP", "0") == "1":
        return
    Base.metadata.create_all(bind=engine)
    try: ensure_bucket()
    except Exception: pass


def current_user_payload(authorization: str | None = Header(default=None)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Authorization Bearer token مطلوب")

    token = authorization.split(" ", 1)[1].strip()

    try:
        return decode_token(token)
    except ValueError:
        raise HTTPException(status_code=401, detail="رمز الدخول غير صالح أو منتهي")


def require_admin(payload: dict = Depends(current_user_payload)):
    try:
        require_role(payload, {"admin"})
    except PermissionError:
        raise HTTPException(status_code=403, detail="صلاحية admin مطلوبة")
    return payload

@app.get("/health")
def health(): return {"ok": True, "service": "bawh-terrain-api"}

@app.get("/app/identity")
def get_app_identity(): return APP_IDENTITY


@app.post("/auth/bootstrap-admin", response_model=AuthTokenResponse)
def bootstrap_admin(payload: BootstrapAdminRequest, db: Session = Depends(get_db)):
    existing_admin = db.query(AppUser).filter(AppUser.role == "admin").first()

    if existing_admin is not None:
        raise HTTPException(status_code=409, detail="تم إنشاء مدير مسبقًا")

    user = AppUser(
        username=payload.username,
        password_hash=hash_password(payload.password),
        role="admin",
        is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = create_token({"sub": str(user.id), "username": user.username, "role": user.role})

    return AuthTokenResponse(access_token=token, role=user.role, username=user.username)


@app.post("/auth/login", response_model=AuthTokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(AppUser).filter(AppUser.username == payload.username).first()

    if user is None or not user.is_active or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="بيانات الدخول غير صحيحة")

    token = create_token({"sub": str(user.id), "username": user.username, "role": user.role})

    return AuthTokenResponse(access_token=token, role=user.role, username=user.username)


@app.get("/auth/me", response_model=UserResponse)
def auth_me(token_payload: dict = Depends(current_user_payload), db: Session = Depends(get_db)):
    user_id = int(token_payload["sub"])
    user = db.get(AppUser, user_id)

    if user is None or not user.is_active:
        raise HTTPException(status_code=401, detail="المستخدم غير نشط")

    return user


@app.get("/auth/users", response_model=list[UserResponse])
def list_users(_: dict = Depends(require_admin), db: Session = Depends(get_db)):
    return db.query(AppUser).order_by(AppUser.id.asc()).all()


@app.get("/system/overview")
def system_overview(db: Session = Depends(get_db)):
    projects = db.query(ScanProject).count()
    datasets = db.query(RadarDataset).count()
    ai_jobs = db.query(AIAnalysisJob).count()
    metrics = db.query(TerrainMetrics).all()
    layers = 0
    for metric in metrics:
        raster_layers = (metric.source_metadata or {}).get("raster_layers", {}) or {}
        layers += sum(1 for value in raster_layers.values() if value and value.get("available"))
    return {
        "ok": True,
        "identity": APP_IDENTITY,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "counts": {
            "projects": projects,
            "datasets": datasets,
            "ai_jobs": ai_jobs,
            "layers": layers,
            "offline_map_packs": db.query(OfflineMapPack).count(),
            "offline_download_jobs": db.query(OfflineMapDownloadJob).count(),
            "emergency_events": db.query(EmergencyAlertEvent).count(),
        },
        "operating_mode": {
            "offline_first": True,
            "online_features_available": True,
            "cache_enabled": True,
            "local_data_path": "/app/data",
        },
        "sections": [
            {"id": "radar", "label_ar": "الرادار", "status": "ready", "online_required": False},
            {"id": "safety", "label_ar": "السلامة والتنبؤات", "status": "hybrid", "online_required": False},
            {"id": "sources", "label_ar": "مصادر الأقمار", "status": "hybrid", "online_required": True},
            {"id": "library", "label_ar": "مكتبة البيانات", "status": "ready", "online_required": False},
            {"id": "ai", "label_ar": "طابور AI", "status": "ready", "online_required": False},
            {"id": "security", "label_ar": "الأمان", "status": "ready", "online_required": False},
        ],
    }

@app.get("/sources/status")
def sources_status():
    def env_present(name: str) -> bool:
        return bool(os.getenv(name))

    sources = [
        {
            "id": "local_radar_library",
            "label_ar": "مكتبة الرادار المحلية",
            "category": "local",
            "mode": "local",
            "configured": True,
            "enabled": True,
            "message_ar": "تعمل بدون إنترنت من /app/data/imports والبيانات المرفوعة.",
        },
        {
            "id": "local_raster_engine",
            "label_ar": "محرك Raster المحلي",
            "category": "local",
            "mode": "local",
            "configured": True,
            "enabled": True,
            "message_ar": "يولد طبقات DEM/Slope/Flow محليًا ويخدم Tiles.",
        },
        {
            "id": "open_meteo",
            "label_ar": "Open-Meteo للطقس والسلامة",
            "category": "weather",
            "mode": "hybrid",
            "configured": True,
            "enabled": True,
            "message_ar": "يتحدث عند توفر الإنترنت ويستخدم Cache عند الانقطاع.",
        },
        {
            "id": "opentopography",
            "label_ar": "OpenTopography DEM",
            "category": "satellite",
            "mode": "online",
            "configured": env_present("OPENTOPOGRAPHY_API_KEY"),
            "enabled": env_present("OPENTOPOGRAPHY_API_KEY"),
            "message_ar": "يحتاج مفتاح API لجلب DEM حقيقي؛ يعمل النظام بدونه عبر fallback محلي.",
        },
        {
            "id": "sentinel_hub",
            "label_ar": "Sentinel Hub Process API",
            "category": "satellite",
            "mode": "online",
            "configured": env_present("SENTINEL_HUB_CLIENT_ID") and env_present("SENTINEL_HUB_CLIENT_SECRET"),
            "enabled": env_present("SENTINEL_HUB_CLIENT_ID") and env_present("SENTINEL_HUB_CLIENT_SECRET"),
            "message_ar": "يفعل تحميل باندات Sentinel تلقائيًا عند توفر الاعتماديات.",
        },
        {
            "id": "soilgrids",
            "label_ar": "SoilGrids",
            "category": "satellite",
            "mode": "online",
            "configured": True,
            "enabled": True,
            "message_ar": "مصدر تربة عالمي متصل؛ يستخدم فقط عند توفر الإنترنت.",
        },
        {
            "id": "overpass",
            "label_ar": "OpenStreetMap Overpass",
            "category": "maps",
            "mode": "online",
            "configured": True,
            "enabled": True,
            "message_ar": "يجلب سياق الطرق والمياه والمعالم عند توفر الإنترنت.",
        },
        {
            "id": "ai_queue",
            "label_ar": "طابور AI المحلي",
            "category": "ai",
            "mode": "local",
            "configured": True,
            "enabled": True,
            "message_ar": "يحفظ المهام لنموذج آخر أو تحليل لاحق بدون إنترنت.",
        },
    ]
    return {"ok": True, "generated_at": datetime.now(timezone.utc).isoformat(), "sources": sources}


@app.post("/projects", response_model=ScanProjectResponse)
def create_project(payload: CreateScanProjectRequest, db: Session = Depends(get_db)):
    p=ScanProject(name=payload.name, center_lat=payload.center_lat, center_lng=payload.center_lng, radius_m=payload.radius_m, soil_type=payload.soil_type, terrain_type=payload.terrain_type, status="queued")
    db.add(p); db.commit(); db.refresh(p)
    run_terrain_analysis.delay(p.id)
    return p

@app.get("/projects", response_model=list[ScanProjectResponse])
def list_projects(db: Session = Depends(get_db)):
    return db.query(ScanProject).order_by(ScanProject.id.desc()).limit(50).all()

@app.get("/projects/{project_id}", response_model=ScanProjectResponse)
def get_project(project_id: int, db: Session = Depends(get_db)):
    p=db.get(ScanProject, project_id)
    if not p: raise HTTPException(404, "المشروع غير موجود")
    return p

@app.get("/projects/{project_id}/metrics", response_model=TerrainMetricsResponse)
def get_metrics(project_id: int, db: Session = Depends(get_db)):
    m=db.query(TerrainMetrics).filter(TerrainMetrics.project_id==project_id).first()
    if not m: raise HTTPException(404, "التحليل لم يكتمل")
    return m

@app.post("/projects/{project_id}/uploads")
async def upload_project_file(project_id: int, file: UploadFile = File(...), band_role: str | None = None, db: Session = Depends(get_db)):
    p=db.get(ScanProject, project_id)
    if not p: raise HTTPException(404, "المشروع غير موجود")
    valid={None,"blue","green","red","nir","swir"}
    if band_role not in valid: raise HTTPException(400, "band_role غير مدعوم")
    data=await file.read()
    if len(data)>300*1024*1024: raise HTTPException(413, "حجم الملف كبير")
    safe=file.filename.replace("/","_").replace("\\","_")
    object_name=f"projects/{project_id}/uploads/{safe}"
    url=upload_bytes(object_name, data, file.content_type or "application/octet-stream")
    local_dir=Path(f"/app/data/uploads/projects/{project_id}"); local_dir.mkdir(parents=True, exist_ok=True)
    local_path=local_dir/safe; local_path.write_bytes(data)
    db.add(ProjectUpload(project_id=project_id,file_name=safe,object_name=object_name,local_path=str(local_path),content_type=file.content_type or "application/octet-stream",file_size=len(data),band_role=band_role))
    db.commit()
    return {"ok":True,"url":url,"local_path":str(local_path)}

@app.post("/projects/{project_id}/rerun")
def rerun(project_id: int, db: Session = Depends(get_db)):
    p=db.get(ScanProject, project_id)
    if not p: raise HTTPException(404, "المشروع غير موجود")
    p.status="queued"; db.commit(); run_terrain_analysis.delay(p.id)
    return {"ok": True, "status": "queued"}

@app.post("/radar-scan")
def radar_scan(payload: RadarScanRequest, db: Session = Depends(get_db)):
    p=db.get(ScanProject, payload.project_id)
    if not p: raise HTTPException(404, "المشروع غير موجود")
    p.center_lat=payload.center_lat; p.center_lng=payload.center_lng; p.radius_m=payload.radius_m; p.status="queued"
    db.commit(); run_terrain_analysis.delay(p.id)
    return {"ok": True, "project_id": p.id, "radar": payload.model_dump()}

@app.get("/projects/{project_id}/layers")
def layers(project_id: int, db: Session = Depends(get_db)):
    m=db.query(TerrainMetrics).filter(TerrainMetrics.project_id==project_id).first()
    rasters=(m.source_metadata.get("raster_layers",{}) if m else {}) or {}
    return [{"name":name,"title":name.upper(),"available":bool(rasters.get(name)),"tile_url":f"/projects/{project_id}/layers/{name}/tiles/{{z}}/{{x}}/{{y}}.png" if rasters.get(name) else None,"min":(rasters.get(name) or {}).get("min"),"max":(rasters.get(name) or {}).get("max"),"mean":(rasters.get(name) or {}).get("mean")} for name in ["hillshade","slope","flow","ndvi","ndwi","bsi","ndmi"]]

@app.get("/projects/{project_id}/layers/{layer_name}/tiles/{z}/{x}/{y}.png")
def tile(project_id:int, layer_name:str, z:int, x:int, y:int, db:Session=Depends(get_db)):
    if layer_name not in RASTER_LAYER_NAMES: raise HTTPException(404, "الطبقة غير موجودة")
    m=db.query(TerrainMetrics).filter(TerrainMetrics.project_id==project_id).first()
    if not m: raise HTTPException(404, "لا توجد نتائج")
    info=(m.source_metadata.get("raster_layers",{}) or {}).get(layer_name)
    if not info: raise HTTPException(404, "الطبقة غير متاحة")
    try:
        png=render_tile_png(info["geotiff_path"], layer_name, z,x,y, info.get("min"), info.get("max"))
    except FileNotFoundError:
        raise HTTPException(404, "ملف الطبقة غير موجود")
    return Response(content=png, media_type="image/png", headers={"Cache-Control":"public, max-age=3600"})

@app.post("/projects/{project_id}/radar-datasets")
async def upload_radar_dataset(project_id:int, file:UploadFile=File(...), db:Session=Depends(get_db)):
    p=db.get(ScanProject, project_id)
    if not p: raise HTTPException(404, "المشروع غير موجود")
    if not file.filename.lower().endswith(".zip"): raise HTTPException(400, "يجب رفع ZIP")
    data=await file.read()
    if len(data)>1024*1024*1024: raise HTTPException(413, "حجم الملف أكبر من 1GB")
    safe=file.filename.replace("/","_").replace("\\","_")
    root=Path(f"/app/data/radar_datasets/project_{project_id}"); root.mkdir(parents=True, exist_ok=True)
    zip_path=root/safe; zip_path.write_bytes(data)
    extract=root/safe.replace(".zip","")
    files=safe_extract_zip(zip_path, extract)
    assets=index_extracted_files(files, extract)
    ds=RadarDataset(project_id=project_id,name=safe,original_file_name=safe,object_name=f"radar_datasets/project_{project_id}/{safe}",local_zip_path=str(zip_path),extract_dir=str(extract),file_count=len(files),image_count=sum(1 for a in assets if a["content_type"].startswith("image/")),metadata_json={"classified_roles":sorted(set(a["asset_role"] for a in assets))})
    db.add(ds); db.commit(); db.refresh(ds)
    for a in assets: db.add(RadarDatasetAsset(dataset_id=ds.id, project_id=project_id, **a))
    db.commit()
    return {"ok":True,"dataset_id":ds.id,"file_count":ds.file_count,"image_count":ds.image_count,"roles":ds.metadata_json["classified_roles"]}

@app.get("/radar/library")
def radar_library():
    items=build_radar_library()
    return {"ok":True,"count":len(items),"items":[i.__dict__ for i in items],"notes":["نطاق الوسط مكمل للممر الإقليمي.","Port جزئي.","سجل أبو عزيزة محلي."]}

@app.get("/radar/library/{role}")
def radar_library_item(role:str):
    d=build_dataset_detail(role)
    if not d.get("ok"): raise HTTPException(404, d["message"])
    return d

@app.get("/radar/regional-corridor")
def regional_corridor():
    path=Path("/app/data/imports/bouh_sentinel_dataset_summary.csv")
    if not path.exists(): return {"ok":True,"layer_name":"regional_corridor","segments":[],"analysis":{"status":"missing_summary"}}
    rows=[]
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            if r.get("role") in {"regional_south","regional_center","regional_north"}: rows.append(r)
    seg=build_corridor_segments(rows)
    return {"ok":True,"layer_name":"regional_corridor","segments":[s.__dict__ for s in seg],"analysis":analyze_corridor_trend(seg)}

@app.post("/ai-analysis/jobs", response_model=AIAnalysisJobResponse)
def create_ai_job(payload:CreateAIAnalysisJobRequest, db:Session=Depends(get_db)):
    allowed={"image_pattern_review","spectral_anomaly_review","local_register_review","cross_dataset_comparison","regional_corridor_review","report_generation"}
    if payload.task_type not in allowed: raise HTTPException(400, "نوع المهمة غير مدعوم")
    job=AIAnalysisJob(**payload.model_dump(), status="queued")
    db.add(job); db.commit(); db.refresh(job)
    return job

@app.get("/ai-analysis/jobs", response_model=list[AIAnalysisJobResponse])
def list_ai_jobs(db:Session=Depends(get_db)):
    return db.query(AIAnalysisJob).order_by(AIAnalysisJob.id.desc()).limit(200).all()

@app.post("/ai-analysis/jobs/create-regional-defaults")
def ai_defaults(db:Session=Depends(get_db)):
    created=0
    task_map={"regional_south":"regional_corridor_review","regional_center":"regional_corridor_review","regional_north":"regional_corridor_review","port_partial":"image_pattern_review","local_target_west":"spectral_anomaly_review","local_target_east":"spectral_anomaly_review","abuziza_local_app":"local_register_review"}
    for item in build_radar_library():
        db.add(AIAnalysisJob(dataset_role=item.role,dataset_name=item.source_name,task_type=task_map.get(item.role,"cross_dataset_comparison"),priority="high" if item.role=="regional_center" else "normal",input_metadata=item.__dict__,notes_ar=item.recommendation_ar))
        created += 1
    db.commit()
    return {"ok":True,"created_count":created}

@app.post("/ai-analysis/jobs/{job_id}/mark-reviewed")
def mark_reviewed(job_id:int, db:Session=Depends(get_db)):
    job=db.get(AIAnalysisJob, job_id)
    if not job: raise HTTPException(404, "مهمة غير موجودة")
    job.human_review_status="reviewed"; db.commit()
    return {"ok":True}

@app.post("/safety/forecast")
async def safety_forecast(payload: SafetyForecastRequest):
    cache=SafetyLocalCache()
    try:
        raw=await OpenMeteoSafetyConnector().fetch_forecast(payload.lat, payload.lng, payload.hours)
        cache.save(payload.lat, payload.lng, raw)
        analyzed=analyze_safety_forecast(raw)
    except Exception:
        analyzed=offline_safety_response(payload.lat, payload.lng, cache.load(payload.lat, payload.lng))
    return {**analyzed, "lat": payload.lat, "lng": payload.lng}


@app.post("/offline-map-packs")
async def upload_offline_map_pack(file: UploadFile = File(...), db: Session = Depends(get_db)):
    try:
        safe_name = safe_pack_name(file.filename or "map-pack")
        validate_map_pack_extension(safe_name)
        pack_type = detect_pack_type(safe_name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    data = await file.read()

    if len(data) > 4 * 1024 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="حزمة الخرائط أكبر من 4GB")

    pack_root = Path("/app/data/offline_map_packs")
    pack_root.mkdir(parents=True, exist_ok=True)
    local_path = pack_root / safe_name
    local_path.write_bytes(data)

    try:
        inspection = inspect_mbtiles(local_path) if pack_type == "mbtiles" else inspect_pmtiles(local_path)
    except Exception as exc:
        local_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=f"فشل فحص حزمة الخرائط: {exc}")

    pack = OfflineMapPack(
        name=safe_name.rsplit(".", 1)[0],
        pack_type=pack_type,
        file_name=safe_name,
        local_path=str(local_path),
        file_size=len(data),
        min_zoom=inspection.get("min_zoom"),
        max_zoom=inspection.get("max_zoom"),
        bounds_json=inspection.get("bounds") or {},
        metadata_json=inspection.get("metadata") or {},
    )

    db.add(pack)
    db.commit()
    db.refresh(pack)

    return {
        "ok": True,
        "id": pack.id,
        "name": pack.name,
        "pack_type": pack.pack_type,
        "file_size": pack.file_size,
        "min_zoom": pack.min_zoom,
        "max_zoom": pack.max_zoom,
        "bounds": pack.bounds_json,
        "metadata": pack.metadata_json,
        "tile_url": f"/offline-map-packs/{pack.id}/tiles/{{z}}/{{x}}/{{y}}.png" if pack.pack_type == "mbtiles" else None,
        "pmtiles_url": f"/offline-map-packs/{pack.id}/file.pmtiles" if pack.pack_type == "pmtiles" else None,
    }


@app.get("/offline-map-packs")
def list_offline_map_packs(db: Session = Depends(get_db)):
    packs = db.query(OfflineMapPack).order_by(OfflineMapPack.id.desc()).all()

    return [
        {
            "id": pack.id,
            "name": pack.name,
            "pack_type": pack.pack_type,
            "file_name": pack.file_name,
            "file_size": pack.file_size,
            "min_zoom": pack.min_zoom,
            "max_zoom": pack.max_zoom,
            "bounds": pack.bounds_json,
            "metadata": pack.metadata_json,
            "tile_url": f"/offline-map-packs/{pack.id}/tiles/{{z}}/{{x}}/{{y}}.png" if pack.pack_type == "mbtiles" else None,
        "pmtiles_url": f"/offline-map-packs/{pack.id}/file.pmtiles" if pack.pack_type == "pmtiles" else None,
            "created_at": pack.created_at,
        }
        for pack in packs
    ]


@app.get("/offline-map-packs/{pack_id}/tiles/{z}/{x}/{y}.png")
def offline_map_pack_tile(pack_id: int, z: int, x: int, y: int, db: Session = Depends(get_db)):
    pack = db.get(OfflineMapPack, pack_id)

    if pack is None:
        raise HTTPException(status_code=404, detail="حزمة الخرائط غير موجودة")

    if pack.pack_type != "mbtiles":
        raise HTTPException(status_code=400, detail="PMTiles محفوظ كحزمة خام ولا يقدم Tiles من هذا endpoint")

    tile = read_mbtiles_tile(pack.local_path, z, x, y)

    if tile is None:
        raise HTTPException(status_code=404, detail="Tile غير موجود داخل MBTiles")

    content, media_type = tile
    return Response(
        content=content,
        media_type=media_type,
        headers={"Cache-Control": "public, max-age=31536000, immutable"},
    )


@app.get("/offline-map-packs/{pack_id}/file.pmtiles")
def offline_map_pack_pmtiles_file(pack_id: int, db: Session = Depends(get_db)):
    pack = db.get(OfflineMapPack, pack_id)

    if pack is None:
        raise HTTPException(status_code=404, detail="حزمة الخرائط غير موجودة")

    if pack.pack_type != "pmtiles":
        raise HTTPException(status_code=400, detail="هذه الحزمة ليست PMTiles")

    path = Path(pack.local_path)

    if not path.exists():
        raise HTTPException(status_code=404, detail="ملف PMTiles غير موجود")

    return FileResponse(
        str(path),
        media_type="application/octet-stream",
        filename=pack.file_name,
        headers={"Cache-Control": "public, max-age=31536000, immutable"},
    )


@app.post("/offline-map-downloads", response_model=OfflineMapDownloadJobResponse)
def create_offline_map_download_job(payload: CreateOfflineMapDownloadJobRequest, db: Session = Depends(get_db)):
    if payload.east <= payload.west or payload.north <= payload.south:
        raise HTTPException(status_code=400, detail="حدود المنطقة غير صالحة")

    if payload.max_zoom < payload.min_zoom:
        raise HTTPException(status_code=400, detail="max_zoom يجب أن يكون أكبر أو يساوي min_zoom")

    sources = [payload.source]
    if payload.include_reference:
        sources.append("esri_reference")
    if payload.include_streets:
        sources.append("osm_streets")

    estimated = estimate_tile_count(
        payload.west,
        payload.south,
        payload.east,
        payload.north,
        payload.min_zoom,
        payload.max_zoom,
        len(sources),
    )

    if estimated > 50000:
        raise HTTPException(status_code=413, detail="الخطة كبيرة جدًا. قلل المنطقة أو مستويات Zoom.")

    plan = build_tile_plan(
        payload.west,
        payload.south,
        payload.east,
        payload.north,
        payload.min_zoom,
        payload.max_zoom,
        sources,
    )

    job = OfflineMapDownloadJob(
        name=payload.name,
        source=payload.source,
        status="planned",
        west=payload.west,
        south=payload.south,
        east=payload.east,
        north=payload.north,
        min_zoom=payload.min_zoom,
        max_zoom=payload.max_zoom,
        estimated_tiles=estimated,
        downloaded_tiles=0,
        failed_tiles=0,
        metadata_json={"sources": sources, "ranges": plan["ranges"]},
    )

    db.add(job)
    db.commit()
    db.refresh(job)
    return job


@app.get("/offline-map-downloads", response_model=list[OfflineMapDownloadJobResponse])
def list_offline_map_download_jobs(db: Session = Depends(get_db)):
    return db.query(OfflineMapDownloadJob).order_by(OfflineMapDownloadJob.id.desc()).limit(200).all()


@app.get("/offline-map-downloads/{job_id}/plan")
def offline_map_download_plan(job_id: int, db: Session = Depends(get_db)):
    job = db.get(OfflineMapDownloadJob, job_id)

    if job is None:
        raise HTTPException(status_code=404, detail="خطة تنزيل الخرائط غير موجودة")

    sources = job.metadata_json.get("sources") or [job.source]

    plan = build_tile_plan(
        job.west,
        job.south,
        job.east,
        job.north,
        job.min_zoom,
        job.max_zoom,
        sources,
    )

    return {
        "ok": True,
        "job_id": job.id,
        "name": job.name,
        "count": plan["count"],
        "ranges": plan["ranges"],
        "tiles": plan["tiles"],
    }


@app.post("/offline-map-downloads/{job_id}/mark-complete")
def mark_offline_map_download_complete(job_id: int, downloaded_tiles: int = 0, failed_tiles: int = 0, db: Session = Depends(get_db)):
    job = db.get(OfflineMapDownloadJob, job_id)

    if job is None:
        raise HTTPException(status_code=404, detail="خطة تنزيل الخرائط غير موجودة")

    job.downloaded_tiles = downloaded_tiles
    job.failed_tiles = failed_tiles
    job.status = "completed" if failed_tiles == 0 else "completed_with_errors"
    db.commit()

    return {"ok": True, "job_id": job.id, "status": job.status}


@app.get("/maps/base-layers")
def base_layers_catalog():
    return {
        "ok": True,
        "groups": [
            {
                "id": "satellite",
                "label_ar": "خرائط فضائية",
                "layers": [
                    {
                        "id": "esri_satellite",
                        "label_ar": "Esri Satellite",
                        "type": "raster_xyz",
                        "online_required": True,
                        "offline_cache": True,
                        "url_template": "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
                    },
                    {
                        "id": "esri_hybrid_reference",
                        "label_ar": "Esri Reference Overlay",
                        "type": "raster_xyz",
                        "online_required": True,
                        "offline_cache": True,
                        "url_template": "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
                    },
                ],
            },
            {
                "id": "streets",
                "label_ar": "الشوارع والمسارات",
                "layers": [
                    {
                        "id": "osm_streets",
                        "label_ar": "OpenStreetMap Streets",
                        "type": "raster_xyz",
                        "online_required": True,
                        "offline_cache": True,
                        "url_template": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                    },
                ],
            },
            {
                "id": "local_packs",
                "label_ar": "الحزم المحلية",
                "layers": [
                    {"id": "mbtiles", "label_ar": "MBTiles", "type": "local_tile_pack", "online_required": False, "offline_cache": True},
                    {"id": "pmtiles", "label_ar": "PMTiles", "type": "local_tile_pack", "online_required": False, "offline_cache": True},
                ],
            },
            {
                "id": "analysis",
                "label_ar": "طبقات التحليل",
                "layers": [
                    {"id": "hillshade", "label_ar": "Hillshade", "type": "project_raster", "online_required": False},
                    {"id": "slope", "label_ar": "Slope", "type": "project_raster", "online_required": False},
                    {"id": "flow", "label_ar": "Flow", "type": "project_raster", "online_required": False},
                    {"id": "ndvi", "label_ar": "NDVI", "type": "spectral_index", "online_required": False},
                    {"id": "ndwi", "label_ar": "NDWI", "type": "spectral_index", "online_required": False},
                    {"id": "bsi", "label_ar": "BSI", "type": "spectral_index", "online_required": False},
                ],
            },
        ],
    }


@app.get("/emergency/sources")
def emergency_sources():
    return {"ok": True, "sources": build_emergency_sources_status()}


@app.post("/emergency/forecast")
async def emergency_forecast(payload: EmergencyForecastRequest):
    weather_raw = None
    if payload.include_satellite_feeds:
        try:
            connector = OpenMeteoSafetyConnector()
            fetched = await connector.fetch_forecast(payload.lat, payload.lng, min(payload.hours, 168))
            weather_raw = fetched.raw
        except Exception:
            weather_raw = None

    return forecast_emergency_risk(payload.lat, payload.lng, payload.radius_km, payload.hours, weather_raw)


@app.get("/emergency/events", response_model=list[EmergencyAlertEventResponse])
def list_emergency_events(db: Session = Depends(get_db)):
    rows = db.query(EmergencyAlertEvent).order_by(EmergencyAlertEvent.id.desc()).limit(200).all()
    return rows


@app.get("/projects/{project_id}/layers/{layer_name}/metadata")
def layer_metadata(project_id: int, layer_name: str, db: Session = Depends(get_db)):
    if layer_name not in RASTER_LAYER_NAMES:
        raise HTTPException(status_code=404, detail="الطبقة غير مدعومة")

    metrics = db.query(TerrainMetrics).filter(TerrainMetrics.project_id == project_id).first()
    if not metrics:
        raise HTTPException(status_code=404, detail="لا توجد نتائج تحليل للمشروع")

    layers = (metrics.source_metadata or {}).get("raster_layers", {}) or {}
    info = layers.get(layer_name)

    if not info:
        raise HTTPException(status_code=404, detail="بيانات الطبقة غير متاحة")

    return {
        "ok": True,
        "project_id": project_id,
        "layer": layer_name,
        "metadata": {
            "geotiff_path": info.get("geotiff_path"),
            "available": info.get("available"),
            "bounds": info.get("bounds"),
            "crs": info.get("crs", "EPSG:4326"),
            "min": info.get("min"),
            "max": info.get("max"),
            "mean": info.get("mean"),
            "std": info.get("std"),
            "tiling": "rio-tiler endpoint",
            "tile_endpoint": f"/projects/{project_id}/layers/{layer_name}/tiles/{{z}}/{{x}}/{{y}}.png",
        },
    }


@app.get("/radar/corridor")
def radar_corridor_alias():
    items = [item.__dict__ for item in build_radar_library()]
    return {"ok": True, "corridor": build_corridor_decision(items), "items": items}


@app.get("/bouh/decision-preview")
def bouh_decision_preview(source: str = "synthetic_fallback"):
    evidence = {
        "source": source,
        "structure_evidence": False,
        "pattern_evidence": True,
        "alteration_evidence": False,
        "spectral_confirmation": False,
        "feox_evidence": True,
    }
    return decide_target_priority(evidence)


@app.get("/projects/{project_id}/report/json")
def project_report_json(project_id: int, db: Session = Depends(get_db)):
    project = db.get(ScanProject, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")

    metrics = db.query(TerrainMetrics).filter(TerrainMetrics.project_id == project_id).first()
    metrics_dict = {}
    source_metadata = {}

    if metrics:
        source_metadata = metrics.source_metadata or {}
        metrics_dict = {
            "min_elevation": metrics.min_elevation,
            "max_elevation": metrics.max_elevation,
            "mean_elevation": metrics.mean_elevation,
            "mean_slope": metrics.mean_slope,
            "roughness_score": metrics.roughness_score,
            "flow_score": metrics.flow_score,
            "raster_layers": list((source_metadata.get("raster_layers") or {}).keys()),
            "dem_source": source_metadata.get("dem_source", "synthetic_fallback"),
        }

    project_dict = {
        "name": project.name,
        "center_lat": project.center_lat,
        "center_lng": project.center_lng,
        "radius_m": project.radius_m,
    }

    evidence = {
        "source": source_metadata.get("dem_source", "synthetic_fallback"),
        "structure_evidence": False,
        "pattern_evidence": bool(metrics),
        "alteration_evidence": False,
        "spectral_confirmation": False,
        "magnetic_ground_risk": None,
        "quartz_qi": None,
    }

    safety = {"source": "open_meteo_or_cache", "status": "not_requested_in_report_endpoint"}
    report = build_project_report_json(project_dict, metrics_dict, source_metadata, safety, evidence)
    return report


@app.get("/projects/{project_id}/report/html")
def project_report_html(project_id: int, db: Session = Depends(get_db)):
    report = project_report_json(project_id, db)
    return Response(content=build_project_report_html(report), media_type="text/html; charset=utf-8")


@app.post("/data-manager/inspect-upload")
async def data_manager_inspect_upload(file: UploadFile = File(...)):
    data = await file.read()
    meta = validate_upload(file.filename or "upload.bin", len(data), file.content_type)
    meta = enrich_with_hash(meta, data)
    return {"ok": not meta["errors"], "workflow": ["Upload", "Inspect", "Classify", "Validate", "Store", "Analyze", "Report"], "file": meta}


@app.get("/data-manager/rules")
def data_manager_rules():
    return {
        "ok": True,
        "accepted_extensions": sorted(list({".tif",".tiff",".jp2",".zip",".geojson",".json",".csv",".mbtiles",".pmtiles",".kml",".kmz",".png",".jpg",".jpeg",".webp"})),
        "context_only": sorted(list({".kml",".kmz",".png",".jpg",".jpeg",".webp"})),
        "dangerous_blocked": sorted(list({".exe",".bat",".cmd",".sh",".ps1",".dll",".so",".dylib",".js",".mjs",".php",".py",".jar",".apk"})),
        "workflow": ["Upload", "Inspect", "Classify", "Validate", "Store", "Analyze", "Report"],
        "scientific_rule_ar": "Google Earth/JPG/PNG/KMZ/KML سياق بصري فقط وليست دليلاً طيفياً رقمياً.",
    }
