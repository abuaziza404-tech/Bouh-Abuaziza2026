from pathlib import Path
import json, hashlib

class SafetyLocalCache:
    def __init__(self, root="/app/data/cache/safety"):
        self.root=Path(root); self.root.mkdir(parents=True, exist_ok=True)
    def path_for(self, lat, lng):
        key=hashlib.sha256(f"{lat:.4f},{lng:.4f}".encode()).hexdigest()
        return self.root/f"{key}.json"
    def save(self, lat, lng, payload):
        self.path_for(lat,lng).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    def load(self, lat, lng):
        p=self.path_for(lat,lng)
        if not p.exists(): return None
        try: return json.loads(p.read_text(encoding="utf-8"))
        except Exception: return None
