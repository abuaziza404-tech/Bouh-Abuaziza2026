from datetime import datetime, timezone
import httpx

class OpenMeteoSafetyConnector:
    base_url = "https://api.open-meteo.com/v1/forecast"
    async def fetch_forecast(self, lat: float, lng: float, hours: int = 48) -> dict:
        params = {
            "latitude": lat, "longitude": lng,
            "current": "temperature_2m,relative_humidity_2m,precipitation,rain,showers,weather_code,cloud_cover,wind_speed_10m,wind_gusts_10m",
            "hourly": "temperature_2m,relative_humidity_2m,precipitation_probability,precipitation,rain,showers,weather_code,cloud_cover,visibility,wind_speed_10m,wind_gusts_10m,soil_temperature_0cm,soil_moisture_0_to_1cm",
            "forecast_hours": hours, "timezone": "auto"
        }
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(self.base_url, params=params)
            r.raise_for_status()
            data = r.json()
        data["_fetched_at"] = datetime.now(timezone.utc).isoformat()
        return data
