from app.bouh_core.evidence_guard import guard_numeric, guard_coordinates


def test_visual_only_blocks_numeric_indices():
    result = guard_numeric("ndvi", 0.5, "visual_only")
    assert result["status"] == "blocked"
    assert "لا توجد بيانات" in result["message_ar"]


def test_real_raster_accepts_numeric_indices():
    result = guard_numeric("ndvi", 0.5, "real_raster")
    assert result["status"] == "accepted"
    assert result["value"] == 0.5


def test_coordinates_need_documented_source():
    result = guard_coordinates(24.0, 46.0, "visual_only")
    assert result["status"] == "blocked"
