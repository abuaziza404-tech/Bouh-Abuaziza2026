from app.bouh_core.gpz_strategy import recommend_gpz_strategy


def test_gpz_high_magnetic():
    result = recommend_gpz_strategy(0.9, 0.2)
    assert result["ground_type"] == "Severe/Difficult"
    assert result["gold_mode"] == "High Yield"


def test_gpz_low_magnetic_high_quartz():
    result = recommend_gpz_strategy(0.3, 0.8)
    assert result["ground_type"] == "Normal"
    assert result["gold_mode"] == "General/Deep"


def test_gpz_insufficient():
    result = recommend_gpz_strategy(None, None)
    assert result["status"] == "insufficient_data"
