import React, { useEffect, useMemo, useState } from "react";
import {
  AppIdentity,
  Project,
  SystemOverview,
  createProject,
  getIdentity,
  getSystemOverview,
  isNetworkError
} from "./api";
import RadarPage from "./RadarPage";
import SafetyPage from "./SafetyPage";
import SourcesPage from "./SourcesPage";
import SecurityPage from "./SecurityPage";
import LibraryPage from "./LibraryPage";
import ReportPage from "./ReportPage";

type Screen = "dashboard" | "radar" | "reports" | "library" | "safety" | "security";

const navItems: Array<{ id: Screen; label: string; icon: string }> = [
  { id: "dashboard", label: "الرئيسية", icon: "⌂" },
  { id: "radar", label: "الرادار", icon: "◎" },
  { id: "reports", label: "التقارير", icon: "▤" },
  { id: "library", label: "المكتبة", icon: "▥" },
  { id: "safety", label: "السلامة", icon: "◈" },
  { id: "security", label: "الإعدادات", icon: "⚙" }
];

export default function App() {
  const [screen, setScreen] = useState<Screen>("dashboard");
  const [lat, setLat] = useState(19.41022162800518);
  const [lng, setLng] = useState(36.86820999932388);
  const [project, setProject] = useState<Project | null>(null);
  const [message, setMessage] = useState("جاهز للعمل المحلي");
  const [identity, setIdentity] = useState<AppIdentity | null>(null);
  const [overview, setOverview] = useState<SystemOverview | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isCreatingProject, setIsCreatingProject] = useState(false);

  useEffect(() => {
    refreshIdentityAndOverview();

    const online = () => {
      setIsOnline(true);
      setMessage("الاتصال متاح. تبقى قراءة الأرض محلية.");
    };

    const offline = () => {
      setIsOnline(false);
      setMessage("Offline: قاعدة التحليل المحلية والرادار يعملان بدون اتصال خارجي.");
    };

    window.addEventListener("online", online);
    window.addEventListener("offline", offline);

    return () => {
      window.removeEventListener("online", online);
      window.removeEventListener("offline", offline);
    };
  }, []);

  async function refreshIdentityAndOverview() {
    try {
      const [id, sys] = await Promise.all([getIdentity(), getSystemOverview()]);
      setIdentity(id);
      setOverview(sys);
    } catch (error) {
      setMessage(isNetworkError(error) ? "يعمل محليًا. API غير متصل حاليًا." : "تعذر تحديث حالة النظام.");
    }
  }

  async function ensureProject(): Promise<Project | null> {
    if (project) return project;

    setIsCreatingProject(true);

    try {
      const created = await createProject({
        name: `رادار ميداني ${new Date().toLocaleString("ar")}`,
        center_lat: lat,
        center_lng: lng,
        radius_m: 300,
        soil_type: "سطحي",
        terrain_type: "Landsat/DEM"
      });

      setProject(created);
      setMessage(`تم إنشاء مشروع ميداني #${created.id}.`);
      return created;
    } catch (error) {
      setMessage(error instanceof Error ? `تعذر إنشاء المشروع: ${error.message}` : "تعذر إنشاء المشروع.");
      return null;
    } finally {
      setIsCreatingProject(false);
    }
  }

  async function openRadar() {
    await ensureProject();
    setScreen("radar");
  }

  const currentTitle = useMemo(() => navItems.find((item) => item.id === screen)?.label ?? "بوح التضاريس", [screen]);

  return (
    <main className="app-shell professional-shell" dir="rtl">
      <header className="topbar professional-topbar">
        <div className="brand">
          <div className="brand-mark bouh-icon-mini" aria-hidden="true" />
          <div>
            <h1>بوح التضاريس</h1>
            <p>{currentTitle} · Offline-first</p>
          </div>
        </div>

        <div className={isOnline ? "net-pill online" : "net-pill offline"}>
          {isOnline ? "محلي + اتصال" : "Offline"}
        </div>
      </header>

      <div className="status-line compact-status">{message}</div>

      {screen === "dashboard" && (
        <Dashboard
          overview={overview}
          project={project}
          isOnline={isOnline}
          onOpenRadar={openRadar}
          onNavigate={setScreen}
          isCreatingProject={isCreatingProject}
        />
      )}

      {screen === "radar" && (
        <RadarPage
          project={project}
          lat={lat}
          lng={lng}
          onCoords={(nextLat, nextLng) => {
            setLat(nextLat);
            setLng(nextLng);
          }}
          onMessage={setMessage}
        />
      )}

      {screen === "reports" && <ReportPage project={project} onMessage={setMessage} />}
      {screen === "library" && <LibraryPage onMessage={setMessage} />}
      {screen === "safety" && <SafetyPage lat={lat} lng={lng} projectId={project?.id ?? null} onMessage={setMessage} />}
      {screen === "security" && (
        <>
          <SecurityPage identity={identity} onMessage={setMessage} />
          <SourcesPage onMessage={setMessage} />
        </>
      )}

      <nav className="bottom-nav professional-bottom-nav" aria-label="أقسام التطبيق">
        {navItems.map((item) => (
          <button key={item.id} type="button" className={screen === item.id ? "active" : ""} onClick={() => setScreen(item.id)}>
            <span>{item.icon}</span>
            <small>{item.label}</small>
          </button>
        ))}
      </nav>
    </main>
  );
}

function Dashboard({
  overview,
  project,
  isOnline,
  onOpenRadar,
  onNavigate,
  isCreatingProject
}: {
  overview: SystemOverview | null;
  project: Project | null;
  isOnline: boolean;
  onOpenRadar: () => void;
  onNavigate: (screen: Screen) => void;
  isCreatingProject: boolean;
}) {
  const apiExternal = overview?.operating_mode?.online_features_available ? "اختياري" : "لا يوجد اتصال API خارجي";

  return (
    <section className="screen home-clean">
      <article className="home-hero-card">
        <span className="eyebrow">BOUH Terrain</span>
        <h2>بوح التضاريس</h2>
        <p>منظومة تحليل ميداني Offline-first للطبقات السطحية والتضاريس.</p>

        <div className="home-status-grid">
          <StatusPill label="يعمل محليًا" value={isOnline ? "نشط" : "Offline"} />
          <StatusPill label="قاعدة التحليل" value="4303 خلية" />
          <StatusPill label="نوع التحليل" value="Landsat/DEM جزئي" />
          <StatusPill label="API خارجي" value={apiExternal} />
        </div>

        <div className="home-actions">
          <button className="primary xl" type="button" onClick={onOpenRadar} disabled={isCreatingProject}>
            {isCreatingProject ? "جاري التجهيز..." : "فتح رادار التحليل"}
          </button>
          <button className="secondary xl" type="button" onClick={() => onNavigate("library")}>
            المكتبة / إدارة البيانات
          </button>
        </div>
      </article>

      <article className="truth-card">
        <strong>No Gold Proof</strong>
        <span>Surface Screening</span>
        <span>Field-check</span>
      </article>

      <section className="home-quick-grid">
        <button type="button" onClick={() => onNavigate("reports")}>تقرير نقطة</button>
        <button type="button" onClick={() => onNavigate("safety")}>السلامة</button>
        <button type="button" onClick={() => onNavigate("security")}>الإعدادات</button>
      </section>

      {project && (
        <article className="compact-project-card">
          <span>المشروع الحالي</span>
          <strong>#{project.id}</strong>
          <small>{project.center_lat.toFixed(5)}, {project.center_lng.toFixed(5)}</small>
        </article>
      )}
    </section>
  );
}

function StatusPill({ label, value }: { label: string; value: string }) {
  return (
    <div className="status-pill">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
