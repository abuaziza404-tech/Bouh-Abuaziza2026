import React, { useEffect, useState } from "react";
import { EmergencyForecast, EmergencySource, getEmergencyForecast, getEmergencySources } from "./api";

export default function EmergencyPage({
  lat,
  lng,
  onMessage
}: {
  lat: number;
  lng: number;
  onMessage: (message: string) => void;
}) {
  const [sources, setSources] = useState<EmergencySource[]>([]);
  const [forecast, setForecast] = useState<EmergencyForecast | null>(null);
  const [radiusKm, setRadiusKm] = useState(50);
  const [hours, setHours] = useState(72);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSources();
    runForecast();
  }, []);

  async function loadSources() {
    try {
      const response = await getEmergencySources();
      setSources(response.sources);
    } catch {
      setSources([]);
    }
  }

  async function runForecast() {
    setLoading(true);

    try {
      const response = await getEmergencyForecast(lat, lng, radiusKm, hours, true);
      setForecast(response);
      setSources(response.sources);
      onMessage(response.summary_ar);
    } catch {
      onMessage("تم استخدام وضع الطوارئ المحلي؛ تعذر الاتصال بمصادر التحديث.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="screen emergency-screen">
      <article className="hero-card compact emergency-hero">
        <span className="eyebrow">قسم الحالات الطارئة</span>
        <h2>تنبؤ وربط بأحدث مصادر الأقمار والأنظمة عند الطوارئ</h2>
        <p>يربط Copernicus EMS وNASA FIRMS وOpen‑Meteo ومحرك السلامة المحلي لتقدير السيول والرياح والحرائق والرؤية.</p>
        <div className="action-row">
          <button className="primary" type="button" onClick={runForecast}>{loading ? "جاري..." : "تشغيل التنبؤ"}</button>
          <button className="secondary" type="button" onClick={loadSources}>تحديث المصادر</button>
        </div>
      </article>

      <article className="panel emergency-controls">
        <label>
          نطاق المتابعة: {radiusKm} كم
          <input type="range" min={5} max={300} step={5} value={radiusKm} onChange={(event) => setRadiusKm(Number(event.target.value))} />
        </label>
        <label>
          مدة التنبؤ: {hours} ساعة
          <input type="range" min={12} max={168} step={12} value={hours} onChange={(event) => setHours(Number(event.target.value))} />
        </label>
      </article>

      {forecast && (
        <>
          <article className={`emergency-summary emergency-${forecast.overall_level}`}>
            <span>مؤشر الطوارئ العام</span>
            <strong>{Math.round(forecast.overall_score)}/100</strong>
            <p>{forecast.summary_ar}</p>
          </article>

          <section className="emergency-risk-grid">
            {forecast.risks.map((risk) => (
              <article key={risk.name} className={`emergency-risk emergency-${risk.level}`}>
                <div className="risk-score">{Math.round(risk.score)}</div>
                <h3>{risk.label_ar}</h3>
                <p>{risk.message_ar}</p>
              </article>
            ))}
          </section>

          <article className="panel">
            <h3>إجراءات موصى بها</h3>
            <ul className="clean-list">
              {forecast.recommended_actions.map((action) => <li key={action}>{action}</li>)}
            </ul>
          </article>
        </>
      )}

      <article className="panel">
        <div className="panel-head">
          <h3>مصادر الطوارئ المتصلة</h3>
          <span>{sources.length}</span>
        </div>
        <section className="emergency-source-grid">
          {sources.map((source) => (
            <div key={source.id} className="emergency-source-card">
              <strong>{source.label_ar}</strong>
              <small>{source.mode} · {source.priority}</small>
              <p>{source.message_ar}</p>
            </div>
          ))}
        </section>
      </article>
    </section>
  );
}
