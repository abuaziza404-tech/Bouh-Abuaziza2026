import React, { useEffect, useState } from "react";
import { RadarLibraryItem, getRadarLibrary } from "./api";

export default function LibraryPage({ onMessage }: { onMessage: (message: string) => void }) {
  const [items, setItems] = useState<RadarLibraryItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const response = await getRadarLibrary();
      setItems(response.items);
      onMessage("تم تحديث مكتبة الرادار.");
    } catch {
      setItems([]);
      onMessage("المكتبة المحلية غير متاحة من API الآن.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="screen concise-page">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">المكتبة / إدارة البيانات</span>
        <h2>مكتبة الرادار الإقليمية</h2>
        <p>بيانات النطاقات والقراءات المحلية تظهر مختصرة للمستخدم الميداني.</p>
        <div className="action-row">
          <button className="primary" type="button" onClick={load}>{loading ? "جاري..." : "تحديث المكتبة"}</button>
          <button className="secondary" type="button" onClick={() => onMessage("قاعدة التحليل: 4303 خلية · Landsat/DEM جزئي · ليست Sentinel/SWIR كاملة.")}>
            عرض حالة قاعدة التحليل
          </button>
        </div>
      </article>

      <article className="panel clean-card">
        <h3>النطاقات</h3>
        <div className="region-list">
          <Region name="South" detail="نطاق الجنوب" />
          <Region name="Center" detail="نطاق الوسط" />
          <Region name="North" detail="نطاق الشمال" />
          <Region name="السيقات المحلية" detail="سياقات ميدانية/محلية" />
        </div>
      </article>

      <article className="panel clean-card">
        <h3>قاعدة التحليل</h3>
        <div className="status-list">
          <div><span>عدد الخلايا</span><strong>4303</strong></div>
          <div><span>المصادر</span><strong>Landsat/DEM</strong></div>
          <div><span>نوع التحليل</span><strong>partial ready analyzed ground grid</strong></div>
          <div><span>Sentinel/SWIR</span><strong>غير كامل</strong></div>
        </div>
      </article>

      {items.length > 0 && (
        <article className="panel clean-card">
          <h3>عناصر محلية</h3>
          <div className="library-compact-list">
            {items.slice(0, 8).map((item) => (
              <div key={item.role}>
                <strong>{item.label_ar}</strong>
                <span>{item.band_count} bands · {item.analysis_status}</span>
              </div>
            ))}
          </div>
        </article>
      )}
    </section>
  );
}

function Region({ name, detail }: { name: string; detail: string }) {
  return (
    <div>
      <strong>{name}</strong>
      <span>{detail}</span>
    </div>
  );
}
