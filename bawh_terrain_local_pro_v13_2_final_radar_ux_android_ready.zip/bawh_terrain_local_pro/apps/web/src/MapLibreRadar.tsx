import React, { useEffect, useMemo, useRef, useState } from "react";
import maplibregl, { Map, Marker, NavigationControl } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { Protocol } from "pmtiles";
import { OfflineMapPack, ProjectLayer, RadarLibraryItem, apiUrl, listOfflineMapPacks, uploadOfflineMapPack } from "./api";
import { getBouhRadarBootstrap } from "./bouh/api";
import type { BouhRadarBootstrap, BouhScreeningPoint, BouhTarget } from "./bouh/types";

type BaseMapMode = "osm" | "esri" | "hybrid";

type MapLibreRadarProps = {
  projectId: number | null;
  lat: number;
  lng: number;
  radius: number;
  layers: ProjectLayer[];
  enabledLayers?: Record<string, boolean>;
  layerOpacity?: Record<string, number>;
  selectedItem?: RadarLibraryItem | null;
  followMapCenter?: boolean;
  showLocalMaps?: boolean;
  onCoords: (lat: number, lng: number) => void;
  onMessage: (message: string) => void;
};

type OfflineProgress = {
  running: boolean;
  current: number;
  total: number;
  label: string;
};

const ESRI_WORLD_IMAGERY = "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
const ESRI_REFERENCE = "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}";
const OSM_STREETS = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
let pmtilesProtocolRegistered = false;

const baseStyle = {
  version: 8,
  sources: {
    osm: {
      type: "raster",
      tiles: [OSM_STREETS],
      tileSize: 256,
      attribution: "© OpenStreetMap contributors"
    },
    esriWorldImagery: {
      type: "raster",
      tiles: [ESRI_WORLD_IMAGERY],
      tileSize: 256,
      attribution: "Tiles © Esri"
    },
    esriReference: {
      type: "raster",
      tiles: [ESRI_REFERENCE],
      tileSize: 256
    }
  },
  layers: [
    {
      id: "osm",
      type: "raster",
      source: "osm",
      layout: { visibility: "visible" }
    },
    {
      id: "esri-world-imagery",
      type: "raster",
      source: "esriWorldImagery",
      layout: { visibility: "none" }
    },
    {
      id: "esri-reference",
      type: "raster",
      source: "esriReference",
      layout: { visibility: "none" },
      paint: { "raster-opacity": 0.82 }
    }
  ]
};

export default function MapLibreRadar({
  projectId,
  lat,
  lng,
  radius,
  layers,
  enabledLayers = {},
  layerOpacity = {},
  selectedItem,
  followMapCenter = true,
  showLocalMaps = false,
  onCoords,
  onMessage
}: MapLibreRadarProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<Map | null>(null);
  const markerRef = useRef<Marker | null>(null);
  const [baseMapMode, setBaseMapMode] = useState<BaseMapMode>("esri");
  const [offlineProgress, setOfflineProgress] = useState<OfflineProgress>({
    running: false,
    current: 0,
    total: 0,
    label: "جاهز"
  });
  const [offlineMapPacks, setOfflineMapPacks] = useState<OfflineMapPack[]>([]);
  const [selectedMapPackId, setSelectedMapPackId] = useState<number | null>(null);
  const [bouhData, setBouhData] = useState<BouhRadarBootstrap | null>(null);
  const followCenterRef = useRef(followMapCenter);

  useEffect(() => {
    followCenterRef.current = followMapCenter;
  }, [followMapCenter]);

  const offlinePercent = useMemo(() => {
    if (!offlineProgress.total) {
      return 0;
    }

    return Math.round((offlineProgress.current / offlineProgress.total) * 100);
  }, [offlineProgress]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) {
      return;
    }

    registerPmtilesProtocol();

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: baseStyle as any,
      center: [lng, lat],
      zoom: 13,
      pitch: 0,
      bearing: 0,
      attributionControl: { compact: true }
    });

    map.addControl(new NavigationControl({ visualizePitch: true }), "bottom-left");

    const markerElement = document.createElement("div");
    markerElement.className = "map-radar-marker";
    markerElement.innerHTML = "<span>⌖</span>";

    const marker = new maplibregl.Marker({
      element: markerElement,
      anchor: "center",
      draggable: true
    }).setLngLat([lng, lat]).addTo(map);

    marker.on("dragend", () => {
      const next = marker.getLngLat();
      onCoords(next.lat, next.lng);
      onMessage("تم تحديث مركز الرادار من الخريطة.");
    });

    map.on("click", (event) => {
      marker.setLngLat([event.lngLat.lng, event.lngLat.lat]);
      onCoords(event.lngLat.lat, event.lngLat.lng);
      onMessage("تم تحديد مركز جديد للرادار.");
    });

    map.on("moveend", () => {
      if (!followCenterRef.current) {
        return;
      }
      const center = map.getCenter();
      marker.setLngLat([center.lng, center.lat]);
      onCoords(center.lat, center.lng);
    });

    map.on("load", () => {
      syncBaseMap(map, baseMapMode);
      syncRadius(map, lng, lat, radius);
      syncSelectedBounds(map, selectedItem);
      syncProjectLayers(map, projectId, layers, enabledLayers, layerOpacity);
      syncBouhOverlay(map, bouhData, onCoords, onMessage);
    });

    mapRef.current = map;
    markerRef.current = marker;

    return () => {
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
    };
  }, []);

  useEffect(() => {
    loadOfflineMapPacks();
    loadBouhOverlay();
  }, []);

  async function loadBouhOverlay() {
    try {
      const payload = await getBouhRadarBootstrap();
      setBouhData(payload);
      onMessage("تم تحميل overlay بوح الخفيف فوق الخريطة.");
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "لا يوجد cache محلي لبيانات بوح الخفيفة.");
    }
  }

  useEffect(() => {
    const map = mapRef.current;

    if (map && map.isStyleLoaded()) {
      syncOfflineMapPack(map, selectedMapPackId, offlineMapPacks);
    }
  }, [selectedMapPackId, offlineMapPacks]);

  useEffect(() => {
    const map = mapRef.current;

    if (map && map.isStyleLoaded()) {
      syncBaseMap(map, baseMapMode);
    }
  }, [baseMapMode]);

  useEffect(() => {
    const map = mapRef.current;
    const marker = markerRef.current;

    if (!map || !marker) {
      return;
    }

    marker.setLngLat([lng, lat]);

    if (map.isStyleLoaded()) {
      syncRadius(map, lng, lat, radius);
    }
  }, [lat, lng, radius]);

  useEffect(() => {
    const map = mapRef.current;

    if (map && map.isStyleLoaded()) {
      syncProjectLayers(map, projectId, layers, enabledLayers, layerOpacity);
    }
  }, [projectId, layers, enabledLayers, layerOpacity]);

  useEffect(() => {
    const map = mapRef.current;

    if (map && map.isStyleLoaded()) {
      syncSelectedBounds(map, selectedItem);
    }
  }, [selectedItem]);

  useEffect(() => {
    const map = mapRef.current;

    if (map && map.isStyleLoaded()) {
      syncBouhOverlay(map, bouhData, onCoords, onMessage);
    }
  }, [bouhData]);

  async function saveOfflineArea() {
    if (offlineProgress.running) {
      return;
    }

    const minZoom = 11;
    const maxZoom = 16;
    const bounds = buildBoundsFromRadius(lat, lng, radius * 1.8);
    const requests: Array<{ url: string; label: string }> = [];

    for (let zoom = minZoom; zoom <= maxZoom; zoom += 1) {
      const range = tileRangeForBounds(bounds, zoom);

      for (let x = range.minX; x <= range.maxX; x += 1) {
        for (let y = range.minY; y <= range.maxY; y += 1) {
          requests.push({
            url: tileUrl(ESRI_WORLD_IMAGERY, zoom, x, y),
            label: `Esri ${zoom}/${x}/${y}`
          });
          requests.push({
            url: tileUrl(OSM_STREETS, zoom, x, y),
            label: `OSM ${zoom}/${x}/${y}`
          });
          requests.push({
            url: tileUrl(ESRI_REFERENCE, zoom, x, y),
            label: `Reference ${zoom}/${x}/${y}`
          });
        }
      }
    }

    setOfflineProgress({
      running: true,
      current: 0,
      total: requests.length,
      label: "بدء حفظ الخرائط"
    });

    let saved = 0;
    let failed = 0;

    for (let index = 0; index < requests.length; index += 1) {
      const request = requests[index];

      try {
        await fetch(request.url, {
          mode: "no-cors",
          cache: "force-cache"
        });
        saved += 1;
      } catch {
        failed += 1;
      }

      setOfflineProgress({
        running: true,
        current: index + 1,
        total: requests.length,
        label: request.label
      });

      await sleep(16);
    }

    setOfflineProgress({
      running: false,
      current: requests.length,
      total: requests.length,
      label: `اكتمل الحفظ: ${saved} محفوظ / ${failed} فشل`
    });

    onMessage(`تم تجهيز المنطقة للعمل Offline: ${saved} tiles محفوظة في Cache المتصفح.`);
  }

  async function loadOfflineMapPacks() {
    try {
      const packs = await listOfflineMapPacks();
      setOfflineMapPacks(packs);
      const firstMbtiles = packs.find((pack) => pack.pack_type === "mbtiles");
      if (!selectedMapPackId && firstMbtiles) {
        setSelectedMapPackId(firstMbtiles.id);
      }
    } catch {
      setOfflineMapPacks([]);
    }
  }

  async function uploadMapPack(file: File) {
    try {
      const pack = await uploadOfflineMapPack(file);
      await loadOfflineMapPacks();
      if (pack.pack_type === "mbtiles") {
        setSelectedMapPackId(pack.id);
      }
      onMessage(`تم رفع حزمة خرائط Offline: ${pack.name}`);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل رفع حزمة الخرائط.");
    }
  }

  return (
    <div className="maplibre-pro-wrap">
      <div ref={containerRef} className="maplibre-pro-map" />
      <div className="maplibre-radar-overlay radar-crosshair" />
      <div className="maplibre-crosshair map-center-crosshair" aria-hidden="true" />

      <div className="maplibre-layer-switcher compact">
        <button className={baseMapMode === "esri" ? "active" : ""} onClick={() => setBaseMapMode("esri")} type="button">Esri</button>
        <button className={baseMapMode === "hybrid" ? "active" : ""} onClick={() => setBaseMapMode("hybrid")} type="button">Hybrid</button>
        <button className={baseMapMode === "osm" ? "active" : ""} onClick={() => setBaseMapMode("osm")} type="button">OSM</button>
      </div>

      <div className="maplibre-gps-card compact">
        <span>{followMapCenter ? "تتبع المركز" : "دبوس مثبت"}</span>
        <b>{lat.toFixed(5)}, {lng.toFixed(5)}</b>
      </div>

      {showLocalMaps && (
        <div className="maplibre-local-maps-drawer">
          <div className="map-pack-row">
            <span>إدارة الخرائط المحلية</span>
            <label>
              رفع
              <input
                type="file"
                accept=".mbtiles,.pmtiles"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) uploadMapPack(file);
                }}
              />
            </label>
          </div>

          <select
            value={selectedMapPackId ?? ""}
            onChange={(event) => setSelectedMapPackId(event.target.value ? Number(event.target.value) : null)}
          >
            <option value="">بدون حزمة محلية</option>
            {offlineMapPacks.map((pack) => (
              <option key={pack.id} value={pack.id}>
                {pack.name} · {pack.pack_type === "pmtiles" ? "PMTiles" : "MBTiles"}
              </option>
            ))}
          </select>

          <button type="button" onClick={saveOfflineArea} disabled={offlineProgress.running}>
            {offlineProgress.running ? `حفظ ${offlinePercent}%` : "حفظ المنطقة الحالية Offline"}
          </button>
        </div>
      )}

      <div className="maplibre-map-note compact">
        حرّك الخريطة لتحليل مركز الشاشة
      </div>
    </div>
  );
}


function syncBouhOverlay(
  map: Map,
  data: BouhRadarBootstrap | null,
  onCoords: (lat: number, lng: number) => void,
  onMessage: (message: string) => void
) {
  const sourceIds = ["bouh-official-targets", "bouh-universal-support", "bouh-sentinel2-support"];

  if (!data) {
    for (const sourceId of sourceIds) {
      hideLayer(map, `${sourceId}-circle`);
    }
    return;
  }

  const official = {
    type: "FeatureCollection",
    features: data.official_targets.map((target) => targetFeature(target))
  };
  const universal = {
    type: "FeatureCollection",
    features: data.screening_points.universal_top10.map((point) => pointFeature(point, "universal"))
  };
  const sentinel = {
    type: "FeatureCollection",
    features: data.screening_points.sentinel2_top10.map((point) => pointFeature(point, "sentinel2"))
  };

  upsertBouhSourceAndLayer(map, "bouh-official-targets", official, "#f2c14e", 7);
  upsertBouhSourceAndLayer(map, "bouh-universal-support", universal, "#20e28a", 5);
  upsertBouhSourceAndLayer(map, "bouh-sentinel2-support", sentinel, "#4fb3ff", 5);

  attachBouhPopupHandlers(map, onCoords, onMessage);
}

function upsertBouhSourceAndLayer(map: Map, sourceId: string, data: any, color: string, radius: number) {
  const layerId = `${sourceId}-circle`;
  const source = map.getSource(sourceId) as maplibregl.GeoJSONSource | undefined;

  if (source) {
    source.setData(data);
    if (map.getLayer(layerId)) {
      map.setLayoutProperty(layerId, "visibility", "visible");
    }
    return;
  }

  map.addSource(sourceId, { type: "geojson", data });

  map.addLayer({
    id: layerId,
    type: "circle",
    source: sourceId,
    paint: {
      "circle-radius": radius,
      "circle-color": color,
      "circle-stroke-color": "#ffffff",
      "circle-stroke-width": 1.5,
      "circle-opacity": 0.92
    }
  });
}

function attachBouhPopupHandlers(
  map: Map,
  onCoords: (lat: number, lng: number) => void,
  onMessage: (message: string) => void
) {
  const mapAny = map as Map & { __bouhHandlersAttached?: boolean };

  if (mapAny.__bouhHandlersAttached) {
    return;
  }

  for (const sourceId of ["bouh-official-targets", "bouh-universal-support", "bouh-sentinel2-support"]) {
    const layerId = `${sourceId}-circle`;

    map.on("mouseenter", layerId, () => {
      map.getCanvas().style.cursor = "pointer";
    });

    map.on("mouseleave", layerId, () => {
      map.getCanvas().style.cursor = "";
    });

    map.on("click", layerId, (event) => {
      const feature = event.features?.[0];

      if (!feature || !feature.geometry || feature.geometry.type !== "Point") {
        return;
      }

      const coordinates = feature.geometry.coordinates.slice() as [number, number];
      const props = feature.properties ?? {};

      new maplibregl.Popup({ closeButton: true, closeOnClick: true, maxWidth: "320px" })
        .setLngLat(coordinates)
        .setHTML(buildBouhPopupHTML(props))
        .addTo(map);

      onCoords(coordinates[1], coordinates[0]);
      map.easeTo({ center: coordinates, zoom: Math.max(map.getZoom(), 13), duration: 700 });
      onMessage(`تم تحديد نقطة بوح خفيفة: ${String(props.label ?? props.id ?? "Field-check")}`);
    });
  }

  mapAny.__bouhHandlersAttached = true;
}

function targetFeature(target: BouhTarget) {
  return {
    type: "Feature",
    properties: {
      id: target.target_id,
      label: `${target.target_id} — ${target.name}`,
      source: target.source,
      evidence_class: target.evidence_class,
      truth_status: target.truth_status,
      limitation_ar: target.limitation_ar,
      calculation_allowed: String(target.calculation_allowed),
      proof_status: target.proof_status,
      layer_type: "official_field_check"
    },
    geometry: {
      type: "Point",
      coordinates: [target.longitude, target.latitude]
    }
  };
}

function pointFeature(point: BouhScreeningPoint, kind: "universal" | "sentinel2") {
  const score = point.score ?? point.score_relative;
  return {
    type: "Feature",
    properties: {
      id: `${kind}-${point.rank}`,
      label: `${kind === "universal" ? "Universal" : "Sentinel-2"} #${point.rank}`,
      score: typeof score === "number" ? score.toFixed(6) : "—",
      source: point.source,
      evidence_class: point.evidence_class,
      truth_status: point.truth_status,
      limitation_ar: point.limitation_ar,
      calculation_allowed: String(point.calculation_allowed),
      proof_status: point.proof_status,
      layer_type: kind === "universal" ? "relative_support" : "sentinel2_relative_support"
    },
    geometry: {
      type: "Point",
      coordinates: [point.longitude, point.latitude]
    }
  };
}

function buildBouhPopupHTML(props: any) {
  const safe = (value: unknown) => String(value ?? "غير متوفر")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");

  return `
    <div dir="rtl" style="font-family:system-ui;line-height:1.6;color:#10241f">
      <strong>${safe(props.label)}</strong>
      <div><b>source:</b> ${safe(props.source)}</div>
      <div><b>truth_status:</b> ${safe(props.truth_status)}</div>
      <div><b>evidence_class:</b> ${safe(props.evidence_class)}</div>
      <div><b>proof_status:</b> ${safe(props.proof_status)}</div>
      <div><b>calculation_allowed:</b> ${safe(props.calculation_allowed)}</div>
      <hr />
      <div style="color:#8a4b00"><b>limitation_ar:</b> ${safe(props.limitation_ar)}</div>
      <div style="margin-top:6px;color:#b00020;font-weight:700">ليست Gold Target ولا تثبت هدفًا تحت الأرض.</div>
    </div>
  `;
}


function syncBaseMap(map: Map, mode: BaseMapMode) {
  setLayerVisibility(map, "osm", mode === "osm");
  setLayerVisibility(map, "esri-world-imagery", mode === "esri" || mode === "hybrid");
  setLayerVisibility(map, "esri-reference", mode === "hybrid");
}

function setLayerVisibility(map: Map, layerId: string, visible: boolean) {
  if (map.getLayer(layerId)) {
    map.setLayoutProperty(layerId, "visibility", visible ? "visible" : "none");
  }
}

function syncOfflineMapPack(map: Map, packId: number | null, packs: OfflineMapPack[]) {
  const rasterSourceId = "offline-map-pack-source";
  const rasterLayerId = "offline-map-pack-layer";
  const pmtilesSourceId = "offline-pmtiles-source";
  const pmtilesLayerId = "offline-pmtiles-layer";
  const selected = packs.find((pack) => pack.id === packId);

  hideLayer(map, rasterLayerId);
  hideLayer(map, pmtilesLayerId);

  if (!selected) {
    return;
  }

  if (selected.pack_type === "mbtiles" && selected.tile_url) {
    const tileTemplate = apiUrl(`/offline-map-packs/${selected.id}/tiles/{z}/{x}/{y}.png`);

    if (!map.getSource(rasterSourceId)) {
      map.addSource(rasterSourceId, {
        type: "raster",
        tiles: [tileTemplate],
        tileSize: 256,
        minzoom: selected.min_zoom ?? 0,
        maxzoom: selected.max_zoom ?? 22
      });

      map.addLayer({
        id: rasterLayerId,
        type: "raster",
        source: rasterSourceId,
        paint: {
          "raster-opacity": 1
        }
      }, "scan-radius-fill");
    } else if (map.getLayer(rasterLayerId)) {
      map.setLayoutProperty(rasterLayerId, "visibility", "visible");
    }

    return;
  }

  if (selected.pack_type === "pmtiles" && selected.pmtiles_url) {
    const pmtilesUrl = `pmtiles://${apiUrl(`/offline-map-packs/${selected.id}/file.pmtiles`)}`;

    try {
      if (!map.getSource(pmtilesSourceId)) {
        map.addSource(pmtilesSourceId, {
          type: "raster",
          url: pmtilesUrl
        } as any);

        map.addLayer({
          id: pmtilesLayerId,
          type: "raster",
          source: pmtilesSourceId,
          paint: {
            "raster-opacity": 1
          }
        } as any, "scan-radius-fill");
      } else if (map.getLayer(pmtilesLayerId)) {
        map.setLayoutProperty(pmtilesLayerId, "visibility", "visible");
      }
    } catch {
      if (map.getLayer(pmtilesLayerId)) {
        map.setLayoutProperty(pmtilesLayerId, "visibility", "none");
      }
    }
  }
}

function hideLayer(map: Map, layerId: string) {
  if (map.getLayer(layerId)) {
    map.setLayoutProperty(layerId, "visibility", "none");
  }
}

function registerPmtilesProtocol() {
  if (pmtilesProtocolRegistered) {
    return;
  }

  const protocol = new Protocol();
  maplibregl.addProtocol("pmtiles", protocol.tile);
  pmtilesProtocolRegistered = true;
}

function syncProjectLayers(map: Map, projectId: number | null, layers: ProjectLayer[], enabledLayers: Record<string, boolean> = {}, layerOpacity: Record<string, number> = {}) {
  const existingLayerIds = ["hillshade", "slope", "flow", "ndvi", "ndwi", "bsi", "ndmi"].map((name) => `raster-${name}`);

  for (const layerId of existingLayerIds) {
    if (map.getLayer(layerId)) {
      map.setLayoutProperty(layerId, "visibility", "none");
    }
  }

  if (!projectId) {
    return;
  }

  for (const layer of layers) {
    if (!layer.available || enabledLayers[layer.name] === false) {
      continue;
    }

    const sourceId = `raster-source-${layer.name}`;
    const layerId = `raster-${layer.name}`;
    const tileEndpoint = apiUrl(`/projects/${projectId}/layers/${layer.name}/tiles/{z}/{x}/{y}.png`);

    if (!map.getSource(sourceId)) {
      map.addSource(sourceId, {
        type: "raster",
        tiles: [tileEndpoint],
        tileSize: 256
      });

      map.addLayer({
        id: layerId,
        type: "raster",
        source: sourceId,
        paint: {
          "raster-opacity": (layerOpacity[layer.name] ?? (layer.name === "hillshade" ? 45 : 62)) / 100
        }
      });
    } else if (map.getLayer(layerId)) {
      map.setPaintProperty(layerId, "raster-opacity", (layerOpacity[layer.name] ?? (layer.name === "hillshade" ? 45 : 62)) / 100);
      map.setLayoutProperty(layerId, "visibility", "visible");
    }
  }
}

function syncSelectedBounds(map: Map, item?: RadarLibraryItem | null) {
  const sourceId = "selected-library-bounds";
  const fillId = "selected-library-bounds-fill";
  const lineId = "selected-library-bounds-line";

  if (!item || item.west === null || item.south === null || item.east === null || item.north === null) {
    if (map.getLayer(fillId)) {
      map.setLayoutProperty(fillId, "visibility", "none");
    }
    if (map.getLayer(lineId)) {
      map.setLayoutProperty(lineId, "visibility", "none");
    }
    return;
  }

  const data = {
    type: "FeatureCollection",
    features: [
      {
        type: "Feature",
        properties: {
          role: item.role,
          label_ar: item.label_ar,
          ndvi_mean: item.ndvi_mean,
          ndwi_mean: item.ndwi_mean,
          bsi_mean: item.bsi_mean
        },
        geometry: {
          type: "Polygon",
          coordinates: [[
            [item.west, item.south],
            [item.east, item.south],
            [item.east, item.north],
            [item.west, item.north],
            [item.west, item.south]
          ]]
        }
      }
    ]
  };

  const existing = map.getSource(sourceId) as maplibregl.GeoJSONSource | undefined;

  if (existing) {
    existing.setData(data as any);
    if (map.getLayer(fillId)) map.setLayoutProperty(fillId, "visibility", "visible");
    if (map.getLayer(lineId)) map.setLayoutProperty(lineId, "visibility", "visible");
  } else {
    map.addSource(sourceId, { type: "geojson", data: data as any });
    map.addLayer({
      id: fillId,
      type: "fill",
      source: sourceId,
      paint: {
        "fill-color": "#f2c14e",
        "fill-opacity": 0.18
      }
    });
    map.addLayer({
      id: lineId,
      type: "line",
      source: sourceId,
      paint: {
        "line-color": "#f2c14e",
        "line-width": 3
      }
    });
  }

  map.fitBounds(
    [
      [item.west, item.south],
      [item.east, item.north]
    ],
    { padding: 38, duration: 800 }
  );
}

function syncRadius(map: Map, lng: number, lat: number, radiusMeters: number) {
  const source = map.getSource("scan-radius") as maplibregl.GeoJSONSource | undefined;
  const data = buildCircleGeoJSON(lng, lat, radiusMeters);

  if (source) {
    source.setData(data as any);
    return;
  }

  map.addSource("scan-radius", {
    type: "geojson",
    data: data as any
  });

  map.addLayer({
    id: "scan-radius-fill",
    type: "fill",
    source: "scan-radius",
    paint: {
      "fill-color": "#20e28a",
      "fill-opacity": 0.12
    }
  });

  map.addLayer({
    id: "scan-radius-line",
    type: "line",
    source: "scan-radius",
    paint: {
      "line-color": "#20e28a",
      "line-width": 2
    }
  });
}

function buildCircleGeoJSON(centerLng: number, centerLat: number, radiusMeters: number) {
  const points = 96;
  const coordinates: number[][] = [];
  const earthRadiusMeters = 6371008.8;
  const angularDistance = radiusMeters / earthRadiusMeters;
  const centerLatRad = degreesToRadians(centerLat);
  const centerLngRad = degreesToRadians(centerLng);

  for (let index = 0; index <= points; index += 1) {
    const bearing = (index / points) * Math.PI * 2;

    const latRad = Math.asin(
      Math.sin(centerLatRad) * Math.cos(angularDistance)
      + Math.cos(centerLatRad) * Math.sin(angularDistance) * Math.cos(bearing)
    );

    const lngRad = centerLngRad + Math.atan2(
      Math.sin(bearing) * Math.sin(angularDistance) * Math.cos(centerLatRad),
      Math.cos(angularDistance) - Math.sin(centerLatRad) * Math.sin(latRad)
    );

    coordinates.push([radiansToDegrees(lngRad), radiansToDegrees(latRad)]);
  }

  return {
    type: "Feature",
    properties: {},
    geometry: {
      type: "Polygon",
      coordinates: [coordinates]
    }
  };
}

function buildBoundsFromRadius(lat: number, lng: number, radiusMeters: number) {
  const latDelta = radiusMeters / 111320;
  const lngDelta = radiusMeters / (111320 * Math.cos(degreesToRadians(lat)));

  return {
    west: lng - lngDelta,
    south: lat - latDelta,
    east: lng + lngDelta,
    north: lat + latDelta
  };
}

function tileRangeForBounds(bounds: { west: number; south: number; east: number; north: number }, zoom: number) {
  const northWest = lngLatToTile(bounds.west, bounds.north, zoom);
  const southEast = lngLatToTile(bounds.east, bounds.south, zoom);

  return {
    minX: Math.max(0, Math.min(northWest.x, southEast.x)),
    maxX: Math.max(northWest.x, southEast.x),
    minY: Math.max(0, Math.min(northWest.y, southEast.y)),
    maxY: Math.max(northWest.y, southEast.y)
  };
}

function lngLatToTile(lng: number, lat: number, zoom: number) {
  const n = 2 ** zoom;
  const latRad = degreesToRadians(Math.max(-85.05112878, Math.min(85.05112878, lat)));
  const x = Math.floor(((lng + 180) / 360) * n);
  const y = Math.floor(((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * n);

  return { x, y };
}

function tileUrl(template: string, zoom: number, x: number, y: number) {
  return template
    .replace("{z}", String(zoom))
    .replace("{x}", String(x))
    .replace("{y}", String(y));
}

function sleep(milliseconds: number) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

function degreesToRadians(value: number) {
  return value * Math.PI / 180;
}

function radiansToDegrees(value: number) {
  return value * 180 / Math.PI;
}
