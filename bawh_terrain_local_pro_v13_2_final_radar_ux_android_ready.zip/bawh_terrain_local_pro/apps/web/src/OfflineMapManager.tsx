import React, { useEffect, useState } from "react";
import {
  OfflineMapDownloadJob,
  createOfflineMapDownload,
  getOfflineMapDownloadPlan,
  listOfflineMapDownloads,
  markOfflineMapDownloadComplete
} from "./api";

export default function OfflineMapManager({
  lat,
  lng,
  radius,
  onMessage
}: {
  lat: number;
  lng: number;
  radius: number;
  onMessage: (message: string) => void;
}) {
  const [jobs, setJobs] = useState<OfflineMapDownloadJob[]>([]);
  const [minZoom, setMinZoom] = useState(11);
  const [maxZoom, setMaxZoom] = useState(16);
  const [busyJobId, setBusyJobId] = useState<number | null>(null);
  const [progress, setProgress] = useState({ current: 0, total: 0 });

  useEffect(() => {
    loadJobs();
  }, []);

  async function loadJobs() {
    try {
      setJobs(await listOfflineMapDownloads());
    } catch {
      setJobs([]);
    }
  }

  async function createPlan() {
    const bounds = buildBoundsFromRadius(lat, lng, radius * 2);

    try {
      const job = await createOfflineMapDownload({
        name: `منطقة ميدانية ${new Date().toLocaleString("ar")}`,
        source: "esri_satellite",
        west: bounds.west,
        south: bounds.south,
        east: bounds.east,
        north: bounds.north,
        min_zoom: minZoom,
        max_zoom: maxZoom,
        include_reference: true,
        include_streets: true
      });
      await loadJobs();
      onMessage(`تم إنشاء خطة Offline: ${job.estimated_tiles} tiles.`);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل إنشاء خطة Offline.");
    }
  }

  async function downloadJob(job: OfflineMapDownloadJob) {
    setBusyJobId(job.id);
    setProgress({ current: 0, total: job.estimated_tiles });

    let downloaded = 0;
    let failed = 0;

    try {
      const plan = await getOfflineMapDownloadPlan(job.id);

      for (let index = 0; index < plan.tiles.length; index += 1) {
        const tile = plan.tiles[index];

        try {
          await fetch(tile.url, { mode: "no-cors", cache: "force-cache" });
          downloaded += 1;
        } catch {
          failed += 1;
        }

        setProgress({ current: index + 1, total: plan.tiles.length });
        await sleep(12);
      }

      await markOfflineMapDownloadComplete(job.id, downloaded, failed);
      await loadJobs();
      onMessage(`اكتمل تنزيل الخطة: ${downloaded} محفوظ / ${failed} فشل.`);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل تنزيل خطة Offline.");
    } finally {
      setBusyJobId(null);
    }
  }

  const percent = progress.total ? Math.round((progress.current / progress.total) * 100) : 0;

  return (
    <article className="panel offline-manager-panel">
      <div className="panel-head">
        <h3>مدير تنزيل خرائط Offline</h3>
        <button type="button" onClick={loadJobs}>تحديث</button>
      </div>

      <div className="offline-zoom-grid">
        <label>
          Min Zoom
          <input type="number" min={0} max={22} value={minZoom} onChange={(event) => setMinZoom(Number(event.target.value))} />
        </label>
        <label>
          Max Zoom
          <input type="number" min={0} max={22} value={maxZoom} onChange={(event) => setMaxZoom(Number(event.target.value))} />
        </label>
      </div>

      <button className="primary" type="button" onClick={createPlan}>
        إنشاء خطة حول مركز الرادار
      </button>

      {busyJobId && (
        <div className="download-progress-card">
          <span>تنزيل Offline</span>
          <strong>{percent}%</strong>
          <div className="offline-progress"><i style={{ width: `${percent}%` }} /></div>
        </div>
      )}

      <div className="offline-job-list">
        {jobs.length === 0 && <p>لا توجد خطط بعد.</p>}

        {jobs.map((job) => (
          <div className="offline-job-card" key={job.id}>
            <div>
              <strong>{job.name}</strong>
              <small>{job.status} · {job.estimated_tiles} tiles · z{job.min_zoom}-{job.max_zoom}</small>
            </div>
            <button type="button" onClick={() => downloadJob(job)} disabled={busyJobId !== null}>
              تنزيل
            </button>
          </div>
        ))}
      </div>
    </article>
  );
}

function buildBoundsFromRadius(lat: number, lng: number, radiusMeters: number) {
  const latDelta = radiusMeters / 111320;
  const lngDelta = radiusMeters / (111320 * Math.cos((lat * Math.PI) / 180));

  return {
    west: lng - lngDelta,
    south: lat - latDelta,
    east: lng + lngDelta,
    north: lat + latDelta
  };
}

function sleep(milliseconds: number) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}
