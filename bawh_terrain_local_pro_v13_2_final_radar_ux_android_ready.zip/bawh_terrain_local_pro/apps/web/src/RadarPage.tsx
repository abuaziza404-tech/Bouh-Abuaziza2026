import React, { useEffect, useMemo, useState } from "react";
import MapLibreRadar from "./MapLibreRadar";
import BouhLiveGroundScoreMeter from "./bouh/BouhLiveGroundScoreMeter";
import "./bouh/bouh_panel.css";
import "./bouh/bouh_live_meter.css";
import { getNativePosition } from "./native";
import {
  Project,
  ProjectLayer,
  RadarLibraryItem,
  getProjectLayers,
  getRadarLibrary,
  getProjectReportHtmlUrl,
  rerunProject,
  startRadarScan
} from "./api";

const layerOrder = ["hillshade", "slope", "flow", "ndvi", "ndwi", "bsi", "ndmi"] as const;
const radiusOptions = [100, 300, 500, 1000] as const;

export default function RadarPage({
  project,
  lat,
  lng,
  onCoords,
  onMessage
}: {
  project: Project | null;
  lat: number;
  lng: number;
  onCoords: (lat: number, lng: number) => void;
  onMessage: (message: string) => void;
}) {
  const [radius, setRadius] = useState<(typeof radiusOptions)[number]>(300);
  const [layers, setLayers] = useState<ProjectLayer[]>([]);
  const [library, setLibrary] = useState<RadarLibraryItem[]>([]);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [followCenter, setFollowCenter] = useState(true);
  const [showLayers, setShowLayers] = useState(false);
  const [showLocalMaps, setShowLocalMaps] = useState(false);
  const [liveScoreRefreshKey, setLiveScoreRefreshKey] = useState(0);
  const [enabledLayers, setEnabledLayers] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(layerOrder.map((name) => [name, true]))
  );
  const [layerOpacity] = useState<Record<string, number>>(() =>
    Object.fromEntries(layerOrder.map((name) => [name, name === "hillshade" ? 45 : 62]))
  );

  const selectedItem = useMemo(() => library.find((item) => item.role === selectedRole) ?? library[0] ?? null, [library, selectedRole]);
  const availableLayerCount = layers.filter((layer) => layer.available).length;

  useEffect(() => {
    refreshRadarContext();
  }, [project?.id]);

  async function refreshRadarContext() {
    await Promise.allSettled([loadLibrary(), loadLayers()]);
  }

  async function loadLibrary() {
    try {
      const response = await getRadarLibrary();
      setLibrary(response.items);
      if (!selectedRole && response.items.length) {
        setSelectedRole(response.items[0].role);
      }
    } catch {
      setLibrary([]);
    }
  }

  async function loadLayers() {
    if (!project) {
      setLayers([]);
      return;
    }

    try {
      setLayers(await getProjectLayers(project.id));
    } catch {
      setLayers([]);
    }
  }

  async function analyzeCenter() {
    setLiveScoreRefreshKey((value) => value + 1);

    if (!project) {
      onMessage("تم تحديث قراءة المركز الحالي من قاعدة Live Score المحلية.");
      return;
    }

    setBusy(true);
    try {
      await startRadarScan({
        project_id: project.id,
        center_lat: lat,
        center_lng: lng,
        radius_m: radius,
        resolution_mode: "high",
        enabled_layers: layerOrder.filter((name) => enabledLayers[name]) as unknown as string[]
      });
      setLiveScoreRefreshKey((value) => value + 1);
      onMessage("تم تحليل المركز الحالي وتحديث قراءة الأرض.");
    } catch (error) {
      setLiveScoreRefreshKey((value) => value + 1);
      onMessage(error instanceof Error ? error.message : "تم تحديث Live Score محليًا، وتعذر تشغيل مهمة API.");
    } finally {
      setBusy(false);
    }
  }

  async function rerunAnalysis() {
    if (!project) {
      setLiveScoreRefreshKey((value) => value + 1);
      onMessage("لا يوجد مشروع API نشط. تم تحديث قراءة المركز محليًا.");
      return;
    }

    setBusy(true);
    try {
      await rerunProject(project.id);
      await loadLayers();
      setLiveScoreRefreshKey((value) => value + 1);
      onMessage("تمت إعادة التحليل للمركز الحالي.");
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشلت إعادة التحليل.");
    } finally {
      setBusy(false);
    }
  }

  async function useNativeGps() {
    const position = await getNativePosition();
    if (!position) {
      onMessage("لم يتم الحصول على GPS من الجهاز.");
      return;
    }

    onCoords(position.lat, position.lng);
    setLiveScoreRefreshKey((value) => value + 1);
    onMessage("تم تحديث موقع الرادار من GPS الجهاز.");
  }

  function openReport() {
    if (!project) {
      onMessage("أنشئ مشروعًا أولًا لتوليد تقرير API. آخر قراءة محفوظة متاحة في صفحة التقارير.");
      return;
    }
    window.open(getProjectReportHtmlUrl(project.id), "_blank", "noopener,noreferrer");
  }

  return (
    <section className="screen radar-pro-screen">
      <header className="radar-pro-header">
        <div>
          <span className="eyebrow">رادار التحليل الميداني</span>
          <h2>تحليل مركز الشاشة</h2>
        </div>
        <div className="radar-header-meta">
          <span>Offline</span>
          <strong>{lat.toFixed(6)}, {lng.toFixed(6)}</strong>
        </div>
      </header>

      <article className="radar-map-shell-pro">
        <MapLibreRadar
          projectId={project?.id ?? null}
          lat={lat}
          lng={lng}
          radius={radius}
          layers={layers}
          enabledLayers={enabledLayers}
          layerOpacity={layerOpacity}
          selectedItem={selectedItem}
          followMapCenter={followCenter}
          showLocalMaps={showLocalMaps}
          onCoords={(nextLat, nextLng) => {
            onCoords(nextLat, nextLng);
            setLiveScoreRefreshKey((value) => value + 1);
          }}
          onMessage={onMessage}
        />

        <div className="radar-floating-actions">
          <button type="button" onClick={() => setShowLayers((value) => !value)}>الطبقات</button>
          <button type="button" onClick={() => setShowLocalMaps((value) => !value)}>الخرائط المحلية</button>
        </div>
      </article>

      <article className="radar-controls-pro">
        <div className="pin-mode-row">
          <button type="button" className={followCenter ? "active" : ""} onClick={() => setFollowCenter(true)}>
            تتبع مركز الشاشة
          </button>
          <button type="button" className={!followCenter ? "active" : ""} onClick={() => setFollowCenter(false)}>
            تثبيت الدبوس
          </button>
        </div>

        <div className="radius-row">
          <span>نطاق القراءة</span>
          <div>
            {radiusOptions.map((value) => (
              <button
                key={value}
                type="button"
                className={radius === value ? "active" : ""}
                onClick={() => {
                  setRadius(value);
                  setLiveScoreRefreshKey((current) => current + 1);
                }}
              >
                {value}m
              </button>
            ))}
          </div>
        </div>

        <div className="action-row compact-actions">
          <button className="primary" type="button" onClick={analyzeCenter} disabled={busy}>
            {busy ? "جاري..." : "تحليل المركز الحالي"}
          </button>
          <button className="secondary" type="button" onClick={useNativeGps}>GPS</button>
          <button className="secondary" type="button" onClick={openReport}>تقرير</button>
        </div>
      </article>

      <BouhLiveGroundScoreMeter
        key={`${lat.toFixed(6)}-${lng.toFixed(6)}-${radius}-${liveScoreRefreshKey}`}
        lat={lat}
        lng={lng}
        radius={radius}
      />

      {showLayers && (
        <details className="panel compact-drawer" open>
          <summary>طبقات التحليل · {availableLayerCount}/{layers.length || layerOrder.length}</summary>
          <div className="layer-mini-list">
            {layerOrder.map((name) => {
              const layer = layers.find((item) => item.name === name);
              return (
                <label key={name}>
                  <input
                    type="checkbox"
                    checked={enabledLayers[name]}
                    onChange={(event) => setEnabledLayers((current) => ({ ...current, [name]: event.target.checked }))}
                  />
                  <span>{name.toUpperCase()}</span>
                  <small>{layer?.available ? "جاهزة" : "غير محسوبة"}</small>
                </label>
              );
            })}
          </div>
        </details>
      )}

      <details className="panel compact-drawer">
        <summary>مكتبة الرادار الإقليمية</summary>
        <div className="library-tabs compact-tabs">
          {library.map((item) => (
            <button
              key={item.role}
              type="button"
              className={selectedItem?.role === item.role ? "active" : ""}
              onClick={() => setSelectedRole(item.role)}
            >
              {item.label_ar}
            </button>
          ))}
        </div>
        {selectedItem && (
          <p className="muted-paragraph">
            {selectedItem.label_ar} · {selectedItem.band_count} bands · {selectedItem.analysis_status}
          </p>
        )}
        <button className="secondary full" type="button" onClick={rerunAnalysis}>تحديث طبقات المشروع</button>
      </details>
    </section>
  );
}
