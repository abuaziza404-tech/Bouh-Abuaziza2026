import React, { useEffect, useState } from "react";
import { Project, getProjectReportHtmlUrl, getProjectReportJson } from "./api";

type LastReading = {
  lat?: number;
  lng?: number;
  radius?: number;
  mode?: string;
  limitation_ar?: string;
  result?: {
    final_ground_score?: number | null;
    class?: string;
    limitation_ar?: string;
  };
};

export default function ReportPage({
  project,
  onMessage
}: {
  project: Project | null;
  onMessage: (message: string) => void;
}) {
  const [last, setLast] = useState<LastReading | null>(() => readLast());
  const [report, setReport] = useState<Record<string, unknown> | null>(null);

  useEffect(() => {
    const handler = () => setLast(readLast());
    window.addEventListener("bouh:last-live-score", handler);
    return () => window.removeEventListener("bouh:last-live-score", handler);
  }, []);

  async function loadReport() {
    if (!project) {
      onMessage("لا يوجد مشروع API. آخر قراءة رادار محفوظة معروضة أدناه.");
      return;
    }

    try {
      const data = await getProjectReportJson(project.id);
      setReport(data);
      onMessage("تم توليد تقرير JSON.");
    } catch {
      onMessage("تعذر توليد تقرير API. استخدم آخر قراءة محفوظة.");
    }
  }

  function exportLastJson() {
    const payload = last ?? { message: "لا توجد قراءة محفوظة بعد." };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "bouh_point_report.json";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section className="screen concise-page">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">التقارير</span>
        <h2>تقرير نقطة ميدانية</h2>
        <div className="action-row">
          <button className="primary" type="button" onClick={loadReport}>إنشاء تقرير نقطة</button>
          <button className="secondary" type="button" onClick={exportLastJson}>تصدير JSON</button>
          {project && <a className="secondary link-button" href={getProjectReportHtmlUrl(project.id)} target="_blank" rel="noreferrer">HTML</a>}
        </div>
      </article>

      <article className="panel clean-card">
        <h3>آخر قراءة</h3>
        <div className="report-summary-grid">
          <Row label="الإحداثيات" value={last?.lat && last?.lng ? `${last.lat.toFixed(6)}, ${last.lng.toFixed(6)}` : "لا توجد"} />
          <Row label="score" value={formatScore(last?.result?.final_ground_score)} />
          <Row label="class" value={last?.result?.class ?? "—"} />
          <Row label="mode" value={last?.mode ?? "—"} />
          <Row label="limitation" value={last?.limitation_ar ?? last?.result?.limitation_ar ?? "تحليل سطحي يحتاج فحصًا ميدانيًا."} />
        </div>
      </article>

      {report && (
        <article className="panel clean-card">
          <h3>ملخص JSON</h3>
          <pre className="compact-json">{JSON.stringify(report, null, 2).slice(0, 1400)}</pre>
        </article>
      )}
    </section>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function formatScore(value: unknown) {
  return typeof value === "number" ? value.toFixed(1) : "—";
}

function readLast(): LastReading | null {
  try {
    const raw = localStorage.getItem("bouh.last_live_ground_score");
    return raw ? JSON.parse(raw) as LastReading : null;
  } catch {
    return null;
  }
}
