import React, { useEffect, useMemo, useState } from "react";
import { SafetyForecastResponse, getSafetyForecast } from "./api";

export default function SafetyPage({
  lat,
  lng,
  projectId,
  onMessage
}: {
  lat: number;
  lng: number;
  projectId: number | null;
  onMessage: (message: string) => void;
}) {
  const [forecast, setForecast] = useState<SafetyForecastResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [hours, setHours] = useState(48);

  useEffect(() => {
    loadForecast();
  }, [lat, lng, hours]);

  async function loadForecast() {
    setLoading(true);

    try {
      const data = await getSafetyForecast(lat, lng, projectId, hours);
      setForecast(data);
      onMessage(data.online ? "تم تحديث تنبؤات السلامة من الإنترنت." : "تم تشغيل السلامة من التخزين المحلي.");
    } catch (error) {
      onMessage(error instanceof Error ? error.message : "فشل تحميل صفحة السلامة.");
    } finally {
      setLoading(false);
    }
  }

  const highestRisk = useMemo(() => {
    if (!forecast?.risks.length) return null;
    return forecast.risks.reduce((best, risk) => risk.score > best.score ? risk : best, forecast.risks[0]);
  }, [forecast]);

  return (
    <section className="safety-page">
      <article className="safety-hero">
        <div>
          <span className="eyebrow">نظام التنبؤ والسلامة</span>
          <h2>الأقمار · الطقس · المخاطر · الطوارئ</h2>
          <p>يعمل بدون إنترنت بآخر بيانات محفوظة، ويتحدث عند توفر الإنترنت. مناسب لتقييم السلامة الميدانية قبل العمل.</p>
        </div>
        <button onClick={loadForecast}>{loading ? "جاري..." : "تحديث"}</button>
      </article>

      <article className="safety-command">
        <div>
          <span>نطاق التوقع</span>
          <strong>{hours} ساعة</strong>
        </div>
        <input type="range" min={12} max={168} step={12} value={hours} onChange={(event) => setHours(Number(event.target.value))} />
      </article>

      <article className="developer-secure-card">
        <span>المطور المعتمد</span>
        <strong>أحمد أبوعزيزة الرشيدي</strong>
        <p>Offline-first · Safe Uploads · Local Cache · Audit-ready</p>
      </article>

      {forecast && (
        <>
          <article className="safety-summary-card">
            <div className="panel-head">
              <div>
                <span>{forecast.online ? "متصل" : "بدون إنترنت"}</span>
                <h3>{forecast.source}</h3>
              </div>
              <strong>{highestRisk ? `${Math.round(highestRisk.score)}/100` : "—"}</strong>
            </div>
            <p>{forecast.summary_ar}</p>
            <small>{new Date(forecast.generated_at).toLocaleString("ar")}</small>
          </article>

          <section className="safety-risk-grid">
            {forecast.risks.map((risk) => (
              <article className={`risk-card risk-${risk.level}`} key={risk.name}>
                <div className="risk-score">{Math.round(risk.score)}</div>
                <h3>{risk.label_ar}</h3>
                <p>{risk.message_ar}</p>
              </article>
            ))}
          </section>
        </>
      )}

      <section className="offline-online-grid">
        <article className="panel">
          <h3>يعمل بدون إنترنت</h3>
          <ul>
            <li>الرادار والبيانات المرفوعة.</li>
            <li>مكتبة جنوب/وسط/شمال.</li>
            <li>آخر توقع محفوظ في Cache.</li>
            <li>طابور AI والتحليلات المؤجلة.</li>
          </ul>
        </article>

        <article className="panel">
          <h3>يتفعّل عند الإنترنت</h3>
          <ul>
            <li>تحديث الطقس والمخاطر.</li>
            <li>مصادر Sentinel وDEM وSoilGrids.</li>
            <li>OSM والسياق المكاني.</li>
            <li>تنبيهات الطوارئ حسب المصدر.</li>
          </ul>
        </article>
      </section>
    </section>
  );
}
