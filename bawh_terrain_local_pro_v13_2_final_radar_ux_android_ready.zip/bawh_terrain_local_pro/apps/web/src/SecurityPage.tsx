import React, { useState } from "react";
import { AppIdentity } from "./api";
import AdminAuthPanel from "./AdminAuthPanel";

export default function SecurityPage({ identity, onMessage }: { identity: AppIdentity | null; onMessage: (message: string) => void }) {
  const [detailsOpen, setDetailsOpen] = useState(false);

  const controls = [
    ["Offline-first", "مفعل"],
    ["Safe uploads", "مفعل"],
    ["Path Traversal protection", "مفعل"],
    ["Local cache", "مفعل"],
    ["API headers", "محلي فقط"],
    ["JWT/RBAC", "اختياري"]
  ];

  return (
    <section className="screen concise-page">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">الإعدادات / الأمن</span>
        <h2>لوحة أمن مختصرة</h2>
        <p>{identity?.developer_name_ar ?? "أحمد أبوعزيزة الرشيدي"} · تشغيل محلي آمن.</p>
      </article>

      <section className="security-dashboard">
        {controls.map(([label, value]) => (
          <div key={label} className="security-tile">
            <span>{label}</span>
            <strong>{value}</strong>
          </div>
        ))}
      </section>

      <button className="secondary full" type="button" onClick={() => setDetailsOpen((value) => !value)}>
        {detailsOpen ? "إخفاء التفاصيل" : "عرض التفاصيل"}
      </button>

      {detailsOpen && (
        <article className="panel clean-card">
          <h3>تفاصيل الحماية</h3>
          <p>النظام يمنع تنفيذ الملفات المرفوعة، يتحقق من المسارات، ويحافظ على فصل البيانات المحلية عن أي مصادر اختيارية متصلة.</p>
          <AdminAuthPanel onMessage={onMessage} />
        </article>
      )}

      <article className="truth-card compact">
        <strong>No Gold Proof</strong>
        <span>No Depth</span>
        <span>No 100%</span>
      </article>
    </section>
  );
}
