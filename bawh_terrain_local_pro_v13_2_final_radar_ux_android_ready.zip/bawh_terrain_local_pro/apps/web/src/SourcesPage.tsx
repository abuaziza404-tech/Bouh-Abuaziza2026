import React, { useEffect, useState } from "react";
import { SourceStatus, getSourceStatus, isNetworkError } from "./api";

export default function SourcesPage({ onMessage }: { onMessage: (message: string) => void }) {
  const [status, setStatus] = useState<SourceStatus | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const response = await getSourceStatus();
      setStatus(response);
      onMessage("تم تحديث حالة المصادر.");
    } catch (error) {
      onMessage(isNetworkError(error) ? "المصادر الخارجية غير متصلة. المصادر المحلية متاحة." : "فشل فحص المصادر.");
    } finally {
      setLoading(false);
    }
  }

  const local = status?.sources?.filter((s) => s.mode === "local" || s.category === "local") ?? [];
  const external = status?.sources?.filter((s) => s.mode !== "local" && s.category !== "local") ?? [];

  return (
    <section className="screen concise-page sources-compact">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">المصادر</span>
        <h2>محلية أولًا</h2>
        <p>التحليل الأساسي يعتمد على قاعدة Ground Grid المحلية. المصادر الخارجية اختيارية وليست جزءًا لازمًا من Ground score.</p>
        <button className="secondary full" type="button" onClick={load}>{loading ? "جاري..." : "فحص المصادر"}</button>
      </article>

      <SourceGroup title="مصادر محلية مدمجة" items={[
        ["Ground Grid SQLite", "محلي"],
        ["بيانات الرادار", "محلي"],
        ["مكتبة النطاقات", "محلي"],
        ...local.slice(0, 4).map((item) => [item.label_ar, "محلي"] as [string, string])
      ]} />

      <SourceGroup title="مصادر خارجية اختيارية" items={[
        ["Esri Satellite", "يحتاج إنترنت"],
        ["Open-Meteo", "يحتاج إنترنت"],
        ["FIRMS", "غير متصل"],
        ["Copernicus", "غير متصل"],
        ...external.slice(0, 4).map((item) => [item.label_ar, item.enabled ? "متصل" : "غير متصل"] as [string, string])
      ]} />
    </section>
  );
}

function SourceGroup({ title, items }: { title: string; items: Array<[string, string]> }) {
  return (
    <article className="panel clean-card">
      <h3>{title}</h3>
      <div className="source-compact-list">
        {items.map(([label, state]) => (
          <div key={`${title}-${label}`}>
            <strong>{label}</strong>
            <span>{state}</span>
          </div>
        ))}
      </div>
    </article>
  );
}
