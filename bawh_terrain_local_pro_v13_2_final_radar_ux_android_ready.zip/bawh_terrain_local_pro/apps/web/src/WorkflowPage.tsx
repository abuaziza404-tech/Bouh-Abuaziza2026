import React, { useMemo } from "react";
import { Project } from "./api";

const stages = [
  { id: "project", title: "إنشاء المشروع", text: "تحديد الموقع والنطاق وخصائص التربة.", icon: "1" },
  { id: "upload", title: "رفع البيانات", text: "ZIP، GeoTIFF، باندات Sentinel، أو سجل محلي.", icon: "2" },
  { id: "index", title: "الفهرسة", text: "فك آمن، استخراج Metadata، تصنيف جنوب/وسط/شمال.", icon: "3" },
  { id: "analysis", title: "التحليل", text: "DEM، Slope، Flow، NDVI، NDWI، BSI، Safety.", icon: "4" },
  { id: "review", title: "المراجعة", text: "طابور AI ومراجعة بشرية وتقرير نهائي.", icon: "5" }
];

export default function WorkflowPage({ project, onMessage }: { project: Project | null; onMessage: (message: string) => void }) {
  const activeIndex = useMemo(() => project ? 2 : 0, [project]);

  return (
    <section className="screen">
      <article className="hero-card compact">
        <span className="eyebrow">Workflow</span>
        <h2>مسار تشغيل واضح لكل حزمة وطبقة ونتيجة</h2>
        <p>هذه اللوحة تجعل المنظومة منظمة وسهلة: من إنشاء المشروع إلى المراجعة النهائية.</p>
      </article>

      <section className="timeline">
        {stages.map((stage, index) => (
          <article key={stage.id} className={index <= activeIndex ? "timeline-card active" : "timeline-card"}>
            <div className="timeline-index">{stage.icon}</div>
            <div>
              <h3>{stage.title}</h3>
              <p>{stage.text}</p>
            </div>
          </article>
        ))}
      </section>

      <article className="panel">
        <h3>إجراءات سريعة</h3>
        <div className="quick-actions">
          <button className="secondary" onClick={() => onMessage("ارفع حزم ZIP من صفحة الرادار.")}>رفع حزمة</button>
          <button className="secondary" onClick={() => onMessage("أنشئ مهام AI من صفحة الرادار أو AI.")}>توليد مهام AI</button>
          <button className="secondary" onClick={() => onMessage("افتح صفحة السلامة لتحديث المخاطر.")}>تحديث السلامة</button>
        </div>
      </article>
    </section>
  );
}
