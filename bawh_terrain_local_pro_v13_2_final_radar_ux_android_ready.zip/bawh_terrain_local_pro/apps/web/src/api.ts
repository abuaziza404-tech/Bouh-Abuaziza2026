export type Project = {
  id: number;
  name: string;
  center_lat: number;
  center_lng: number;
  radius_m: number;
  soil_type: string;
  terrain_type: string;
  status: string;
};

export type ProjectPayload = {
  name: string;
  center_lat: number;
  center_lng: number;
  radius_m: number;
  soil_type: string;
  terrain_type: string;
};

export type BandRole = "blue" | "green" | "red" | "nir" | "swir";
export type RasterLayerName = "hillshade" | "slope" | "flow" | "ndvi" | "ndwi" | "bsi";

export type ProjectLayer = {
  name: RasterLayerName;
  title: string;
  available: boolean;
  tile_url: string | null;
  min: number | null;
  max: number | null;
  mean: number | null;
};

export type CorridorSegment = {
  role: string;
  name: string;
  west: number;
  south: number;
  east: number;
  north: number;
  center_lat: number;
  center_lng: number;
  ndvi_mean: number | null;
  ndwi_mean: number | null;
  bsi_mean: number | null;
  ndmi_mean: number | null;
  complete_core: boolean;
};

export type RegionalCorridorResponse = {
  ok: boolean;
  layer_name: string;
  segments: CorridorSegment[];
  analysis: Record<string, unknown>;
};

export type RadarLibraryItem = {
  role: string;
  label_ar: string;
  source_name: string;
  complete_core: boolean;
  band_count: number;
  west: number | null;
  south: number | null;
  east: number | null;
  north: number | null;
  center_lat: number | null;
  center_lng: number | null;
  ndvi_mean: number | null;
  ndwi_mean: number | null;
  bsi_mean: number | null;
  ndmi_mean: number | null;
  analysis_status: string;
  recommendation_ar: string;
};

export type SafetyRisk = {
  name: string;
  label_ar: string;
  score: number;
  level: string;
  message_ar: string;
};

export type SafetyForecastResponse = {
  ok: boolean;
  source: string;
  online: boolean;
  lat: number;
  lng: number;
  generated_at: string;
  risks: SafetyRisk[];
  summary_ar: string;
  raw: Record<string, unknown>;
};

export type AIAnalysisJob = {
  id: number;
  project_id: number | null;
  dataset_role: string;
  dataset_name: string;
  task_type: string;
  model_name: string;
  priority: string;
  status: string;
  input_metadata: Record<string, unknown>;
  model_output: Record<string, unknown>;
  confidence: number | null;
  human_review_status: string;
  notes_ar: string;
};

export type AppIdentity = {
  app_name: string;
  app_version: string;
  developer_name_ar: string;
  developer_name_en: string;
  security_profile: string;
  disclaimer_ar: string;
};

export type SystemOverview = {
  ok: boolean;
  identity: AppIdentity;
  generated_at: string;
  counts: Record<string, number>;
  operating_mode: {
    offline_first: boolean;
    online_features_available: boolean;
    cache_enabled: boolean;
    local_data_path: string;
  };
  sections: Array<{
    id: string;
    label_ar: string;
    status: string;
    online_required: boolean;
  }>;
};

export type SourceStatus = {
  ok: boolean;
  generated_at: string;
  sources: Array<{
    id: string;
    label_ar: string;
    category: string;
    mode: "local" | "online" | "hybrid";
    configured: boolean;
    enabled: boolean;
    message_ar: string;
  }>;
};

export type RadarScanPayload = {
  project_id: number;
  center_lat: number;
  center_lng: number;
  radius_m: number;
  resolution_mode: "standard" | "high" | "ultra" | string;
  enabled_layers: string[];
};


export type OfflineMapPack = {
  id: number;
  name: string;
  pack_type: "mbtiles" | "pmtiles" | string;
  file_name: string;
  file_size: number;
  min_zoom: number | null;
  max_zoom: number | null;
  bounds: Record<string, number>;
  metadata: Record<string, unknown>;
  tile_url: string | null;
  pmtiles_url?: string | null;
  created_at?: string;
};



export type OfflineMapDownloadJob = {
  id: number;
  name: string;
  source: string;
  status: string;
  west: number;
  south: number;
  east: number;
  north: number;
  min_zoom: number;
  max_zoom: number;
  estimated_tiles: number;
  downloaded_tiles: number;
  failed_tiles: number;
  metadata_json: Record<string, unknown>;
};

export type OfflineMapTilePlan = {
  ok: boolean;
  job_id: number;
  name: string;
  count: number;
  ranges: Array<Record<string, number>>;
  tiles: Array<{ source: string; z: number; x: number; y: number; url: string }>;
};


export type BaseLayerCatalog = {
  ok: boolean;
  groups: Array<{
    id: string;
    label_ar: string;
    layers: Array<{
      id: string;
      label_ar: string;
      type: string;
      online_required: boolean;
      offline_cache?: boolean;
      url_template?: string;
    }>;
  }>;
};

export type EmergencySource = {
  id: string;
  label_ar: string;
  category: string;
  mode: string;
  priority: string;
  configured: boolean;
  enabled: boolean;
  message_ar: string;
};

export type EmergencyRisk = {
  name: string;
  label_ar: string;
  score: number;
  level: string;
  message_ar: string;
};

export type EmergencyForecast = {
  ok: boolean;
  generated_at: string;
  lat: number;
  lng: number;
  radius_km: number;
  hours: number;
  overall_score: number;
  overall_level: string;
  summary_ar: string;
  risks: EmergencyRisk[];
  recommended_actions: string[];
  sources: EmergencySource[];
};


export type ProjectReportJson = Record<string, unknown>;

export type DataManagerInspection = {
  ok: boolean;
  workflow: string[];
  file: {
    file_name: string;
    size: number;
    content_type: string;
    detected_type: string;
    role: string;
    band_role: string | null;
    crs: string | null;
    bounds: unknown;
    is_analysis_ready: boolean;
    is_context_only: boolean;
    errors: string[];
    recommendation_ar: string;
    sha256: string | null;
  };
};

export type AuthTokenResponse = {
  access_token: string;
  token_type: string;
  role: string;
  username: string;
};

export type AuthUser = {
  id: number;
  username: string;
  role: string;
  is_active: boolean;
};

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

export const apiUrl = (path: string) => `${API_BASE}${path}`;

async function json<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `HTTP ${response.status}`);
  }
  return response.json();
}

export function isNetworkError(error: unknown): boolean {
  return error instanceof TypeError || String(error).includes("Failed to fetch");
}

export const getIdentity = () => json<AppIdentity>(`${API_BASE}/app/identity`);
export const getSystemOverview = () => json<SystemOverview>(`${API_BASE}/system/overview`);
export const getSourceStatus = () => json<SourceStatus>(`${API_BASE}/sources/status`);
export const createProject = (payload: ProjectPayload) => json<Project>(`${API_BASE}/projects`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(payload)
});
export const getProject = (id: number) => json<Project>(`${API_BASE}/projects/${id}`);
export const listProjects = () => json<Project[]>(`${API_BASE}/projects`);
export const getProjectLayers = (id: number) => json<ProjectLayer[]>(`${API_BASE}/projects/${id}/layers`);
export const rerunProject = (id: number) => json(`${API_BASE}/projects/${id}/rerun`, { method: "POST" });
export const startRadarScan = (payload: RadarScanPayload) => json(`${API_BASE}/radar-scan`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(payload)
});

export async function uploadProjectFile(projectId: number, file: File, bandRole?: BandRole) {
  const formData = new FormData();
  formData.append("file", file);
  return json(`${API_BASE}/projects/${projectId}/uploads${bandRole ? `?band_role=${bandRole}` : ""}`, {
    method: "POST",
    body: formData
  });
}

export async function uploadRadarDataset(projectId: number, file: File) {
  const formData = new FormData();
  formData.append("file", file);
  return json(`${API_BASE}/projects/${projectId}/radar-datasets`, {
    method: "POST",
    body: formData
  });
}

export const getRegionalCorridor = () => json<RegionalCorridorResponse>(`${API_BASE}/radar/regional-corridor`);
export const getRadarLibrary = () => json<{ ok: boolean; count: number; items: RadarLibraryItem[]; notes: string[] }>(`${API_BASE}/radar/library`);
export const getRadarLibraryItem = (role: string) => json<{ ok: boolean; item: RadarLibraryItem; quality_notes: string[]; radar_actions: { id: string; label_ar: string; enabled: boolean }[] }>(`${API_BASE}/radar/library/${encodeURIComponent(role)}`);
export const getSafetyForecast = (lat: number, lng: number, projectId?: number | null, hours = 48) => json<SafetyForecastResponse>(`${API_BASE}/safety/forecast`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ lat, lng, project_id: projectId ?? null, hours })
});
export const listAIAnalysisJobs = () => json<AIAnalysisJob[]>(`${API_BASE}/ai-analysis/jobs`);
export const createDefaultRegionalAIJobs = () => json(`${API_BASE}/ai-analysis/jobs/create-regional-defaults`, { method: "POST" });
export const markAIJobReviewed = (id: number) => json(`${API_BASE}/ai-analysis/jobs/${id}/mark-reviewed`, { method: "POST" });

export const listOfflineMapPacks = () => json<OfflineMapPack[]>(`${API_BASE}/offline-map-packs`);

export async function uploadOfflineMapPack(file: File): Promise<OfflineMapPack> {
  const formData = new FormData();
  formData.append("file", file);
  return json<OfflineMapPack>(`${API_BASE}/offline-map-packs`, {
    method: "POST",
    body: formData
  });
}

export const bootstrapAdmin = (username: string, password: string) => json<AuthTokenResponse>(`${API_BASE}/auth/bootstrap-admin`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ username, password })
});

export const login = (username: string, password: string) => json<AuthTokenResponse>(`${API_BASE}/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ username, password })
});

export const getMe = (token: string) => json<AuthUser>(`${API_BASE}/auth/me`, {
  headers: { Authorization: `Bearer ${token}` }
});

export const listOfflineMapDownloads = () => json<OfflineMapDownloadJob[]>(`${API_BASE}/offline-map-downloads`);

export const createOfflineMapDownload = (payload: {
  name: string;
  source: string;
  west: number;
  south: number;
  east: number;
  north: number;
  min_zoom: number;
  max_zoom: number;
  include_reference: boolean;
  include_streets: boolean;
}) => json<OfflineMapDownloadJob>(`${API_BASE}/offline-map-downloads`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(payload)
});

export const getOfflineMapDownloadPlan = (jobId: number) => json<OfflineMapTilePlan>(`${API_BASE}/offline-map-downloads/${jobId}/plan`);

export const markOfflineMapDownloadComplete = (jobId: number, downloadedTiles: number, failedTiles: number) => json(`${API_BASE}/offline-map-downloads/${jobId}/mark-complete?downloaded_tiles=${downloadedTiles}&failed_tiles=${failedTiles}`, {
  method: "POST"
});

export const getBaseLayerCatalog = () => json<BaseLayerCatalog>(`${API_BASE}/maps/base-layers`);

export const getEmergencySources = () => json<{ ok: boolean; sources: EmergencySource[] }>(`${API_BASE}/emergency/sources`);

export const getEmergencyForecast = (lat: number, lng: number, radiusKm = 50, hours = 72, includeSatelliteFeeds = true) => json<EmergencyForecast>(`${API_BASE}/emergency/forecast`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    lat,
    lng,
    radius_km: radiusKm,
    hours,
    include_satellite_feeds: includeSatelliteFeeds
  })
});

export const getProjectReportJson = (projectId: number) => json<ProjectReportJson>(`${API_BASE}/projects/${projectId}/report/json`);
export const getProjectReportHtmlUrl = (projectId: number) => `${API_BASE}/projects/${projectId}/report/html`;
export const getRadarCorridor = () => json<{ ok: boolean; corridor: Record<string, unknown>; items: RadarLibraryItem[] }>(`${API_BASE}/radar/corridor`);

export async function inspectDataManagerUpload(file: File): Promise<DataManagerInspection> {
  const formData = new FormData();
  formData.append("file", file);
  return json<DataManagerInspection>(`${API_BASE}/data-manager/inspect-upload`, {
    method: "POST",
    body: formData
  });
}
