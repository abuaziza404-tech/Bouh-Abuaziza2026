import React, { useEffect, useState } from "react";

type LiveScorePayload = {
  ok: boolean;
  mode: "ground_grid" | "seed_context_only" | "no_data" | "api_unavailable" | string;
  truth_status?: string;
  limitation_ar?: string;
  result?: {
    final_ground_score?: number | null;
    class?: string;
    distance_m?: number;
    truth_status?: string;
    limitation_ar?: string;
    evidence_count?: number;
    refl_brightness?: number;
    refl_red_green_proxy?: number;
    tir_brightness?: number;
    dem_elevation?: number;
    slope_proxy?: number;
    terrain_score?: number;
    alteration_proxy_score?: number;
    dryness_exposure_score?: number;
    structure_score?: number;
  };
};

const API_BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:8000";

export default function BouhLiveGroundScoreMeter({
  lat,
  lng,
  radius,
}: {
  lat: number;
  lng: number;
  radius: number;
}) {
  const [data, setData] = useState<LiveScorePayload | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function run() {
      setLoading(true);
      try {
        const url = `${API_BASE}/bouh/live-score?lat=${lat}&lng=${lng}&radius=${radius}`;
        const response = await fetch(url);
        const payload = (await response.json()) as LiveScorePayload;
        if (!cancelled) {
          setData(payload);
          persistLastReading(payload, lat, lng, radius);
        }
      } catch {
        if (!cancelled) {
          const payload: LiveScorePayload = {
            ok: false,
            mode: "api_unavailable",
            limitation_ar: "تعذر الوصول إلى Live Score API. لا توجد نتيجة محسوبة.",
          };
          setData(payload);
          persistLastReading(payload, lat, lng, radius);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    if (Number.isFinite(lat) && Number.isFinite(lng)) run();
    return () => { cancelled = true; };
  }, [lat, lng, radius]);

  const score = data?.result?.final_ground_score;
  const className = data?.result?.class ?? (data?.mode === "no_data" ? "No Data" : "Field-check");
  const mode = data?.mode ?? "—";
  const truth = data?.truth_status ?? data?.result?.truth_status ?? "—";
  const limitation = data?.limitation_ar ?? data?.result?.limitation_ar ?? "تحليل سطحي يحتاج فحصًا ميدانيًا.";
  const statusClass = mode === "ground_grid" ? "ground" : mode === "seed_context_only" ? "seed" : mode === "no_data" ? "nodata" : "api";

  return (
    <section className={`bouh-live-meter pro ${statusClass}`}>
      <header>
        <div>
          <span>Live Ground Score</span>
          <strong>درجة الأرض</strong>
        </div>
        <small>{loading ? "جاري الحساب..." : mode}</small>
      </header>

      <div className="score-summary">
        <div className="meter-value">{typeof score === "number" ? score.toFixed(1) : "—"}</div>
        <div>
          <b className={className === "Reject" ? "reject-class" : ""}>{className}</b>
          <span>mode: {mode}</span>
        </div>
      </div>

      <div className="score-facts">
        <Fact label="evidence_count" value={data?.result?.evidence_count ?? "—"} />
        <Fact label="truth_status" value={truth} />
        <Fact label="distance" value={typeof data?.result?.distance_m === "number" ? `${data.result.distance_m.toFixed(1)} m` : "—"} />
      </div>

      <p className="meter-note">{limitation}</p>

      <details className="indicator-details">
        <summary>تفاصيل المؤشرات</summary>
        <div className="meter-grid">
          <Metric label="refl_brightness" value={data?.result?.refl_brightness} />
          <Metric label="refl_red_green_proxy" value={data?.result?.refl_red_green_proxy} />
          <Metric label="tir_brightness" value={data?.result?.tir_brightness} />
          <Metric label="dem_elevation" value={data?.result?.dem_elevation} />
          <Metric label="slope_proxy" value={data?.result?.slope_proxy} />
          <Metric label="terrain_score" value={data?.result?.terrain_score} />
          <Metric label="alteration_proxy_score" value={data?.result?.alteration_proxy_score} />
          <Metric label="dryness_exposure_score" value={data?.result?.dryness_exposure_score} />
          <Metric label="structure_score" value={data?.result?.structure_score} />
        </div>
      </details>

      <div className="truth-policy">
        No Gold Proof · No Depth · No 100% · Surface Screening · Field-check
      </div>
    </section>
  );
}

function Fact({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: unknown }) {
  return (
    <span>
      <b>{label}</b>
      <em>{typeof value === "number" ? value.toFixed(3) : "—"}</em>
    </span>
  );
}

function persistLastReading(payload: LiveScorePayload, lat: number, lng: number, radius: number) {
  const stored = {
    ...payload,
    lat,
    lng,
    radius,
    saved_at: new Date().toISOString(),
  };
  localStorage.setItem("bouh.last_live_ground_score", JSON.stringify(stored));
  window.dispatchEvent(new CustomEvent("bouh:last-live-score", { detail: stored }));
}
