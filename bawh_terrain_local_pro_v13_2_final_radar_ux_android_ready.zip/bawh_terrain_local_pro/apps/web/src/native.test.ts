import { describe, expect, it } from "vitest";

describe("native helpers", () => {
  it("loads module", async () => {
    const module = await import("./native");
    expect(typeof module.getNativePosition).toBe("function");
    expect(typeof module.saveNativePreference).toBe("function");
    expect(typeof module.getNativePreference).toBe("function");
  });
});
