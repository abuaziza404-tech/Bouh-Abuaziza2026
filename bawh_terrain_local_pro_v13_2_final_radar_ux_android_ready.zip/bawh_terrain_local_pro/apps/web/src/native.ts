export async function getNativePosition(): Promise<{ lat: number; lng: number } | null> {
  try {
    const capacitor = await import("@capacitor/core");
    const platform = capacitor.Capacitor.getPlatform();

    if (platform === "web") {
      return new Promise((resolve) => {
        if (!navigator.geolocation) {
          resolve(null);
          return;
        }

        navigator.geolocation.getCurrentPosition(
          (position) => resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          }),
          () => resolve(null),
          { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 }
        );
      });
    }

    const geo = await import("@capacitor/geolocation");
    const position = await geo.Geolocation.getCurrentPosition({
      enableHighAccuracy: true,
      timeout: 12000,
      maximumAge: 30000
    });

    return {
      lat: position.coords.latitude,
      lng: position.coords.longitude
    };
  } catch {
    return null;
  }
}

export async function saveNativePreference(key: string, value: string): Promise<void> {
  try {
    const preferences = await import("@capacitor/preferences");
    await preferences.Preferences.set({ key, value });
  } catch {
    localStorage.setItem(key, value);
  }
}

export async function getNativePreference(key: string): Promise<string | null> {
  try {
    const preferences = await import("@capacitor/preferences");
    const result = await preferences.Preferences.get({ key });
    return result.value;
  } catch {
    return localStorage.getItem(key);
  }
}
