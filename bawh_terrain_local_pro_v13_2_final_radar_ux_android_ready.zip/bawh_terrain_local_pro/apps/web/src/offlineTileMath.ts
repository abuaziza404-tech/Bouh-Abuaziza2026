export function degreesToRadians(value: number) {
  return value * Math.PI / 180;
}

export function buildBoundsFromRadius(lat: number, lng: number, radiusMeters: number) {
  const latDelta = radiusMeters / 111320;
  const lngDelta = radiusMeters / (111320 * Math.cos(degreesToRadians(lat)));

  return {
    west: lng - lngDelta,
    south: lat - latDelta,
    east: lng + lngDelta,
    north: lat + latDelta
  };
}

export function lngLatToTile(lng: number, lat: number, zoom: number) {
  const n = 2 ** zoom;
  const latRad = degreesToRadians(Math.max(-85.05112878, Math.min(85.05112878, lat)));
  const x = Math.floor(((lng + 180) / 360) * n);
  const y = Math.floor(((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * n);

  return { x, y };
}
