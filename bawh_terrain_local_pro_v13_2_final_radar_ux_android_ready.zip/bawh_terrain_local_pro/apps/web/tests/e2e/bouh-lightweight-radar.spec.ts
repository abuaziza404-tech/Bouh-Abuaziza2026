import { expect, test } from "@playwright/test";

const bootstrapPayload = {
  ok: true,
  pack_name: "BOUH Radar Lightweight Intelligence Pack",
  pack_version: "12.1-fixed",
  truth_policy: { rule: "No Gold Target claims" },
  heavy_data_policy: "لا توجد بيانات ثقيلة داخل الواجهة أو APK.",
  data_definitions: {},
  universal_summary: {},
  regional_zones: [
    {
      role: "regional_south",
      label_ar: "النطاق الجنوبي",
      source_zip: "south.zip",
      status: "available",
      analysis_use: "Regional corridor",
      truth_status: "metadata_until_import",
      can_render_on_radar: true,
      can_calculate_new_pixels_without_import: false
    },
    {
      role: "regional_center",
      label_ar: "نطاق الوسط",
      source_zip: "center.zip",
      status: "available",
      analysis_use: "Connector",
      truth_status: "metadata_until_import",
      can_render_on_radar: true,
      can_calculate_new_pixels_without_import: false
    },
    {
      role: "regional_north",
      label_ar: "النطاق الشمالي",
      source_zip: "north.zip",
      status: "available",
      analysis_use: "Regional corridor",
      truth_status: "metadata_until_import",
      can_render_on_radar: true,
      can_calculate_new_pixels_without_import: false
    }
  ],
  official_targets: [
    {
      target_id: "T1",
      name: "ARB-GPZ-CORE-01",
      latitude: 19.9732,
      longitude: 36.7456,
      model_type: "Field-check",
      final_status: "SELECT - field-check",
      proof_status: "Not gold proof; field-check only.",
      radar_layer: "official_field_check_targets",
      priority_class: "field_check_select",
      source: "precomputed_fixture",
      evidence_class: "field_check",
      truth_status: "field_check_only",
      limitation_ar: "Field-check only.",
      calculation_allowed: false
    },
    {
      target_id: "T2",
      name: "ARB-VEIN-ALT-01",
      latitude: 19.8813,
      longitude: 36.8088,
      model_type: "Field-check",
      final_status: "SELECT - field-check",
      proof_status: "Not gold proof; field-check only.",
      radar_layer: "official_field_check_targets",
      priority_class: "field_check_select",
      source: "precomputed_fixture",
      evidence_class: "field_check",
      truth_status: "field_check_only",
      limitation_ar: "Field-check only.",
      calculation_allowed: false
    },
    {
      target_id: "T3",
      name: "ARB-FEEDER-JOG-01",
      latitude: 19.9831,
      longitude: 36.7764,
      model_type: "Field-check",
      final_status: "SELECT - field-check",
      proof_status: "Not gold proof; field-check only.",
      radar_layer: "official_field_check_targets",
      priority_class: "field_check_select",
      source: "precomputed_fixture",
      evidence_class: "field_check",
      truth_status: "field_check_only",
      limitation_ar: "Field-check only.",
      calculation_allowed: false
    }
  ],
  screening_points: {
    universal_top10: [
      {
        rank: 1,
        latitude: 19.6382,
        longitude: 36.776,
        score: 0.98,
        evidence_count: 5,
        truth_status: "relative_support_only",
        source: "universal_relative_support_precomputed",
        evidence_class: "relative_support",
        limitation_ar: "Relative support only.",
        calculation_allowed: false,
        proof_status: "Not a target proof."
      }
    ],
    sentinel2_top10: [
      {
        rank: 1,
        latitude: 20.0066,
        longitude: 37.0279,
        score_relative: 0.934,
        NDVI: 0.062,
        IRON_B04_B02: 2.125,
        SWIR_B11_B12: 1.1,
        truth_status: "relative_sentinel_support_only",
        source: "sentinel2_relative_support_precomputed",
        evidence_class: "relative_sentinel_support",
        limitation_ar: "Sentinel relative support only.",
        calculation_allowed: false,
        proof_status: "Not a target proof."
      }
    ]
  }
};

test("lightweight radar panel loads official targets and relative support", async ({ page }) => {
  await page.route("**/bouh/radar/bootstrap", async (route) => {
    await route.fulfill({ json: bootstrapPayload });
  });
  await page.route("**/app/identity", async (route) => {
    await route.fulfill({ json: { app_name: "بوح التضاريس", developer_name_ar: "أحمد أبوعزيزة الرشيدي" } });
  });
  await page.route("**/system/overview", async (route) => {
    await route.fulfill({ json: { counts: {} } });
  });

  await page.goto("/");
  await page.getByRole("button", { name: /الرادار/ }).click();

  await expect(page.getByTestId("bouh-lightweight-radar-panel")).toBeVisible();
  await expect(page.getByText("T1")).toBeVisible();
  await expect(page.getByText("T2")).toBeVisible();
  await expect(page.getByText("T3")).toBeVisible();
  await expect(page.getByText(/أفضل نقاط الدعم النسبي/)).toBeVisible();
  await expect(page.getByText(/relative_support_only/)).toBeVisible();

  await page.getByText("T1").click();
  await expect(page.getByText(/تم تحديد نقطة|تم تحميل|تحديد/)).toBeVisible();
});
