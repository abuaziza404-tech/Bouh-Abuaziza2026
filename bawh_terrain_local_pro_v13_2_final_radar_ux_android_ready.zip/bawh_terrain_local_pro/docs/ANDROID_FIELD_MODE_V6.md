# بوح التضاريس Local Pro v6 — Android Field Mode

المطور: أحمد أبوعزيزة الرشيدي

## الهدف

تجهيز التطبيق للعمل بسلاسة على هاتف Android بنمطين:

1. PWA مباشر من Chrome:
   - تثبيت على الشاشة الرئيسية.
   - Offline-first.
   - حفظ خرائط Esri Satellite/Hybrid/Streets أثناء الإنترنت.
   - استمرار العمل عند انقطاع الإنترنت حسب Cache محفوظ.

2. Android APK عبر Capacitor:
   - حزمة Native WebView.
   - تشغيل واجهة التطبيق داخل تطبيق Android.
   - إمكانية بناء APK debug/release محليًا.

## تشغيل PWA على Android

```bash
docker compose up --build
```

ثم من الهاتف على نفس الشبكة افتح:

```text
http://IP-ADDRESS:5173
```

من Chrome:
- افتح القائمة ⋮
- اختر Install app أو Add to Home screen
- افتح التطبيق من الشاشة الرئيسية
- ادخل الرادار
- اختر Esri Satellite أو Hybrid
- اضغط حفظ المنطقة أثناء توفر الإنترنت

## بناء APK عبر Capacitor

داخل مجلد `apps/web`:

```bash
npm install
npm run android:init
npm run android:apk:debug
```

مسار APK الناتج غالبًا:

```text
apps/web/android/app/build/outputs/apk/debug/app-debug.apk
```

## بناء Release

يتطلب Android Studio/SDK وتوقيع Keystore:

```bash
npm run android:sync
cd android
./gradlew assembleRelease
```

## ميزات Offline على Android

- Service Worker للتطبيق.
- Tile Cache منفصل للخرائط.
- زر تثبيت التخزين الدائم.
- Safe-area CSS.
- أزرار كبيرة مناسبة للمس.
- PWA manifest كامل بأيقونات.
- Shortcuts للرادار والسلامة.

## حدود مهمة

- Cache المتصفح قد يُحذف إذا امتلأت مساحة الهاتف.
- لمناطق كبيرة جدًا يوصى لاحقًا بإضافة MBTiles/PMTiles.
- خرائط Esri/OSM يجب استخدامها وفق شروط المزود.
- بناء APK النهائي يحتاج Android SDK غير متوفر داخل هذه الجلسة.
