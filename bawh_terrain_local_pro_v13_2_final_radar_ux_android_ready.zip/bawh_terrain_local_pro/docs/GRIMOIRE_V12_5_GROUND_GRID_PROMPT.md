# برومبت المطور — v12.5 Ground Grid Live Radar Engine

أنت المطور. لا تغيّر منطق التحليل. هذا الملف صادر من جهة التحليل الجيولوجي لمشروع بوح التضاريس.

## المشكلة
v12.4 فيها خريطة ونقاط وOverlays وCache، لكنها لا تحتوي قراءة أرض حقيقية تحت الدبوس.

## المطلوب
ادمج الحزمة:
BOUH_v12_5_ANALYTICAL_AUTHORITY_GROUND_GRID_PACK.zip

داخل مشروع v12.4 وأصدر:
bawh_terrain_local_pro_v12_5_ground_grid_live_radar_engine.zip

## الخطوات

1. انسخ:
- configs/ground_score_model_v12_5.json
- data/precomputed/bouh_seed_cells_v12_5.*
- scripts/build_bouh_ground_grid.py
- apps/api/app/bouh_core/live_score_repository.py
- apps/api/app/bouh_core/live_score_router_patch.py
- apps/web/src/bouh/BouhLiveGroundScoreMeter.tsx
- apps/web/src/bouh/bouh_live_meter.css
- tests/test_live_score_repository.py

2. أضف endpoints إلى router الحالي:
GET /bouh/live-score?lat=...&lng=...&radius=...
GET /bouh/live-score/status

3. في صفحة الرادار:
- أضف BouhLiveGroundScoreMeter
- اربطه بإحداثيات الدبوس الحالية
- حدثه عند dragend/click/radius change/start scan

4. شغّل:
python scripts/build_bouh_ground_grid.py

إذا لم توجد rasters:
- لا تخترع grid
- اترك bouh_ground_grid.sqlite فارغًا أو بحالة no_raw_grid_built
- live-score يستخدم seed context فقط ويكتب ذلك بوضوح

إذا وجدت rasters:
- ابني bouh_ground_grid.sqlite
- لا تستخدم PNG/JPG/KMZ في الحساب
- لا تضف rasters إلى Android assets

5. قواعد غير قابلة للتغيير:
- No Gold Proof
- No depth
- No 100%
- Never evaluate on FeOx alone
- No Structure + No Clay/Silica = Reject
- visual files context only

6. أضف تقرير:
data/precomputed/BOUH_GROUND_GRID_BUILD_REPORT.md

يحتوي:
- عدد الخلايا
- مصادر البيانات
- هل النتائج raw-pixel محسوبة أم seed-context فقط
- النواقص

7. أضف اختبار:
pytest tests/test_live_score_repository.py

## القبول
أقبل النسخة فقط إذا:
- الدبوس يعطي live-score عند التحريك
- إذا لا توجد بيانات خام يظهر no_data/seed_context وليس نتيجة وهمية
- لا توجد ملفات raster ثقيلة داخل Android assets
- التوثيق يفرق بين seed context وraw ground grid
