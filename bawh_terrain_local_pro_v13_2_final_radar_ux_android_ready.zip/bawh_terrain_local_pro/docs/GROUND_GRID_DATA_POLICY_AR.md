# سياسة بيانات Ground Grid

## الفرق بين Seed وGround Grid

### Seed
نقطة موجودة مسبقًا من سجل بوح أو ملخصات Universal/Sentinel.
تستخدم كمرساة سياقية فقط.

### Ground Grid
شبكة خلايا محسوبة من raster خام.
هذه هي التي تعطي قراءة أرض تحت الدبوس.

## ممنوع
- تحويل seed إلى gold proof.
- اعتبار universal score قراءة بيكسل لمكان جديد.
- استخدام PNG/KMZ لحساب NDVI أو BSI.
- إعطاء Score عند عدم وجود خلية أو seed.

## مسموح
- عرض seed كـ context.
- استخدام ground grid إذا بنيت من GeoTIFF/DEM.
- عرض limitation_ar دائمًا.
