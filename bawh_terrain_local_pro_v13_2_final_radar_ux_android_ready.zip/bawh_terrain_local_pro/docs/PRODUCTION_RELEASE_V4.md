# بوح التضاريس Local Pro v4 — Production Release

المطور: أحمد أبوعزيزة الرشيدي

## ما الجديد

- دمج خريطة MapLibre حقيقية داخل الرادار.
- اختيار المركز بالنقر على الخريطة.
- سحب الهدف Marker.
- دائرة نطاق GeoJSON حسب radius.
- عرض حدود النطاق المختار من مكتبة الرادار.
- عرض طبقات المشروع Raster Tiles عند توفر التحليل.
- حزمة Production override لـ Docker Compose.

## التشغيل المحلي

```bash
cp .env.example .env
docker compose up --build
```

## تشغيل production

```bash
cp .env.example .env
docker compose -f docker-compose.yml -f docker-compose.prod.yml up --build -d
```

## ملاحظات

- الخرائط الأساسية من OpenStreetMap تحتاج إنترنت.
- الطبقات المحلية والرادار والبيانات المرفوعة تعمل محليًا.
- إذا لم يوجد إنترنت، يبقى التطبيق يعمل، وتظهر الخريطة حسب ما تم تخزينه في Cache المتصفح.
