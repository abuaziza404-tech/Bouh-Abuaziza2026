# بوح التضاريس Local Pro v11 — Maps/Layers & Emergency Intelligence

المطور: أحمد أبوعزيزة الرشيدي

## الإضافات

### قسم الخرائط والطبقات الأساسية

قسم مستقل لإدارة:

- Esri Satellite.
- Esri Reference Hybrid.
- OpenStreetMap Streets.
- MBTiles.
- PMTiles.
- Hillshade.
- Slope.
- Flow.
- NDVI.
- NDWI.
- BSI.

Endpoint:

```text
GET /maps/base-layers
```

### قسم الحالات الطارئة

قسم مستقل يربط مصادر الطوارئ والتنبؤ:

- Copernicus EMS.
- NASA FIRMS.
- Open‑Meteo.
- NOAA/NWS Alerts كمصدر إقليمي للولايات المتحدة.
- محرك السلامة المحلي Offline.

Endpoints:

```text
GET /emergency/sources
POST /emergency/forecast
GET /emergency/events
```

## التشغيل Offline

- محرك السلامة المحلي يعمل دون إنترنت.
- الخرائط المحفوظة وMBTiles/PMTiles تعمل دون إنترنت.
- مصادر الأقمار والطوارئ المتصلة تتحدث عند توفر الإنترنت.

## تنبيه

النظام يقدم تنبؤًا وتشغيلًا ميدانيًا مساعدًا، ولا يغني عن الجهات الرسمية أو قرارات السلامة البشرية.
