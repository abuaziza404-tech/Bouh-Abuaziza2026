# بوح التضاريس Local Pro v8 — PMTiles Direct / JWT-RBAC / Release Signing

المطور: أحمد أبوعزيزة الرشيدي

## W — PMTiles مباشر

تمت إضافة بروتوكول PMTiles داخل MapLibre:

- إضافة مكتبة `pmtiles`.
- تسجيل `pmtiles://` protocol.
- endpoint:
  - `GET /offline-map-packs/{id}/file.pmtiles`
- اختيار PMTiles من قائمة حزم الخرائط.
- MBTiles يستمر عبر endpoint tiles المحلي.
- PMTiles يعرض مباشرة عبر بروتوكول MapLibre عند توافق ملف PMTiles.

## E — JWT/RBAC بجانب PIN المحلي

تمت إضافة نظام مستخدمين API:

- `POST /auth/bootstrap-admin`
- `POST /auth/login`
- `GET /auth/me`
- `GET /auth/users` للمدير فقط

الرمز المستخدم هو JWT-Lite موقع HMAC-SHA256 باستخدام `APP_SECRET_KEY`.

> ملاحظة: PIN المحلي يحمي واجهة الهاتف. JWT/RBAC يحمي API عند النشر أو الشبكة.

## D — اختبارات

تمت إضافة:

- اختبارات auth security.
- اختبارات API health/identity.
- سكربت Docker smoke test:
  - `scripts/test_docker_full.sh`

## Z — Release Signing Guide

### Android Debug APK

```bash
cd apps/web
npm install
npm run android:init
npm run android:apk:debug
```

### Android Release APK/AAB

أنشئ Keystore على جهازك:

```bash
keytool -genkeypair \
  -alias bawhterrain \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000 \
  -keystore bawhterrain-release.keystore
```

ضع الملف في مكان آمن خارج Git.

داخل `apps/web/android/gradle.properties` أضف:

```properties
BAWH_RELEASE_STORE_FILE=/absolute/path/bawhterrain-release.keystore
BAWH_RELEASE_KEY_ALIAS=bawhterrain
BAWH_RELEASE_STORE_PASSWORD=YOUR_STORE_PASSWORD
BAWH_RELEASE_KEY_PASSWORD=YOUR_KEY_PASSWORD
```

ثم عدّل `apps/web/android/app/build.gradle` بعد إنشاء مشروع Android من Capacitor لإضافة signingConfigs، أو استخدم Android Studio:

```bash
cd apps/web
npm run android:sync
npx cap open android
```

من Android Studio:
- Build
- Generate Signed Bundle / APK
- اختر keystore
- اختر release
- أنشئ APK أو AAB

## حماية المفاتيح

- لا ترفع keystore إلى Git.
- لا تشارك كلمات المرور.
- لا تضع مفاتيح API داخل APK إلا للضرورة.
- استخدم `.env` على الخادم.
