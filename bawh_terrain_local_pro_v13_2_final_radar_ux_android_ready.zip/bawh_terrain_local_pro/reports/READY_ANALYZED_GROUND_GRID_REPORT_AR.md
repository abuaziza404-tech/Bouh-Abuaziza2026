# تقرير بيانات بوح الجاهزة المحللة v12.6

## النتيجة

تم تجهيز بيانات محللة جاهزة للرادار بصيغة SQLite:

`data/precomputed/bouh_ground_grid.sqlite`

## عدد الخلايا

- ground_cells: 4303
- أعلى درجة: 66.0
- متوسط الدرجة: 57.237
- أقل درجة: 14.813

## حدود التغطية التقريبية EPSG:4326

- Lat: 19.319561963433515 → 20.305485815650368
- Lng: 36.56926339431469 → 37.155658657986564

## مصادر البيانات التي دخلت الحساب فعليًا

- Landsat reflectance composite: `LC08...refl_wgs84_px.tiff`
- Landsat TIR: `LC08...tir_wgs84_px.tiff`
- Landsat QA: `LC08...QA_PIXEL_wgs84_u.tiff`
- DEM: `n19_e036_3arc_v2.tif`

## المؤشرات/القيم المحسوبة فعليًا

- refl_r / refl_g / refl_b
- refl_brightness
- refl_red_green_proxy
- tir_brightness
- qa_value
- dem_elevation
- slope_proxy
- terrain_score
- alteration_proxy_score
- dryness_exposure_score
- structure_score
- final_ground_score
- class

## ما لم يُحسب بعد

لم تُحسب مؤشرات Sentinel/SWIR الحقيقية التالية لأن باندات Sentinel الخام لم تكن داخل البيانات المحللة الجاهزة:

- NDVI الحقيقي
- NDWI الحقيقي
- BSI الحقيقي
- NDMI الحقيقي
- IRON_B04_B02 الحقيقي
- SWIR_B11_B12 الحقيقي
- DRY_B11_B08 الحقيقي

## تنبيه الدقة

طلب "كل متر" غير صادق علميًا إذا كانت المصادر Landsat/Sentinel/DEM؛ لأن دقة المصادر الأصلية ليست 1 متر.
لذلك هذه الحزمة تعطي خلايا تحليل جاهزة حسب دقة/تقطيع المصادر المتاحة، ولا تدعي قياس 1 متر حقيقي.

## حدود الصدق

- لا Gold Proof
- لا Depth
- لا 100%
- لا ادعاء ذهب
- النتائج ترجيح سطحي/تحليل أرضي جزئي فقط
- أعلى تصنيف حاليًا capped عند Class C بسبب غياب Sentinel/SWIR الكامل

## طريقة الدمج

انسخ الملف:

`data/precomputed/bouh_ground_grid.sqlite`

إلى مشروع v12.5 في نفس المسار:

`data/precomputed/bouh_ground_grid.sqlite`

ثم شغل:

`GET /bouh/live-score/status`

يجب أن يظهر:

`ground_grid_cell_count = 4303`

ثم اختبر:

`GET /bouh/live-score?lat=19.9732&lng=36.7456&radius=300`
