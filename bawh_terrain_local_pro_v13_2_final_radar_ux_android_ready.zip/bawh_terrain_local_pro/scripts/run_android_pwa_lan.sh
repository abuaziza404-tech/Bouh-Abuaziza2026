#!/usr/bin/env bash
set -euo pipefail

echo "Start API and Web for Android phone on the same Wi-Fi:"
echo "docker compose up --build"
echo ""
echo "Then open from Android Chrome:"
IP="$(hostname -I | awk '{print $1}')"
echo "http://${IP}:5173"
echo ""
echo "Install from Chrome menu: ⋮ > Install app"
