from __future__ import annotations

import json
import os
from pathlib import Path
import sys

# Allows running standalone before package install.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "apps" / "api"))

from app.bouh_core.import_status import scan_imports

if __name__ == "__main__":
    root = Path(os.getenv("BOUH_IMPORT_ROOT", "/app/data/imports"))
    if len(sys.argv) > 1:
        root = Path(sys.argv[1])
    print(json.dumps(scan_imports(root), ensure_ascii=False, indent=2))
