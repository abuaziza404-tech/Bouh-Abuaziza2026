#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

docker compose up -d --build db redis minio api worker web

echo "Waiting for API..."
for i in {1..60}; do
  if curl -fsS http://localhost:8000/health >/dev/null; then
    break
  fi
  sleep 2
done

curl -fsS http://localhost:8000/health
curl -fsS http://localhost:8000/app/identity
curl -fsS http://localhost:8000/system/overview

docker compose exec -T api pytest

echo "Docker integration smoke tests passed."
