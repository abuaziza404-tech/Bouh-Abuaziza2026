from __future__ import annotations

import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    required = [
        ROOT / "configs/ground_score_model_v12_5.json",
        ROOT / "data/precomputed/bouh_seed_cells_v12_5.json",
        ROOT / "data/precomputed/bouh_seed_cells_v12_5.sqlite",
        ROOT / "scripts/build_bouh_ground_grid.py",
        ROOT / "apps/api/app/bouh_core/live_score_repository.py",
        ROOT / "docs/GRIMOIRE_V12_5_GROUND_GRID_PROMPT.md",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise SystemExit(f"Missing files: {missing}")

    model = json.loads((ROOT/"configs/ground_score_model_v12_5.json").read_text(encoding="utf-8"))
    assert model["truth_policy"]["no_gold_proof"] is True
    assert "Never evaluate on FeOx alone" in model["truth_policy"]["feox_rule"]

    seeds = json.loads((ROOT/"data/precomputed/bouh_seed_cells_v12_5.json").read_text(encoding="utf-8"))["seed_cells"]
    assert len(seeds) >= 10
    for s in seeds:
        assert s["is_raw_pixel_result"] is False
        assert "ليست قراءة بيكسل خام" in s["limitation_ar"]

    conn = sqlite3.connect(ROOT/"data/precomputed/bouh_seed_cells_v12_5.sqlite")
    count = conn.execute("SELECT COUNT(*) FROM seed_cells").fetchone()[0]
    conn.close()
    assert count == len(seeds)

    print("BOUH v12.5 analytical authority pack validation OK")

if __name__ == "__main__":
    main()
