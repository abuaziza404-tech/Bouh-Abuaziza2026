# BUILD_REPORT.md — v14.0 True Offline Operational Radar

## هدف الإصدار

تحويل التطبيق من واجهة تعتمد على API إلى نظام رادار تشغيلي يعمل محليًا داخل APK:

```text
خريطة → مركز الشاشة → بحث في 4303 خلية → Ground Score → تقرير نقطة
```

## ما تم تنفيذه

- إنشاء Offline Data Layer داخل الويب:
  - `apps/web/public/data/bouh_ground_grid_compact.json`
- الملف يحتوي 4303 خلية من `ground_cells`.
- إنشاء module محلي:
  - `apps/web/src/bouh/localGroundGrid.ts`
- `localGroundGrid` ينفذ:
  - تحميل بيانات ground grid محليًا.
  - البحث عن أقرب خلية للإحداثيات الحالية.
  - احترام radius: 100 / 300 / 500 / 1000.
  - إرجاع `mode = ground_grid` عند وجود خلية ضمن النطاق.
  - إرجاع `mode = no_data` عند عدم وجود خلية قريبة.
  - عدم اختراع نتيجة.
- `Live Ground Score` يستخدم البيانات المحلية أولًا وعمليًا داخل APK.
- إزالة عرض:
  - Failed to fetch
  - api_unavailable
  - فشل تحميل bootstrap
  - لا يوجد cache محلي سابق
- التقارير تستخدم آخر قراءة محلية من الرادار.
- المكتبة تعرض حالة قاعدة التحليل ونطاق التغطية التقريبي.
- السلامة مختصرة كلوحة تشغيل آمن.
- الإعدادات تشمل:
  - radius الافتراضي
  - الطبقة الافتراضية
  - تشغيل/إيقاف تتبع مركز الخريطة
  - مسح cache المحلي
  - عرض حالة التطبيق
  - نسخة التطبيق
- الخريطة أصبحت بطاقة واحدة كاملة العرض.
- إزالة اللوحة الجانبية التي كانت تغطي نصف الخريطة.
- أزرار الطبقات صغيرة أعلى الخريطة:
  - Esri
  - Hybrid
  - Streets
- MBTiles/PMTiles drawer مغلق افتراضيًا.
- crosshair ثابت في مركز الخريطة:
  - `map-center-crosshair`
  - `radar-crosshair`
- دائرة الرادار حول crosshair.
- `map moveend` يقرأ مركز الخريطة ثم يحدث الإحداثيات والنتيجة المحلية.
- الإحداثيات تظهر منفصلة:
  - Lat
  - Lng
- التنقل السفلي يعرض أسماء الأقسام:
  - الرئيسية
  - الرادار
  - التقارير
  - المكتبة
  - السلامة
  - الإعدادات

## البيانات المحلية

```text
compact json path = apps/web/public/data/bouh_ground_grid_compact.json
compact json cells = 4303
compact json sha256 = caedab8f958013fd1b41625f80950a4b29f689cb74b674369467f29a304287f9
```

الحقول الموجودة في كل خلية:

```text
cell_id
latitude
longitude
final_ground_score
class
evidence_count
truth_status
limitation_ar
refl_brightness
refl_red_green_proxy
tir_brightness
dem_elevation
slope_proxy
terrain_score
alteration_proxy_score
dryness_exposure_score
structure_score
```

## سلامة قاعدة التحليل

لم يتم تغيير:

```text
data/precomputed/bouh_ground_grid.sqlite
ground_cells = 4303
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
الأوزان
أسماء الحقول
live-score repository logic
```

أعلى خلية بقيت:

```text
cell_id = partial_raw_0004117
lat = 19.41022162800518
lng = 36.86820999932388
final_ground_score = 66.0
class = Class C
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
```

## الحدود العلمية

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
Field-check only
```

## نتائج البناء المحلي

```text
npm install = rc 0
npm run build = rc 0
npm run build:strict = rc 0
node ./node_modules/@capacitor/cli/bin/capacitor sync android = rc 0
validate_v12_5_analytical_pack = rc 0
test_live_score_repository = rc 0 / 3 passed
test_v12_6_ready_analyzed_grid = rc 0 / 1 passed
```

## حالة APK/AAB المحلية

تعذر بناء APK/AAB داخل هذه البيئة فقط بسبب حجب Gradle عن الإنترنت:

```text
./gradlew assembleDebug = rc 1
./gradlew bundleRelease = rc 1
java.net.UnknownHostException: services.gradle.org
```

يجب تشغيل GitHub Actions لإنتاج:

```text
APK Debug
AAB Release
CHECKSUMS_ANDROID.txt
BOUH_v14_0_INSTALLABLE_ANDROID_ARTIFACTS.zip
```

## قائمة اختبار APK الميداني المطلوبة

```text
الرئيسية: لا تظهر Failed to fetch وتظهر 4303 خلية.
الرادار: الخريطة واضحة، crosshair في المركز، لا توجد لوحة تغطي نصف الخريطة.
الرادار: تحريك الخريطة يغير Lat/Lng ويحدث Local Ground Score.
الرادار: النتيجة mode = ground_grid أو no_data، ولا تظهر api_unavailable.
التقارير: تعرض score/class/mode/limitation بعد تحليل نقطة.
المكتبة: تعرض 4303 خلية ونطاق التغطية التقريبي.
السلامة والإعدادات: مختصرة وواضحة.
```
