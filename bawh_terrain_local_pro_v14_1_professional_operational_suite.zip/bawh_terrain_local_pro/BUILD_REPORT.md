# BUILD_REPORT.md — v14.1 Professional Operational Suite

## الهدف

تجهيز النسخة الاحترافية الحقيقية بحيث لا تكون واجهة أسماء فقط، بل منظومة تشغيل محلية داخل APK.

```text
خريطة → مركز الشاشة → بحث في 4303 خلية → Ground Score → تقرير نقطة → مركز أنظمة
```

## الأنظمة المفعلة

```text
الرئيسية = تشغيل محلي + 4303 خلية + فتح الرادار + المكتبة + مركز الأنظمة
الرادار = خريطة + crosshair + radius + local score + details collapsed
التقارير = آخر قراءة محلية + score/class/mode/limitation + JSON
المكتبة = حالة قاعدة التحليل + التغطية التقريبية + اختبار أقرب خلية
الأنظمة = لوحة فحص كل الأنظمة التشغيلية
الإعدادات = radius الافتراضي + layer + تتبع المركز + cache + نسخة التطبيق
السلامة = Offline-first / Safe uploads / Path traversal / Local cache / API headers
```

## Offline Data Layer

```text
apps/web/public/data/bouh_ground_grid_compact.json
apps/web/android/app/src/main/assets/public/data/bouh_ground_grid_compact.json
cells = 4303
sha256 = caedab8f958013fd1b41625f80950a4b29f689cb74b674369467f29a304287f9
```

## Local Ground Grid Engine

```text
apps/web/src/bouh/localGroundGrid.ts
```

ينفذ:

```text
loadLocalGroundGrid()
calculateLocalGroundScore()
calculateLocalGroundScoreFromCells()
getLocalGroundGridStatus()
calculateNearestForLibrarySample()
persistLocalGroundReading()
readLastLocalGroundReading()
```

## Radar Behavior

```text
Local ground grid هو المصدر الأساسي.
API الخارجي ليس مطلوبًا لحساب Ground Score.
map moveend يقرأ مركز الخريطة.
الإحداثيات تعرض Lat/Lng منفصلة.
radius selector = 100 / 300 / 500 / 1000.
MBTiles/PMTiles drawer مغلق افتراضيًا.
crosshair ثابت في مركز الخريطة.
```

## Data Integrity

لم يتم تغيير:

```text
data/precomputed/bouh_ground_grid.sqlite
ground_cells = 4303
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
الأوزان
أسماء الحقول
live-score repository logic
```

Top cell remains:

```text
cell_id = partial_raw_0004117
lat = 19.41022162800518
lng = 36.86820999932388
final_ground_score = 66.0
class = Class C
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
```

## Scientific Policy

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
Field-check only
```

## Build / Test

```text
npm install = passed
npm run build = passed
npm run build:strict = passed
Capacitor sync Android = passed
validate_v12_5_analytical_pack = passed
test_live_score_repository = 3 passed
test_v12_6_ready_analyzed_grid = 1 passed
```

## APK/AAB

محاولة Gradle محليًا محجوبة بسبب بيئة الجلسة فقط:

```text
./gradlew assembleDebug = rc 1
./gradlew bundleRelease = rc 1
reason: java.net.UnknownHostException services.gradle.org
```

GitHub Actions داخل الحزمة محدث لإنتاج:

```text
APK Debug
AAB Release
CHECKSUMS_ANDROID.txt
BOUH_v14_1_INSTALLABLE_ANDROID_ARTIFACTS.zip
```
