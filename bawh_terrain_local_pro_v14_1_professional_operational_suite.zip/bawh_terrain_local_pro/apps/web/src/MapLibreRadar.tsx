import React, { useEffect, useRef, useState } from "react";
import maplibregl, { Map, NavigationControl } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";

type BaseMapMode = "esri" | "hybrid" | "streets";

type MapLibreRadarProps = {
  lat: number;
  lng: number;
  radius: number;
  followMapCenter?: boolean;
  showLocalMaps?: boolean;
  onCoords: (lat: number, lng: number) => void;
  onMessage: (message: string) => void;
};

const ESRI_WORLD_IMAGERY = "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
const ESRI_REFERENCE = "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}";
const OSM_STREETS = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";

const style = {
  version: 8,
  sources: {
    esriWorldImagery: {
      type: "raster",
      tiles: [ESRI_WORLD_IMAGERY],
      tileSize: 256,
      attribution: "Tiles © Esri"
    },
    esriReference: {
      type: "raster",
      tiles: [ESRI_REFERENCE],
      tileSize: 256
    },
    streets: {
      type: "raster",
      tiles: [OSM_STREETS],
      tileSize: 256,
      attribution: "© OpenStreetMap"
    }
  },
  layers: [
    { id: "esri-world-imagery", type: "raster", source: "esriWorldImagery", layout: { visibility: "visible" } },
    { id: "esri-reference", type: "raster", source: "esriReference", layout: { visibility: "visible" }, paint: { "raster-opacity": 0.82 } },
    { id: "streets", type: "raster", source: "streets", layout: { visibility: "none" } }
  ]
};

export default function MapLibreRadar({
  lat,
  lng,
  radius,
  followMapCenter = true,
  showLocalMaps = false,
  onCoords,
  onMessage
}: MapLibreRadarProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<Map | null>(null);
  const followRef = useRef(followMapCenter);
  const [baseMapMode, setBaseMapMode] = useState<BaseMapMode>("esri");

  useEffect(() => {
    followRef.current = followMapCenter;
  }, [followMapCenter]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: style as any,
      center: [lng, lat],
      zoom: 13,
      pitch: 0,
      bearing: 0,
      attributionControl: { compact: true }
    });

    map.addControl(new NavigationControl({ visualizePitch: false }), "bottom-left");

    map.on("load", () => {
      syncBaseMap(map, baseMapMode);
      onMessage("يعمل التطبيق بالبيانات المحلية.");
    });

    map.on("moveend", () => {
      if (!followRef.current) return;
      const center = map.getCenter();
      onCoords(center.lat, center.lng);
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || followMapCenter) return;

    const current = map.getCenter();
    const moved = Math.abs(current.lat - lat) > 0.000001 || Math.abs(current.lng - lng) > 0.000001;
    if (moved) {
      map.easeTo({ center: [lng, lat], duration: 250 });
    }
  }, [lat, lng, followMapCenter]);

  useEffect(() => {
    const map = mapRef.current;
    if (map && map.isStyleLoaded()) {
      syncBaseMap(map, baseMapMode);
    }
  }, [baseMapMode]);

  return (
    <div className="operational-map-wrap">
      <div ref={containerRef} className="operational-map" />

      <div className="map-mode-buttons" aria-label="أزرار الطبقات">
        <button className={baseMapMode === "esri" ? "active" : ""} type="button" onClick={() => setBaseMapMode("esri")}>Esri</button>
        <button className={baseMapMode === "hybrid" ? "active" : ""} type="button" onClick={() => setBaseMapMode("hybrid")}>Hybrid</button>
        <button className={baseMapMode === "streets" ? "active" : ""} type="button" onClick={() => setBaseMapMode("streets")}>Streets</button>
      </div>

      <div className="map-center-radar-ring radar-crosshair" aria-hidden="true">
        <span />
      </div>
      <div className="map-center-crosshair" aria-hidden="true" />

      <div className="map-coordinate-chip">
        <span>Lat</span>
        <strong dir="ltr">{lat.toFixed(6)}</strong>
        <span>Lng</span>
        <strong dir="ltr">{lng.toFixed(6)}</strong>
      </div>

      <div className="map-radius-chip">
        <span>{radius}m</span>
      </div>

      {showLocalMaps && (
        <div className="local-maps-drawer">
          <strong>الخرائط المحلية</strong>
          <p>MBTiles/PMTiles drawer مغلق افتراضيًا. لا يتم تحميل ملفات خرائط ثقيلة داخل Android assets.</p>
          <small>يمكن ربط إدارة الخرائط المحلية لاحقًا دون تغطية شاشة التحليل.</small>
        </div>
      )}
    </div>
  );
}

function syncBaseMap(map: Map, mode: BaseMapMode) {
  safeSetVisibility(map, "esri-world-imagery", mode === "esri" || mode === "hybrid");
  safeSetVisibility(map, "esri-reference", mode === "hybrid");
  safeSetVisibility(map, "streets", mode === "streets");
}

function safeSetVisibility(map: Map, layerId: string, visible: boolean) {
  if (!map.getLayer(layerId)) return;
  map.setLayoutProperty(layerId, "visibility", visible ? "visible" : "none");
}
