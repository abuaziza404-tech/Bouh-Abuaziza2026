import React, { useState } from "react";
import MapLibreRadar from "./MapLibreRadar";
import BouhLiveGroundScoreMeter from "./bouh/BouhLiveGroundScoreMeter";
import "./bouh/bouh_live_meter.css";
import { getNativePosition } from "./native";
import { calculateLocalGroundScore, persistLocalGroundReading } from "./bouh/localGroundGrid";

const radiusOptions = [100, 300, 500, 1000] as const;

export default function RadarPage({
  lat,
  lng,
  defaultRadius,
  defaultFollowCenter,
  onCoords,
  onMessage
}: {
  lat: number;
  lng: number;
  defaultRadius: number;
  defaultFollowCenter: boolean;
  onCoords: (lat: number, lng: number) => void;
  onMessage: (message: string) => void;
}) {
  const [radius, setRadius] = useState<number>(radiusOptions.includes(defaultRadius as any) ? defaultRadius : 300);
  const [followCenter, setFollowCenter] = useState(defaultFollowCenter);
  const [showLocalMaps, setShowLocalMaps] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  async function analyzeCenter() {
    const reading = await calculateLocalGroundScore(lat, lng, radius);
    persistLocalGroundReading(reading);
    setRefreshKey((value) => value + 1);

    if (reading.mode === "ground_grid") {
      onMessage(`تم حساب Ground Score محليًا: ${reading.result?.final_ground_score ?? "—"} · ${reading.result?.class ?? "—"}`);
    } else {
      onMessage("لا توجد خلية تحليل قريبة ضمن النطاق المحدد.");
    }
  }

  async function useNativeGps() {
    const position = await getNativePosition();
    if (!position) {
      onMessage("لم يتم الحصول على GPS من الجهاز.");
      return;
    }

    onCoords(position.lat, position.lng);
    setRefreshKey((value) => value + 1);
    onMessage("تم تحديث موقع الرادار من GPS الجهاز.");
  }

  return (
    <section className="screen radar-pro-screen true-offline-radar">
      <header className="radar-pro-header">
        <div>
          <span className="eyebrow">رادار التحليل الميداني</span>
          <h2>تحليل مركز الشاشة</h2>
        </div>
        <div className="radar-header-meta">
          <span>Offline</span>
          <strong dir="ltr">Lat: {lat.toFixed(6)}</strong>
          <strong dir="ltr">Lng: {lng.toFixed(6)}</strong>
        </div>
      </header>

      <article className="radar-map-shell-pro operational-map-card">
        <MapLibreRadar
          lat={lat}
          lng={lng}
          radius={radius}
          followMapCenter={followCenter}
          showLocalMaps={showLocalMaps}
          onCoords={(nextLat, nextLng) => {
            onCoords(nextLat, nextLng);
            setRefreshKey((value) => value + 1);
          }}
          onMessage={onMessage}
        />

        <div className="radar-floating-actions">
          <button type="button" onClick={() => setShowLocalMaps((value) => !value)}>الخرائط المحلية</button>
        </div>
      </article>

      <article className="radar-controls-pro">
        <div className="pin-mode-row">
          <button type="button" className={followCenter ? "active" : ""} onClick={() => setFollowCenter(true)}>
            تتبع مركز الشاشة
          </button>
          <button type="button" className={!followCenter ? "active" : ""} onClick={() => setFollowCenter(false)}>
            تثبيت المركز
          </button>
        </div>

        <div className="radius-row">
          <span>نطاق القراءة</span>
          <div>
            {radiusOptions.map((value) => (
              <button
                key={value}
                type="button"
                className={radius === value ? "active" : ""}
                onClick={() => {
                  setRadius(value);
                  setRefreshKey((current) => current + 1);
                }}
              >
                {value}m
              </button>
            ))}
          </div>
        </div>

        <div className="action-row compact-actions">
          <button className="primary" type="button" onClick={analyzeCenter}>تحليل المركز الحالي</button>
          <button className="secondary" type="button" onClick={useNativeGps}>GPS</button>
        </div>
      </article>

      <BouhLiveGroundScoreMeter key={`${lat.toFixed(6)}-${lng.toFixed(6)}-${radius}-${refreshKey}`} lat={lat} lng={lng} radius={radius} />
    </section>
  );
}
