# BUILD_REPORT.md — v14.2 Field Grade Operational Suite

## الهدف

تطبيق واجهة رادار ميدانية حقيقية مستوحاة من النموذج المرفق، مع فصل الأنظمة والسلامة والطقس والتنبؤات عن واجهة الخريطة.

## الواجهة الجديدة

- الرادار أصبح شاشة تشغيل ميداني كاملة.
- خريطة Satellite/Hybird/Streets تملأ واجهة الرادار.
- شريط إحداثيات علوي بنمط ميداني.
- لوحة جاهزية محلية:
  - جاهز
  - 4303 خلية
  - رادار تحليلي محلي
- عدادات مصغرة:
  - تضاريس
  - طيفي
  - حراري
- crosshair مركزي ودائرة رادار.
- بطاقة درجة ميدانية:
  - Ground Score
  - evidence_count
  - class
  - FeOx/alteration proxy
  - terrain score
  - limitation
- أزرار جانبية صغيرة:
  - أقمار
  - هجين
  - طرق
  - خرائط
- شريط تحكم سفلي داخل الرادار:
  - تتبع المركز
  - تحليل
  - GPS
  - radius
- radius selector:
  - 100m
  - 300m
  - 500m
  - 1000m
- تفاصيل المؤشرات collapsed.
- الأنظمة والسلامة والإعدادات منفصلة خارج شاشة الرادار.

## الأنظمة الفعلية

```text
الرئيسية = تشغيل محلي + 4303 خلية + فتح الرادار + المكتبة + مركز الأنظمة
الرادار = خريطة ميدانية + عداد الدرجات + local ground grid
التقارير = آخر قراءة محلية + score/class/mode/limitation + JSON
المكتبة = حالة قاعدة التحليل + تغطية تقريبية + اختبار أقرب خلية
الأنظمة = فحص الأنظمة التشغيلية
السلامة = Offline-first / Safe uploads / Path traversal / Local cache / API headers
الإعدادات = radius + layer + تتبع المركز + cache + نسخة التطبيق
```

## Offline Ground Grid

```text
apps/web/public/data/bouh_ground_grid_compact.json
apps/web/android/app/src/main/assets/public/data/bouh_ground_grid_compact.json
cells = 4303
sha256 = caedab8f958013fd1b41625f80950a4b29f689cb74b674369467f29a304287f9
```

## Data Integrity

لم يتم تغيير:

```text
data/precomputed/bouh_ground_grid.sqlite
ground_cells = 4303
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
الأوزان
أسماء الحقول
live-score repository logic
```

Top cell remains:

```text
cell_id = partial_raw_0004117
lat = 19.41022162800518
lng = 36.86820999932388
final_ground_score = 66.0
class = Class C
truth_status = partial_raw_grid_landsat_dem_not_full_spectral
```

## Scientific Guardrails

```text
partial ready analyzed ground grid from Landsat/DEM
No Gold Proof
No Depth
No 100%
No Gold Target
Surface screening only
Field-check only
```

## Build / Test

```text
npm install = passed
npm run build = passed
npm run build:strict = passed
Capacitor sync Android = passed
validate_v12_5_analytical_pack = passed
test_live_score_repository = 3 passed
test_v12_6_ready_analyzed_grid = 1 passed
```

## APK/AAB

محاولة Gradle المحلية محجوبة بسبب بيئة الجلسة:

```text
./gradlew assembleDebug = rc 1
./gradlew bundleRelease = rc 1
reason: java.net.UnknownHostException services.gradle.org
```

GitHub Actions داخل الحزمة محدث لإنتاج:

```text
APK Debug
AAB Release
CHECKSUMS_ANDROID.txt
BOUH_v14_2_INSTALLABLE_ANDROID_ARTIFACTS.zip
```
