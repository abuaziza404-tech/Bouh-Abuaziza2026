# RELEASE_NOTES.md — v12 BOUH Core Android Release

## الجديد

- تثبيت v11 كأساس إنتاجي.
- دمج BOUH Core.
- تطبيق Evidence Guard.
- Decision Rules: Structure → Pattern → Alteration → Confirmation → Decision.
- GPZ Strategy.
- Report Center HTML/JSON.
- Data Manager.
- Radar Library + Corridor Alias.
- NDMI support.
- Layer metadata endpoint.
- Android package id: `com.bawh.terrain`.
- Scripts: build_android_debug/release/check_android_release.

## نواقص بيئة البناء

لا يمكن إنتاج APK/AAB داخل هذه الجلسة دون Android SDK وGradle project كامل. تم تجهيز scripts والتعليمات. BUILD_REPORT.md يوضح نتيجة المحاولة الفعلية.


## v12 Build Status

راجع BUILD_REPORT.md للتفاصيل الصادقة حول الاختبارات وAndroid/Docker.


## v12.3 Verified Android Ready Patch

- Fixed MapLibre overlay timing for lightweight BOUH overlays.
- Updated `.env.example` to `APP_VERSION=12.2.0-lightweight-overlay-cache-release`.
- Updated Android `versionCode 122` and `versionName "12.2.0-lightweight-overlay-cache-release"`.
- Re-ran frontend build and Capacitor sync.
- Attempted Playwright install/E2E; blocked by cdn.playwright.dev DNS/network.
- Attempted APK/AAB; blocked by services.gradle.org DNS/network.
- Confirmed no heavy GeoTIFF/ZIP/DEM/JP2/MBTiles/PMTiles in Android public assets.


## v12.4 Android Build Artifacts

- Unified runtime/build version to `12.3.0-verified-android-ready-patch`.
- Android `versionCode 123`.
- Android `versionName "12.3.0-verified-android-ready-patch"`.
- Added GitHub Actions `android-build` job.
- Attempted Playwright install/E2E; blocked by `cdn.playwright.dev` DNS/network.
- Attempted APK Debug and AAB Release; blocked by `services.gradle.org` DNS/network.
- Added `CHECKSUMS_ANDROID.txt`.
- Confirmed no GeoTIFF/ZIP/DEM/JP2/MBTiles/PMTiles in Android assets.

## v12.5 Ground Grid Live Radar Engine

- Integrated official analytical authority pack.
- Added `/bouh/live-score`.
- Added `/bouh/live-score/status`.
- Added `BouhLiveGroundScoreMeter` to RadarPage.
- Ran `scripts/build_bouh_ground_grid.py`.
- No raw calculation-grade rasters were found in `data/imports`, so no raw-pixel ground grid was built.
- Current live score modes: `seed_context_only` and `no_data`.
- Added/updated `data/precomputed/BOUH_GROUND_GRID_BUILD_REPORT.md`.
- Validation passed:
  - `python scripts/validate_v12_5_analytical_pack.py`
  - `pytest tests/test_live_score_repository.py -q`
- No GeoTIFF/ZIP/DEM/JP2/MBTiles/PMTiles added to Android assets.


## v12.6 Final Ready Analyzed Ground Grid

- Integrated real `BOUH_v12_6_READY_ANALYZED_GROUND_GRID_DATA.zip`.
- Verified SHA256: `c89cedffb3916878f4fee9a22868300af43fc85874d9d79ef69ee657816c949d`.
- Copied `data/precomputed/bouh_ground_grid.sqlite`.
- Verified `ground_cells = 4303`.
- Live score status reports `ground_grid_exists = true` and `ground_grid_cell_count = 4303`.
- Exact T1 point falls back honestly to `seed_context_only` because no grid cell exists within 300m.
- Nearest real grid cell returns `mode = ground_grid`.
- Sources: Landsat reflectance composite, Landsat TIR, Landsat QA_PIXEL, DEM n19_e036_3arc_v2.
- Not Sentinel/SWIR full spectral stack.
- No Gold Proof, no Depth, no 100%.


## v12.7 Android Release Candidate

- Adopted v12.6 Final Ready Analyzed Ground Grid as the analytical baseline.
- Cleaned BUILD_REPORT header to v12.6 Final.
- Standardized CHECKSUMS_FULL format.
- Verified `ground_cells = 4303`.
- Tested top 20 analyzed cells; all returned `mode = ground_grid`.
- Verified API endpoints with local FastAPI:
  - `/bouh/live-score/status`
  - `/bouh/live-score?lat=19.41022162800518&lng=36.86820999932388&radius=300`
- Docker commands attempted but blocked by local permission denied.
- Android APK/AAB commands attempted but blocked by `services.gradle.org` DNS/network.
- No analytical database, weights, field names, or Android heavy-asset policy changes.


## v12.8 Final Android Artifacts

- Adopted v12.7 RC without analytical changes.
- Regenerated `CHECKSUMS_ANDROID.txt`.
- Regenerated `CHECKSUMS_FULL.txt` after the last file changes.
- Verified `ground_cells = 4303`.
- Android build attempted; blocked by `services.gradle.org` DNS/network in this environment.
- No heavy Android assets added.


## v12.9 Installable Android Release

- Adopted v12.8 as Final Android Artifacts Source Package.
- Cleaned `data/precomputed/BOUH_GROUND_GRID_BUILD_REPORT.md` heading/status.
- Attempted APK Debug and AAB Release builds.
- Gradle build remained blocked by `services.gradle.org` DNS/network.
- Updated `CHECKSUMS_ANDROID.txt`.
- Regenerated `CHECKSUMS_FULL.txt` after all changes.
- Preserved `ground_cells = 4303`, weights, field names, truth_status, and no-heavy-assets policy.


## v13.0 GitHub Actions Build Ready Package

- Attempted APK Debug and AAB Release builds.
- No APK/AAB was produced because Gradle could not resolve `services.gradle.org`.
- Package is explicitly not labeled installable.
- Preserved `ground_cells = 4303`, weights, field names, truth_status, and scientific guardrails.
- Updated `CHECKSUMS_ANDROID.txt`.
- Regenerated `CHECKSUMS_FULL.txt` after all modifications.


## Android Build From Uploaded ZIP workflow

- Added `.github/workflows/android-build-from-zip.yml`.
- Builds APK/AAB from `bawh_terrain_local_pro_v13_0_github_actions_build_ready_package.zip` placed in the repository root.
- Verifies `ground_cells = 4303`.
- Verifies `truth_status = partial_raw_grid_landsat_dem_not_full_spectral`.
- Enforces no heavy raw map/raster files in Android assets.
- Uploads APK/AAB, `CHECKSUMS_ANDROID.txt`, and `BOUH_v13_0_INSTALLABLE_ANDROID_ARTIFACTS.zip`.


## v13.1 Professional Radar UX Patch

- Redesigned home, radar, reports, library, security, sources, navigation, and icons.
- Radar follows map center by default and updates live-score on center/radius changes.
- Added radius selector and center-analysis action.
- Moved local maps controls into a compact drawer.
- Preserved analytical database, weights, field names, truth_status, and no-proof policy.
- Updated GitHub Actions workflow for v13.1 Android build artifacts.


## v13.2 Final Radar UX Android Ready

- Cleaned BUILD_REPORT.md top title to v13.1 Professional Radar UX Patch.
- Added explicit crosshair classes: map-center-crosshair and radar-crosshair.
- Updated GitHub Actions workflow name to BOUH Android Build From ZIP.
- Workflow now installs postcss/autoprefixer and builds via direct Vite/Capacitor node commands.
- package.json build script changed to vite build.
- Added build:strict for tsc && vite build.
- Removed remaining APK/PWA install prompt text from source.
- Preserved ground_cells = 4303, truth_status, weights, fields, live-score logic, and scientific guardrails.


## v14.0 True Offline Operational Radar

- Added compact local ground grid JSON with 4303 cells.
- Added frontend localGroundGrid module for offline nearest-cell search.
- Live Ground Score now uses local ground grid first.
- Removed field-facing API failure states.
- Reports use last local radar reading.
- Rebuilt radar map as a clear full-width operational card.
- Local maps drawer is closed by default.
- Preserved SQLite, weights, fields, truth_status, and scientific guardrails.


## v14.1 Professional Operational Suite

- Added Systems center.
- Confirmed every operational tab has actual local function.
- Maintained true offline ground score engine.
- Preserved SQLite, weights, fields, truth_status, and scientific policy.
- Updated workflow/artifact names to v14.1.


## v14.2 Field Grade Operational Suite

- Applied a field-grade radar interface based on the provided operational mockup.
- Kept safety/weather/systems/settings outside the radar map interface.
- Added top coordinate panel, readiness strip, mini meters, score card, side tools, and radius controls.
- Preserved true offline local ground grid engine and all scientific guardrails.
