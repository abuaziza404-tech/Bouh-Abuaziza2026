import React, { useEffect, useState } from "react";
import RadarPage from "./RadarPage";
import ReportPage from "./ReportPage";
import LibraryPage from "./LibraryPage";
import SafetyPage from "./SafetyPage";
import SecurityPage from "./SecurityPage";
import SystemsPage from "./SystemsPage";
import { getLocalGroundGridStatus } from "./bouh/localGroundGrid";

type Screen = "dashboard" | "radar" | "reports" | "library" | "systems" | "settings";

const navItems: Array<{ id: Screen; label: string; icon: string }> = [
  { id: "dashboard", label: "الرئيسية", icon: "⌂" },
  { id: "radar", label: "الرادار", icon: "◎" },
  { id: "reports", label: "التقارير", icon: "▤" },
  { id: "library", label: "المكتبة", icon: "▥" },
  { id: "systems", label: "الأنظمة", icon: "◇" },
  { id: "settings", label: "الإعدادات", icon: "⚙" }
];

export default function App() {
  const [screen, setScreen] = useState<Screen>("dashboard");
  const [lat, setLat] = useState(19.41022162800518);
  const [lng, setLng] = useState(36.86820999932388);
  const [message, setMessage] = useState("يعمل التطبيق بالبيانات المحلية.");
  const [gridReady, setGridReady] = useState(false);
  const [defaultRadius, setDefaultRadius] = useState<number>(() => Number(localStorage.getItem("bouh.default_radius") ?? 300));
  const [defaultLayer, setDefaultLayer] = useState<string>(() => localStorage.getItem("bouh.default_layer") ?? "esri");
  const [followCenterDefault, setFollowCenterDefault] = useState<boolean>(() => localStorage.getItem("bouh.follow_center") !== "false");

  useEffect(() => {
    getLocalGroundGridStatus()
      .then(() => {
        setGridReady(true);
        setMessage("البيانات المحلية جاهزة: 4303 خلية.");
      })
      .catch(() => {
        setGridReady(false);
        setMessage("تعذر تحميل طبقة البيانات المحلية.");
      });
  }, []);

  const title = navItems.find((item) => item.id === screen)?.label ?? "الرئيسية";

  return (
    <main className="app-shell operational-shell" dir="rtl">
      <header className="operational-topbar">
        <div className="brand">
          <div className="brand-mark bouh-icon-mini" aria-hidden="true" />
          <div>
            <h1>بوح التضاريس</h1>
            <p>Offline-first · {title}</p>
          </div>
        </div>
        <div className="local-pill">محلي</div>
      </header>

      <div className="status-line compact-status">{message}</div>

      {screen === "dashboard" && (
        <Dashboard
          gridReady={gridReady}
          onOpenRadar={() => setScreen("radar")}
          onOpenLibrary={() => setScreen("library")}
          onOpenSystems={() => setScreen("systems")}
          onMessage={setMessage}
        />
      )}

      {screen === "radar" && (
        <RadarPage
          lat={lat}
          lng={lng}
          defaultRadius={defaultRadius}
          defaultFollowCenter={followCenterDefault}
          onCoords={(nextLat, nextLng) => {
            setLat(nextLat);
            setLng(nextLng);
          }}
          onMessage={setMessage}
        />
      )}

      {screen === "reports" && <ReportPage onMessage={setMessage} />}
      {screen === "library" && <LibraryPage currentLat={lat} currentLng={lng} onMessage={setMessage} />}
      {screen === "systems" && <SystemsPage onMessage={setMessage} />}
      {screen === "settings" && (
        <SecurityPage
          defaultRadius={defaultRadius}
          defaultLayer={defaultLayer}
          followCenterDefault={followCenterDefault}
          onDefaultRadiusChange={(value) => {
            setDefaultRadius(value);
            localStorage.setItem("bouh.default_radius", String(value));
            setMessage("تم تحديث نصف القطر الافتراضي.");
          }}
          onDefaultLayerChange={(value) => {
            setDefaultLayer(value);
            localStorage.setItem("bouh.default_layer", value);
            setMessage("تم تحديث الطبقة الافتراضية.");
          }}
          onFollowCenterChange={(value) => {
            setFollowCenterDefault(value);
            localStorage.setItem("bouh.follow_center", String(value));
            setMessage("تم تحديث تتبع مركز الخريطة.");
          }}
          onMessage={setMessage}
        />
      )}

      <nav className="bottom-nav operational-bottom-nav" aria-label="أقسام التطبيق">
        {navItems.map((item) => (
          <button key={item.id} type="button" className={screen === item.id ? "active" : ""} onClick={() => setScreen(item.id)}>
            <span>{item.icon}</span>
            <small>{item.label}</small>
          </button>
        ))}
      </nav>
    </main>
  );
}

function Dashboard({
  gridReady,
  onOpenRadar,
  onOpenLibrary,
  onOpenSystems,
  onMessage
}: {
  gridReady: boolean;
  onOpenRadar: () => void;
  onOpenLibrary: () => void;
  onOpenSystems: () => void;
  onMessage: (message: string) => void;
}) {
  return (
    <section className="screen home-clean operational-home">
      <article className="home-hero-card">
        <span className="eyebrow">BOUH Terrain</span>
        <h2>بوح التضاريس</h2>
        <p>منظومة تشغيل ميداني Offline-first للطبقات السطحية والتضاريس تعمل من داخل APK.</p>

        <div className="home-status-grid">
          <StatusPill label="حالة التشغيل" value={gridReady ? "يعمل محليًا" : "تحميل محلي"} />
          <StatusPill label="قاعدة التحليل" value="4303 خلية" />
          <StatusPill label="نوع التحليل" value="Landsat/DEM جزئي" />
          <StatusPill label="API" value="اختياري فقط" />
        </div>

        <div className="home-actions">
          <button className="primary xl" type="button" onClick={onOpenRadar}>فتح رادار التحليل</button>
          <button className="secondary xl" type="button" onClick={onOpenLibrary}>المكتبة / إدارة البيانات</button>
          <button className="secondary xl" type="button" onClick={onOpenSystems}>مركز الأنظمة</button>
        </div>
      </article>

      <article className="truth-card">
        <strong>Field-check</strong>
        <span>Surface Screening</span>
        <span>No Gold Proof</span>
      </article>

      <section className="home-quick-grid">
        <button type="button" onClick={() => onMessage("افتح الرادار، حرّك الخريطة، ثم حلّل مركز الشاشة.")}>خريطة → مركز</button>
        <button type="button" onClick={() => onMessage("البحث يتم محليًا في 4303 خلية.")}>بحث محلي</button>
        <button type="button" onClick={() => onMessage("النتيجة احتمالية وتحتاج فحصًا ميدانيًا.")}>تقرير نقطة</button>
      </section>
    </section>
  );
}

function StatusPill({ label, value }: { label: string; value: string }) {
  return (
    <div className="status-pill">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
