import React, { useEffect, useState } from "react";
import { calculateNearestForLibrarySample, getLocalGroundGridStatus } from "./bouh/localGroundGrid";

type GridStatus = {
  ground_cells: number;
  truth_status: string;
  min_lat: number;
  max_lat: number;
  min_lng: number;
  max_lng: number;
};

export default function LibraryPage({
  currentLat,
  currentLng,
  onMessage
}: {
  currentLat: number;
  currentLng: number;
  onMessage: (message: string) => void;
}) {
  const [status, setStatus] = useState<GridStatus | null>(null);
  const [sample, setSample] = useState<string>("لم يتم الاختبار بعد.");

  useEffect(() => {
    loadStatus();
  }, []);

  async function loadStatus() {
    try {
      const next = await getLocalGroundGridStatus();
      setStatus(next);
      onMessage("قاعدة التحليل المحلية جاهزة.");
    } catch {
      onMessage("تعذر قراءة قاعدة التحليل المحلية.");
    }
  }

  async function testNearest() {
    const reading = await calculateNearestForLibrarySample();
    setSample(reading.mode === "ground_grid"
      ? `${reading.result?.cell_id} · score ${reading.result?.final_ground_score} · ${reading.result?.class}`
      : "لا توجد خلية ضمن نطاق الاختبار.");
    onMessage("تم اختبار أقرب خلية محلية.");
  }

  return (
    <section className="screen concise-page operational-library">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">المكتبة / إدارة البيانات</span>
        <h2>قاعدة التحليل المحلية</h2>
        <p>هذه الصفحة تعرض حالة بيانات APK المحلية دون الاعتماد على API خارجي.</p>
        <div className="action-row">
          <button className="primary" type="button" onClick={loadStatus}>عرض حالة قاعدة التحليل</button>
          <button className="secondary" type="button" onClick={testNearest}>اختبار أقرب خلية</button>
        </div>
      </article>

      <article className="panel clean-card">
        <h3>حالة قاعدة التحليل</h3>
        <div className="status-list">
          <div><span>عدد الخلايا</span><strong>{status?.ground_cells ?? 4303}</strong></div>
          <div><span>المصادر</span><strong>Landsat/DEM</strong></div>
          <div><span>truth_status</span><strong dir="ltr">{status?.truth_status ?? "partial_raw_grid_landsat_dem_not_full_spectral"}</strong></div>
          <div><span>نوع التحليل</span><strong>partial ready analyzed ground grid</strong></div>
        </div>
      </article>

      <article className="panel clean-card">
        <h3>نطاق التغطية التقريبي</h3>
        <div className="coverage-grid">
          <Row label="Lat min" value={status?.min_lat?.toFixed(6) ?? "—"} />
          <Row label="Lat max" value={status?.max_lat?.toFixed(6) ?? "—"} />
          <Row label="Lng min" value={status?.min_lng?.toFixed(6) ?? "—"} />
          <Row label="Lng max" value={status?.max_lng?.toFixed(6) ?? "—"} />
          <Row label="Current Lat" value={currentLat.toFixed(6)} />
          <Row label="Current Lng" value={currentLng.toFixed(6)} />
        </div>
      </article>

      <article className="panel clean-card">
        <h3>النطاقات</h3>
        <div className="region-list">
          <Region name="South" detail="نطاق الجنوب" />
          <Region name="Center" detail="نطاق الوسط" />
          <Region name="North" detail="نطاق الشمال" />
        </div>
      </article>

      <article className="panel clean-card">
        <h3>اختبار محلي</h3>
        <p>{sample}</p>
      </article>
    </section>
  );
}

function Region({ name, detail }: { name: string; detail: string }) {
  return (
    <div>
      <strong>{name}</strong>
      <span>{detail}</span>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span>{label}</span>
      <strong dir="ltr">{value}</strong>
    </div>
  );
}
