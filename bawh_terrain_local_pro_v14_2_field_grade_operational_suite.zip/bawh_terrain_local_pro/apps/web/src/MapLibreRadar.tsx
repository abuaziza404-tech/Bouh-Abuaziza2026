import React, { useEffect, useRef, useState } from "react";
import maplibregl, { Map, NavigationControl } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";

export type FieldBaseMapMode = "satellite" | "hybrid" | "streets";

type MapLibreRadarProps = {
  lat: number;
  lng: number;
  radius: number;
  followMapCenter?: boolean;
  showLocalMaps?: boolean;
  baseMapMode?: FieldBaseMapMode;
  onCoords: (lat: number, lng: number) => void;
  onMessage: (message: string) => void;
};

const ESRI_WORLD_IMAGERY = "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
const ESRI_REFERENCE = "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}";
const OSM_STREETS = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";

const style = {
  version: 8,
  sources: {
    esriWorldImagery: {
      type: "raster",
      tiles: [ESRI_WORLD_IMAGERY],
      tileSize: 256,
      attribution: "Tiles © Esri"
    },
    esriReference: {
      type: "raster",
      tiles: [ESRI_REFERENCE],
      tileSize: 256
    },
    streets: {
      type: "raster",
      tiles: [OSM_STREETS],
      tileSize: 256,
      attribution: "© OpenStreetMap"
    }
  },
  layers: [
    { id: "esri-world-imagery", type: "raster", source: "esriWorldImagery", layout: { visibility: "visible" } },
    { id: "esri-reference", type: "raster", source: "esriReference", layout: { visibility: "none" }, paint: { "raster-opacity": 0.82 } },
    { id: "streets", type: "raster", source: "streets", layout: { visibility: "none" } }
  ]
};

export default function MapLibreRadar({
  lat,
  lng,
  radius,
  followMapCenter = true,
  showLocalMaps = false,
  baseMapMode = "satellite",
  onCoords,
  onMessage
}: MapLibreRadarProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<Map | null>(null);
  const followRef = useRef(followMapCenter);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    followRef.current = followMapCenter;
  }, [followMapCenter]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: style as any,
      center: [lng, lat],
      zoom: 15,
      pitch: 0,
      bearing: 0,
      attributionControl: false
    });

    map.addControl(new NavigationControl({ visualizePitch: false, showCompass: false }), "bottom-right");

    map.on("load", () => {
      syncBaseMap(map, baseMapMode);
      setReady(true);
      onMessage("الرادار يعمل محليًا من طبقة 4303 خلية.");
    });

    map.on("moveend", () => {
      if (!followRef.current) return;
      const center = map.getCenter();
      onCoords(center.lat, center.lng);
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready) return;
    syncBaseMap(map, baseMapMode);
  }, [baseMapMode, ready]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || followMapCenter) return;

    const current = map.getCenter();
    const moved = Math.abs(current.lat - lat) > 0.000001 || Math.abs(current.lng - lng) > 0.000001;
    if (moved) {
      map.easeTo({ center: [lng, lat], duration: 220 });
    }
  }, [lat, lng, followMapCenter]);

  return (
    <div className="field-map-wrap">
      <div ref={containerRef} className="field-map" />

      <div className="field-radar-ring radar-crosshair" aria-hidden="true">
        <span />
      </div>
      <div className="field-crosshair map-center-crosshair" aria-hidden="true" />

      <div className="field-radius-ring" style={{ width: `${Math.min(74, Math.max(38, radius / 12))}vw`, height: `${Math.min(74, Math.max(38, radius / 12))}vw` }} aria-hidden="true" />

      <div className="field-zoom-pill">
        <b>{radius}m</b>
      </div>

      {showLocalMaps && (
        <div className="field-drawer">
          <strong>الخرائط المحلية</strong>
          <p>إدارة MBTiles/PMTiles منفصلة عن شاشة الرادار. لا توجد حزم خرائط ثقيلة داخل Android assets.</p>
        </div>
      )}
    </div>
  );
}

function syncBaseMap(map: Map, mode: FieldBaseMapMode) {
  safeSetVisibility(map, "esri-world-imagery", mode === "satellite" || mode === "hybrid");
  safeSetVisibility(map, "esri-reference", mode === "hybrid");
  safeSetVisibility(map, "streets", mode === "streets");
}

function safeSetVisibility(map: Map, layerId: string, visible: boolean) {
  if (!map.getLayer(layerId)) return;
  map.setLayoutProperty(layerId, "visibility", visible ? "visible" : "none");
}
