import React, { useEffect, useMemo, useState } from "react";
import MapLibreRadar, { FieldBaseMapMode } from "./MapLibreRadar";
import "./bouh/bouh_live_meter.css";
import { getNativePosition } from "./native";
import {
  LocalGroundScoreResult,
  calculateLocalGroundScore,
  deriveOperationalIndicators,
  persistLocalGroundReading
} from "./bouh/localGroundGrid";

const radiusOptions = [100, 300, 500, 1000] as const;

export default function RadarPage({
  lat,
  lng,
  defaultRadius,
  defaultFollowCenter,
  onCoords,
  onMessage
}: {
  lat: number;
  lng: number;
  defaultRadius: number;
  defaultFollowCenter: boolean;
  onCoords: (lat: number, lng: number) => void;
  onMessage: (message: string) => void;
}) {
  const [radius, setRadius] = useState<number>(radiusOptions.includes(defaultRadius as any) ? defaultRadius : 300);
  const [followCenter, setFollowCenter] = useState(defaultFollowCenter);
  const [showLocalMaps, setShowLocalMaps] = useState(false);
  const [baseMapMode, setBaseMapMode] = useState<FieldBaseMapMode>("satellite");
  const [reading, setReading] = useState<LocalGroundScoreResult | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    calculate();
  }, [lat, lng, radius]);

  const indicators = useMemo(() => deriveOperationalIndicators(reading), [reading]);
  const mode = reading?.mode ?? "no_data";
  const result = reading?.result;

  async function calculate() {
    setBusy(true);
    try {
      const next = await calculateLocalGroundScore(lat, lng, radius);
      setReading(next);
      persistLocalGroundReading(next);
      onMessage(next.mode === "ground_grid" ? "تم تحديث قراءة الرادار محليًا." : "لا توجد خلية قريبة ضمن النطاق.");
    } finally {
      setBusy(false);
    }
  }

  async function useNativeGps() {
    const position = await getNativePosition();
    if (!position) {
      onMessage("لم يتم الحصول على GPS من الجهاز.");
      return;
    }
    onCoords(position.lat, position.lng);
    onMessage("تم تحديث موقع الرادار من GPS.");
  }

  const utmText = `Lat ${lat.toFixed(5)} · Lng ${lng.toFixed(5)}`;

  return (
    <section className="field-radar-screen" dir="rtl">
      <MapLibreRadar
        lat={lat}
        lng={lng}
        radius={radius}
        followMapCenter={followCenter}
        showLocalMaps={showLocalMaps}
        baseMapMode={baseMapMode}
        onCoords={onCoords}
        onMessage={onMessage}
      />

      <header className="field-top-overlay">
        <div className="field-coord-card">
          <strong dir="ltr">{lat.toFixed(5)}° N {lng.toFixed(5)}° E</strong>
          <span dir="ltr">{utmText} | Google Satellite</span>
        </div>
        <div className="field-brand-card">
          <span>بوح التضاريس</span>
          <b>BOUH</b>
        </div>
      </header>

      <section className="field-status-panel">
        <div className="field-ready-pill">
          <span>جاهز</span>
          <b>4303 خلية</b>
          <em>رادار تحليلي محلي</em>
        </div>

        <div className="field-mini-meters">
          <MiniMeter label="تضاريس" value={indicators.terrainSignal} />
          <MiniMeter label="طيفي" value={indicators.spectralSignal} />
          <MiniMeter label="حراري" value={indicators.thermalSignal} />
        </div>

        <div className="field-mode-line">
          <span>ملاحظة</span>
          <b>{mode === "ground_grid" ? "Ground Grid" : "No Data"}</b>
          <em>{radius}m</em>
        </div>
      </section>

      <section className="field-score-card">
        <div className="score-dial">
          <strong>{typeof result?.final_ground_score === "number" ? result.final_ground_score.toFixed(0) : "—"}</strong>
          <span>/100</span>
        </div>
        <div className="field-score-data">
          <h2>رادار تنبؤي للمؤشرات</h2>
          <div className="field-stat-grid">
            <FieldStat label="بينة" value={result?.evidence_count ?? "—"} />
            <FieldStat label="تصنيف" value={result?.class ?? "No Data"} />
            <FieldStat label="FeOx" value={format(result?.alteration_proxy_score)} />
            <FieldStat label="تضاريس" value={format(result?.terrain_score)} />
          </div>
          <p>{reading?.limitation_ar ?? "لا توجد قراءة بعد."}</p>
        </div>
      </section>

      <section className="field-side-actions">
        <button type="button" onClick={() => setBaseMapMode("satellite")} className={baseMapMode === "satellite" ? "active" : ""}>أقمار</button>
        <button type="button" onClick={() => setBaseMapMode("hybrid")} className={baseMapMode === "hybrid" ? "active" : ""}>هجين</button>
        <button type="button" onClick={() => setBaseMapMode("streets")} className={baseMapMode === "streets" ? "active" : ""}>طرق</button>
        <button type="button" onClick={() => setShowLocalMaps((value) => !value)}>خرائط</button>
      </section>

      <section className="field-controls">
        <button type="button" onClick={() => setFollowCenter((value) => !value)} className={followCenter ? "active" : ""}>
          {followCenter ? "تتبع المركز" : "تثبيت"}
        </button>
        <button type="button" onClick={calculate}>{busy ? "..." : "تحليل"}</button>
        <button type="button" onClick={useNativeGps}>GPS</button>
        <button type="button" onClick={() => setRadius(nextRadius(radius))}>{radius}m</button>
      </section>

      <section className="field-radius-bar">
        {radiusOptions.map((value) => (
          <button key={value} className={radius === value ? "active" : ""} onClick={() => setRadius(value)} type="button">
            {value}m
          </button>
        ))}
      </section>

      <details className="field-details">
        <summary>تفاصيل المؤشرات</summary>
        <div className="meter-grid">
          <Metric label="refl_brightness" value={result?.refl_brightness} />
          <Metric label="refl_red_green_proxy" value={result?.refl_red_green_proxy} />
          <Metric label="tir_brightness" value={result?.tir_brightness} />
          <Metric label="dem_elevation" value={result?.dem_elevation} />
          <Metric label="slope_proxy" value={result?.slope_proxy} />
          <Metric label="terrain_score" value={result?.terrain_score} />
          <Metric label="alteration_proxy_score" value={result?.alteration_proxy_score} />
          <Metric label="dryness_exposure_score" value={result?.dryness_exposure_score} />
          <Metric label="structure_score" value={result?.structure_score} />
        </div>
      </details>

      <footer className="field-policy">No Gold Proof · No Depth · No 100% · Surface Screening · Field-check</footer>
    </section>
  );
}

function MiniMeter({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <span>{label}</span>
      <strong>{value}</strong>
      <i><b style={{ width: `${value}%` }} /></i>
    </div>
  );
}

function FieldStat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: unknown }) {
  return (
    <span>
      <b>{label}</b>
      <em>{typeof value === "number" ? value.toFixed(3) : "—"}</em>
    </span>
  );
}

function format(value: unknown) {
  return typeof value === "number" ? Math.round(value) : "—";
}

function nextRadius(radius: number) {
  const current = radiusOptions.indexOf(radius as any);
  return radiusOptions[(current + 1) % radiusOptions.length];
}
