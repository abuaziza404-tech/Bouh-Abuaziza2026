import React, { useEffect, useState } from "react";
import { LocalGroundScoreResult, readLastLocalGroundReading } from "./bouh/localGroundGrid";

export default function ReportPage({ onMessage }: { onMessage: (message: string) => void }) {
  const [last, setLast] = useState<LocalGroundScoreResult | null>(() => readLastLocalGroundReading());

  useEffect(() => {
    const handler = () => setLast(readLastLocalGroundReading());
    window.addEventListener("bouh:last-live-score", handler);
    return () => window.removeEventListener("bouh:last-live-score", handler);
  }, []);

  function createPointReport() {
    const current = readLastLocalGroundReading();
    setLast(current);

    if (!current) {
      onMessage("لا توجد قراءة بعد. افتح الرادار وحلل نقطة.");
      return;
    }

    onMessage("تم تجهيز تقرير النقطة من آخر قراءة محلية.");
  }

  function exportLastJson() {
    const payload = last ?? { message: "لا توجد قراءة بعد. افتح الرادار وحلل نقطة." };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "bouh_local_point_report.json";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section className="screen concise-page operational-report">
      <article className="hero-card compact clean-card">
        <span className="eyebrow">التقارير</span>
        <h2>تقرير نقطة ميدانية</h2>
        <div className="action-row">
          <button className="primary" type="button" onClick={createPointReport}>إنشاء تقرير نقطة</button>
          <button className="secondary" type="button" onClick={exportLastJson}>تصدير JSON</button>
        </div>
      </article>

      {!last && (
        <article className="panel clean-card empty-reading">
          <h3>لا توجد قراءة بعد</h3>
          <p>افتح الرادار، حرّك الخريطة إلى نقطة الفحص، ثم اضغط تحليل المركز الحالي.</p>
        </article>
      )}

      {last && (
        <article className="panel clean-card">
          <h3>آخر قراءة</h3>
          <div className="report-summary-grid">
            <Row label="Lat" value={last.lat.toFixed(6)} ltr />
            <Row label="Lng" value={last.lng.toFixed(6)} ltr />
            <Row label="score" value={formatScore(last.result?.final_ground_score)} ltr />
            <Row label="class" value={last.result?.class ?? "No Data"} />
            <Row label="mode" value={last.mode} ltr />
            <Row label="evidence_count" value={last.result?.evidence_count ?? "—"} ltr />
            <Row label="truth_status" value={last.truth_status} ltr />
            <Row label="limitation" value={last.limitation_ar} />
          </div>
        </article>
      )}
    </section>
  );
}

function Row({ label, value, ltr = false }: { label: string; value: React.ReactNode; ltr?: boolean }) {
  return (
    <div>
      <span>{label}</span>
      <strong dir={ltr ? "ltr" : "rtl"}>{value}</strong>
    </div>
  );
}

function formatScore(value: unknown) {
  return typeof value === "number" ? value.toFixed(1) : "—";
}
